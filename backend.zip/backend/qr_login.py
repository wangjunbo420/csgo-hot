"""
网易 BUFF 扫码登录模块

接口取自 BUFF 官网登录页的前端脚本（2026-11 实测可用），流程：

1. GET  /account/login                      → 种下 client_id / csrf_token / Device-Id cookie
2. POST /account/api/qr_code_create          → {"code_type":1,"extra_param":"{}"}
                                              返回 {code_id, url}，url 即二维码内容
3. GET  /account/api/qr_code_poll?item_id=…  → 返回 state：
                                               1 等待扫码 / 2 已扫码待确认 / 3 已确认 / 4 异常 / 5 超时
4. POST /account/api/qr_code_login           → {"item_id":code_id,"web_device_id":…}
                                              确认后把登录态写入 session（session cookie 就在这里下发）

所有 POST 都需要带 X-CSRFToken 头（值来自 csrf_token cookie），否则返回 403。
"""

import base64
import io
import logging
import time
from dataclasses import dataclass
from typing import Dict, Optional

import qrcode
import requests

logger = logging.getLogger(__name__)


@dataclass
class BuffQRConfig:
    """扫码登录接口配置（来自 BUFF 登录页前端，实测有效）"""

    # 登录页：只用来种 cookie（client_id / csrf_token / Device-Id）
    LOGIN_PAGE_URL: str = "https://buff.163.com/account/login"

    # 生成二维码
    QRCODE_CREATE_URL: str = "https://buff.163.com/account/api/qr_code_create"

    # 轮询扫码状态
    QRCODE_POLL_URL: str = "https://buff.163.com/account/api/qr_code_poll"

    # 确认登录（下发 session cookie）
    QRCODE_LOGIN_URL: str = "https://buff.163.com/account/api/qr_code_login"

    # 二维码用途：1 = 登录
    CODE_TYPE_LOGIN: int = 1

    # 轮询间隔（秒）
    POLL_INTERVAL: float = 2.0

    # 最大轮询次数（2s × 150 = 5 分钟）
    MAX_POLL_COUNT: int = 150

    # 二维码有效期（秒），仅用于前端倒计时展示；真实有效期由 BUFF 的 state=5 决定
    QRCODE_TTL: int = 120

    TIMEOUT: int = 15

    USER_AGENT: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )


# BUFF 的扫码状态码 → 本系统状态
_STATE_MAP = {
    1: ("WAITING", "等待扫码..."),
    2: ("SCANNED", "已扫码，请在手机上确认"),
    3: ("CONFIRMED", "扫码成功！"),
    4: ("ERROR", "二维码异常，请刷新重试"),
    5: ("EXPIRED", "二维码已过期，请刷新重试"),
}


class BuffQRLogin:
    """网易 BUFF 扫码登录"""

    def __init__(self, config: BuffQRConfig = None):
        self.config = config or BuffQRConfig()
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.config.USER_AGENT,
            "Referer": self.config.LOGIN_PAGE_URL,
            "Accept": "application/json, text/plain, */*",
        })
        self._qr_data: Optional[Dict] = None
        self._code_id: str = ""
        self._csrf: str = ""

    # ---- 公开方法 ----

    def start_login(self) -> Dict:
        """
        获取二维码：种 cookie → 调 qr_code_create → 本地生成二维码图片

        Returns:
            {'uuid': code_id, 'qrcode_image': 'data:image/png;base64,...', 'expires_at': ts}
        """
        self._bootstrap()

        payload = {
            "code_type": self.config.CODE_TYPE_LOGIN,
            "extra_param": "{}",
        }
        data = self._post_json(self.config.QRCODE_CREATE_URL, payload)
        if data.get("code") != "OK":
            raise Exception(f"获取二维码失败: {data.get('error') or data.get('msg') or data.get('code')}")

        qr = data.get("data") or {}
        code_id = qr.get("code_id")
        content = qr.get("url")
        if not code_id or not content:
            raise Exception("二维码接口返回缺少 code_id / url")
        if qr.get("action") and qr.get("action") != "login":
            raise Exception(f"二维码用途不符: {qr.get('action')}")

        self._code_id = str(code_id)
        self._qr_data = {
            "uuid": self._code_id,
            "qrcode_image": self._generate_qrcode(content),
            "expires_at": int(time.time()) + self.config.QRCODE_TTL,
        }
        logger.info(f"二维码已生成: {self._code_id}")
        return self._qr_data

    def poll_status(self, uuid: str) -> Dict:
        """
        轮询扫码状态；state=3 时自动调用 qr_code_login 换 session cookie

        Returns:
            {'status': ..., 'message': ..., 'cookie': '...' | None}
        """
        code_id = uuid or self._code_id
        if not code_id:
            return {"status": "ERROR", "message": "缺少二维码 ID，请重新获取", "cookie": None}

        resp = self.session.get(
            self.config.QRCODE_POLL_URL,
            params={"item_id": code_id, "_": int(time.time() * 1000)},
            timeout=self.config.TIMEOUT,
        )
        data = self._json(resp)
        if data.get("code") != "OK":
            return {
                "status": "WAITING",
                "message": "轮询暂未成功，继续等待…",
                "cookie": None,
            }

        state = (data.get("data") or {}).get("state")
        try:
            state = int(state)
        except (TypeError, ValueError):
            state = 0

        status, message = _STATE_MAP.get(state, ("UNKNOWN", "未知状态"))

        if status == "CONFIRMED":
            cookie = self._complete_login(code_id)
            if cookie:
                return {"status": "CONFIRMED", "message": "扫码成功，登录态已获取", "cookie": cookie}
            return {
                "status": "ERROR",
                "message": "已确认扫码，但没能换到登录 Cookie，请重新获取二维码再试",
                "cookie": None,
            }

        return {"status": status, "message": message, "cookie": None}

    def wait_for_scan(self, uuid: str, callback=None) -> Dict:
        """阻塞等待扫码完成"""
        for _ in range(self.config.MAX_POLL_COUNT):
            result = self.poll_status(uuid)
            if callback:
                callback(result["status"], result["message"])
            if result["status"] in ("CONFIRMED", "EXPIRED", "CANCELLED", "ERROR"):
                return result
            time.sleep(self.config.POLL_INTERVAL)

        return {"status": "EXPIRED", "message": "扫码超时，请重试", "cookie": None}

    def get_session_cookie(self) -> str:
        """从 session cookie jar 中提取所有 cookie"""
        return self._collect_cookies()

    def close(self):
        try:
            self.session.close()
        except Exception:
            pass

    # ---- 内部方法：请求 ----

    def _bootstrap(self):
        """访问登录页，拿到 csrf_token 等基础 cookie"""
        try:
            resp = self.session.get(self.config.LOGIN_PAGE_URL, timeout=self.config.TIMEOUT)
            logger.debug(f"登录页状态 {resp.status_code}")
        except Exception as e:
            raise Exception(f"连接 BUFF 登录页失败: {e}")
        self._csrf = self.session.cookies.get("csrf_token", "")
        if not self._csrf:
            raise Exception("BUFF 登录页未返回 csrf_token，可能被风控拦截，请稍后重试")

    def _post_json(self, url: str, payload: Dict) -> Dict:
        """带 CSRF 头的 JSON POST（BUFF 所有写操作都要求 X-CSRFToken）"""
        if not self._csrf:
            self._csrf = self.session.cookies.get("csrf_token", "")
        headers = {
            "Content-Type": "application/json",
            "X-CSRFToken": self._csrf,
            "Referer": self.config.LOGIN_PAGE_URL,
            "Origin": "https://buff.163.com",
        }
        resp = self.session.post(url, json=payload, headers=headers, timeout=self.config.TIMEOUT)
        return self._json(resp)

    @staticmethod
    def _json(resp: requests.Response) -> Dict:
        """解析 JSON，非 JSON 响应给出可读错误"""
        try:
            return resp.json()
        except ValueError:
            snippet = (resp.text or "")[:120].replace("\n", " ")
            raise Exception(f"BUFF 返回非 JSON 响应（HTTP {resp.status_code}）: {snippet}")

    # ---- 内部方法：确认登录与取 Cookie ----

    def _complete_login(self, code_id: str) -> str:
        """
        扫码确认后调用 qr_code_login，把登录态换成本地 session。

        BUFF 前端会额外带 web_device_id（浏览器指纹哈希）。这里优先用 cookie 里的
        Device-Id（同一设备标识）；若接口报错则退回不带该字段再试一次。
        """
        device_id = self.session.cookies.get("Device-Id", "")
        attempts = []
        if device_id:
            attempts.append({"item_id": code_id, "web_device_id": device_id})
        attempts.append({"item_id": code_id})

        last_error = ""
        for payload in attempts:
            try:
                data = self._post_json(self.config.QRCODE_LOGIN_URL, payload)
            except Exception as e:
                last_error = str(e)
                continue
            if data.get("code") == "OK":
                cookie = self._collect_cookies()
                if "session=" in cookie:
                    logger.info("扫码登录成功，已获取 session cookie")
                    return cookie
                last_error = "接口返回成功但未拿到 session cookie"
            else:
                last_error = str(data.get("error") or data.get("msg") or data.get("code"))

        logger.warning(f"扫码登录换取 Cookie 失败: {last_error}")
        return ""

    def _collect_cookies(self) -> str:
        """收集 buff.163.com / .163.com 域下的全部 cookie，拼成请求用的 Cookie 字符串"""
        cookies = {}
        for c in self.session.cookies:
            domain = (c.domain or "")
            if "buff.163.com" in domain or domain.endswith("163.com"):
                if c.name and c.value:
                    cookies[c.name] = c.value
        return "; ".join(f"{k}={v}" for k, v in cookies.items())

    # ---- 内部方法：二维码绘制 ----

    @staticmethod
    def _generate_qrcode(content: str) -> str:
        """把 BUFF 返回的二维码内容画成本地二维码图片（data URI）"""
        qr = qrcode.QRCode(version=None, box_size=8, border=2)
        qr.add_data(content)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode()


def parse_cookie_from_response(response_data: Dict) -> str:
    """从任意形态的响应里尽力提取 cookie 字符串（保留给旧调用方）"""
    if not isinstance(response_data, dict):
        return ""
    for scope in (response_data.get("data"), response_data):
        if isinstance(scope, dict):
            for key in ("cookie", "cookies", "session_cookie"):
                val = scope.get(key)
                if isinstance(val, str) and "=" in val:
                    return val
            sid = scope.get("session_id") or scope.get("sessionid")
            if sid:
                return f"session={sid}"
    return ""


if __name__ == "__main__":
    login = BuffQRLogin()
    try:
        info = login.start_login()
        print(f"二维码已生成: {info['uuid']}")
        result = login.wait_for_scan(info["uuid"])
        print(f"最终结果: {result['status']} {result['message']}")
        if result.get("cookie"):
            print(f"Cookie 前 80 字符: {result['cookie'][:80]}")
    finally:
        login.close()
