"""
数据获取器抽象基类

定义统一接口，所有平台（BUFF、Steam 等）必须实现这些方法。
下游模块（风险分析、交易决策）只依赖此接口，不关心具体平台。
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple


class BaseFetcher(ABC):
    """数据获取器抽象基类"""

    @abstractmethod
    def fetch_item_price(self, market_hash_name: str, game: str = 'csgo',
                         **kwargs) -> Dict:
        """
        获取饰品价格数据

        Returns:
            {
                'item_name': str,        # 饰品名称
                'price_low': float,      # 最低售价
                'price_avg_7d': float,   # 7日均价
                'buy_order': float,      # 最高求购价
                'paintwear': float|None, # 磨损值（部分平台不提供）
                'timestamp': str,        # ISO 格式时间戳
            }
        """

    @abstractmethod
    def fetch_price_history(self, market_hash_name: str, days: int = 7) -> List[Tuple[str, float, int]]:
        """
        获取历史价格数据

        Returns:
            [(date_str, price, volume), ...]  按日期升序排列
        """

    @abstractmethod
    def validate_auth(self) -> bool:
        """
        验证认证凭据是否有效

        Returns:
            True = 凭据有效（或无需凭据），False = 凭据无效或过期
        """

    @abstractmethod
    def close(self):
        """关闭 HTTP 会话，释放资源"""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
