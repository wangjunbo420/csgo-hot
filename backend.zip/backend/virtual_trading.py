"""
虚拟盘 / Paper Trading 后端（MVP）

只做纸面账本：
- 三档虚拟账户
- BUFF 报价买入、168 小时锁定
- BUFF / Steam 双口径手续费与盈亏
- 流动性评分 + 随机无法售出
- 到期结算 / 宽限期 / 无法变现

不调用任何真实下单接口。
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import sqlite3
import statistics
import threading
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import paths
from market_intel import MarketIntel

logger = logging.getLogger(__name__)

MODEL_VERSION = "virtual-mvp-1"
LOCK_HOURS = 168
GRACE_HOURS = 24
STEAM_WALLET_HAIRCUT = 0.70

BUFF_SELL_FEE = 0.015
BUFF_WITHDRAW_FEE = 0.01

TIERS: Dict[str, Dict] = {
    "starter": {
        "name": "体验档",
        "initial_capital": 1000.0,
        "single_limit": 0.20,
        "max_positions": 5,
        "max_daily_buys": 3,
        "min_cash_ratio": 0.10,
    },
    "standard": {
        "name": "标准档",
        "initial_capital": 5000.0,
        "single_limit": 0.15,
        "max_positions": 10,
        "max_daily_buys": 5,
        "min_cash_ratio": 0.10,
    },
    "advanced": {
        "name": "进阶档",
        "initial_capital": 20000.0,
        "single_limit": 0.10,
        "max_positions": 20,
        "max_daily_buys": 10,
        "min_cash_ratio": 0.10,
    },
}

DEFAULT_TIER = "standard"


class VirtualError(Exception):
    """虚拟盘业务错误（由 API 层转成 400）"""


def _now() -> datetime:
    return datetime.now()


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _to_float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _to_int(value, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _round2(value: float) -> float:
    return round(float(value) + 1e-9, 2)


def _cents(value: float) -> int:
    return int(round(float(value) * 100))


def steam_seller_net_cents(buyer_cents: int) -> int:
    """给定 Steam 买家支付价（分），求卖家到手价（分）。

    Steam 5% + CS2 10%，每项最低 1 分，按分向下取整。
    """
    buyer_cents = max(0, int(buyer_cents))
    lo, hi = 0, buyer_cents
    best = 0
    while lo <= hi:
        mid = (lo + hi) // 2
        steam_fee = max(1, mid * 5 // 100)
        game_fee = max(1, mid * 10 // 100)
        total = mid + steam_fee + game_fee
        if total <= buyer_cents:
            best = mid
            lo = mid + 1
        else:
            hi = mid - 1
    return best


def steam_seller_net(buyer_price: float) -> float:
    return steam_seller_net_cents(_cents(buyer_price)) / 100.0


def steam_buyer_price_for_seller(seller_cents: int) -> int:
    """给定卖家要到手的分，求最小买家支付价（分）。"""
    seller_cents = max(0, int(seller_cents))
    if seller_cents <= 0:
        return 0
    lo, hi = seller_cents, seller_cents * 2 + 10
    while lo < hi:
        mid = (lo + hi) // 2
        if steam_seller_net_cents(mid) >= seller_cents:
            hi = mid
        else:
            lo = mid + 1
    return lo


def steam_break_even_buyer(buy_price: float, haircut: float = STEAM_WALLET_HAIRCUT) -> float:
    """Steam 买入后，按钱包折现率回本所需的卖出买家价。"""
    target_seller_cents = int(math.ceil(_cents(buy_price) / max(0.01, haircut)))
    return steam_buyer_price_for_seller(target_seller_cents) / 100.0


def calc_liquidity(quote: Dict, qty: int) -> float:
    """卖方视角流动性评分，0-100。在售越多，分数越低。"""
    qty = max(1, int(qty))
    adv = max(0.0, _to_float(quote.get("daily_volume")))
    bid_volume = max(0, _to_int(quote.get("bid_volume")))
    ask_volume = max(0, _to_int(quote.get("ask_volume") or quote.get("listed_count")))
    spread = max(0.0, _to_float(quote.get("spread_pct")))
    bid = max(0.0, _to_float(quote.get("bid")))

    if bid > 0:
        # 页面没有返回真实求购单数量时，用 1 作为保守代理；不伪造成“很深”。
        bid_volume = max(1, bid_volume)
    ask_volume = max(1, ask_volume)

    v_term = min(1.0, adv / (20.0 * qty))
    d_term = min(1.0, bid_volume / (3.0 * qty))
    s_term = max(0.0, 1.0 - spread / 20.0)
    p_term = min(1.0, (5.0 * qty) / (ask_volume + qty))

    score = 100.0 * (
        0.35 * v_term
        + 0.30 * d_term
        + 0.20 * s_term
        + 0.15 * p_term
    )
    return round(max(0.0, min(100.0, score)), 2)


def calc_fail_probability(quote: Dict, qty: int, liquidity: float,
                          lead_shock_z: float = 0.0) -> float:
    bid = max(0.0, _to_float(quote.get("bid")))
    if bid <= 0:
        return 1.0

    spread = max(0.0, _to_float(quote.get("spread_pct")))
    vol7 = max(0.0, _to_float(quote.get("vol7_pct")))
    depth = max(1, _to_int(quote.get("bid_volume")))
    queue = min(1.0, max(1, int(qty)) / depth)
    z = (
        -5.0
        + 3.0 * (1.0 - liquidity / 100.0)
        + 0.10 * spread
        + 0.15 * vol7
        + 0.80 * queue
        + 0.30 * max(0.0, -lead_shock_z)
    )
    p = 1.0 / (1.0 + math.exp(-z))

    if liquidity >= 85 and queue <= 0.2 and spread <= 3:
        p = min(p, 0.05)
    if liquidity < 20 and spread > 20:
        p = max(p, 0.60)
    return round(max(0.01, min(0.95, p)), 4)


def deterministic_uniform(seed: str) -> float:
    digest = hashlib.sha256(seed.encode("utf-8")).digest()
    value = int.from_bytes(digest[:8], "big")
    return value / float(1 << 64)


def calc_slippage(quote: Dict, qty: int) -> float:
    spread = max(0.0, _to_float(quote.get("spread_pct"))) / 100.0
    vol7 = max(0.0, _to_float(quote.get("vol7_pct"))) / 100.0
    adv = max(1.0, _to_float(quote.get("daily_volume")))
    impact = vol7 * math.sqrt(max(1, qty) / adv)
    return round(min(0.35, max(0.0, 0.5 * spread + impact)), 4)


def _vol7_from_series(series: List[Dict]) -> float:
    """用历史序列估一个保守的 7 日波动百分比。"""
    prices = [max(0.0, _to_float(p.get("price"))) for p in series or []]
    prices = [p for p in prices if p > 0]
    if len(prices) < 2:
        return 2.0
    returns = []
    for i in range(1, len(prices)):
        if prices[i - 1] > 0:
            returns.append(prices[i] / prices[i - 1] - 1.0)
    if not returns:
        return 2.0
    try:
        daily_sigma = statistics.pstdev(returns)
    except statistics.StatisticsError:
        daily_sigma = 0.0
    return round(max(1.0, min(30.0, daily_sigma * 100.0 * math.sqrt(max(1, len(returns) / 7.0)))), 2)


class VirtualTradingDB:
    """独立 SQLite 库，避免污染真实交易库。"""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or paths.data_path("virtual_trading.db")
        self._init_db()

    def _get_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _init_db(self):
        with self._get_conn() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS virtual_accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tier TEXT NOT NULL,
                    initial_capital REAL NOT NULL,
                    cash REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL,
                    reset_at TEXT
                );

                CREATE TABLE IF NOT EXISTS virtual_positions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    account_id INTEGER NOT NULL,
                    venue TEXT NOT NULL DEFAULT 'buff',
                    goods_id TEXT NOT NULL,
                    market_hash_name TEXT,
                    item_name TEXT NOT NULL,
                    icon_url TEXT,
                    exterior TEXT,
                    qty INTEGER NOT NULL,
                    ask REAL NOT NULL,
                    bid REAL NOT NULL,
                    ask_volume INTEGER DEFAULT 0,
                    bid_volume INTEGER DEFAULT 0,
                    daily_volume INTEGER DEFAULT 0,
                    spread_pct REAL DEFAULT 0,
                    buy_cost REAL NOT NULL,
                    bought_at TEXT NOT NULL,
                    lock_until TEXT NOT NULL,
                    grace_until TEXT,
                    status TEXT NOT NULL DEFAULT 'LOCKED',
                    buy_snapshot_json TEXT,
                    steam_shadow_json TEXT,
                    last_bid REAL DEFAULT 0,
                    fail_probability REAL DEFAULT 0,
                    random_seed TEXT,
                    model_version TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS virtual_settlements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    position_id INTEGER NOT NULL,
                    attempt INTEGER NOT NULL DEFAULT 1,
                    settle_at TEXT NOT NULL,
                    exit_price REAL DEFAULT 0,
                    filled_qty INTEGER DEFAULT 0,
                    gross REAL DEFAULT 0,
                    sell_fee REAL DEFAULT 0,
                    withdraw_fee REAL DEFAULT 0,
                    net REAL DEFAULT 0,
                    pnl REAL DEFAULT 0,
                    pnl_pct REAL DEFAULT 0,
                    status TEXT NOT NULL,
                    reason TEXT,
                    random_draw REAL,
                    fail_probability REAL,
                    liquidity_score REAL,
                    settle_snapshot_json TEXT,
                    steam_shadow_json TEXT,
                    model_version TEXT,
                    created_at TEXT NOT NULL,
                    UNIQUE(position_id, attempt)
                );

                CREATE TABLE IF NOT EXISTS virtual_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    account_id INTEGER NOT NULL,
                    position_id INTEGER,
                    entry_type TEXT NOT NULL,
                    amount REAL NOT NULL,
                    balance_after REAL NOT NULL,
                    note TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_virtual_positions_account
                    ON virtual_positions(account_id, status);
                CREATE INDEX IF NOT EXISTS idx_virtual_settlements_position
                    ON virtual_settlements(position_id);
                """
            )
            conn.commit()

    # ---- account ----
    def get_active_account(self) -> Optional[Dict]:
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT * FROM virtual_accounts WHERE status='active' ORDER BY id DESC LIMIT 1"
            ).fetchone()
        return dict(row) if row else None

    def create_account(self, tier: str) -> Dict:
        cfg = TIERS[tier]
        now = _iso(_now())
        with self._get_conn() as conn:
            conn.execute("UPDATE virtual_accounts SET status='archived', reset_at=? WHERE status='active'", (now,))
            cur = conn.execute(
                """INSERT INTO virtual_accounts
                   (tier, initial_capital, cash, status, created_at)
                   VALUES (?, ?, ?, 'active', ?)""",
                (tier, cfg["initial_capital"], cfg["initial_capital"], now),
            )
            conn.commit()
            new_id = cur.lastrowid
        return self.get_account(new_id)

    def get_account(self, account_id: int) -> Optional[Dict]:
        with self._get_conn() as conn:
            row = conn.execute("SELECT * FROM virtual_accounts WHERE id=?", (account_id,)).fetchone()
        return dict(row) if row else None

    def update_account_cash(self, account_id: int, cash: float):
        with self._get_conn() as conn:
            conn.execute("UPDATE virtual_accounts SET cash=? WHERE id=?", (_round2(cash), account_id))
            conn.commit()

    def add_ledger(self, account_id: int, position_id: Optional[int], entry_type: str,
                   amount: float, balance_after: float, note: str = ""):
        with self._get_conn() as conn:
            conn.execute(
                """INSERT INTO virtual_ledger
                   (account_id, position_id, entry_type, amount, balance_after, note, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (account_id, position_id, entry_type, _round2(amount),
                 _round2(balance_after), note, _iso(_now())),
            )
            conn.commit()

    # ---- positions ----
    def insert_position(self, data: Dict) -> Dict:
        now = _iso(_now())
        with self._get_conn() as conn:
            cur = conn.execute(
                """INSERT INTO virtual_positions
                   (account_id, venue, goods_id, market_hash_name, item_name, icon_url, exterior,
                    qty, ask, bid, ask_volume, bid_volume, daily_volume, spread_pct, buy_cost,
                    bought_at, lock_until, status, buy_snapshot_json, steam_shadow_json,
                    last_bid, fail_probability, random_seed, model_version, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    data["account_id"], data.get("venue", "buff"), data["goods_id"],
                    data.get("market_hash_name", ""), data["item_name"], data.get("icon_url", ""),
                    data.get("exterior", ""), int(data["qty"]), _to_float(data["ask"]),
                    _to_float(data["bid"]), _to_int(data.get("ask_volume")),
                    _to_int(data.get("bid_volume")), _to_int(data.get("daily_volume")),
                    _to_float(data.get("spread_pct")), _to_float(data["buy_cost"]),
                    data["bought_at"], data["lock_until"], "LOCKED",
                    json.dumps(data.get("buy_snapshot") or {}, ensure_ascii=False),
                    json.dumps(data.get("steam_shadow") or {}, ensure_ascii=False),
                    _to_float(data.get("bid")), _to_float(data.get("fail_probability")),
                    data["random_seed"], MODEL_VERSION, now, now,
                ),
            )
            conn.commit()
            pos_id = cur.lastrowid
        return self.get_position(pos_id)

    def get_position(self, position_id: int) -> Optional[Dict]:
        with self._get_conn() as conn:
            row = conn.execute("SELECT * FROM virtual_positions WHERE id=?", (position_id,)).fetchone()
        return dict(row) if row else None

    def list_positions(self, account_id: int, include_closed: bool = True) -> List[Dict]:
        sql = "SELECT * FROM virtual_positions WHERE account_id=?"
        params: List = [account_id]
        if not include_closed:
            sql += " AND status IN ('LOCKED','GRACE')"
        sql += " ORDER BY id DESC"
        with self._get_conn() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def update_position(self, position_id: int, **fields):
        if not fields:
            return
        fields["updated_at"] = _iso(_now())
        cols = ", ".join(f"{k}=?" for k in fields)
        vals = list(fields.values()) + [position_id]
        with self._get_conn() as conn:
            conn.execute(f"UPDATE virtual_positions SET {cols} WHERE id=?", vals)
            conn.commit()

    # ---- settlements ----
    def next_attempt(self, position_id: int) -> int:
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT COALESCE(MAX(attempt), 0) AS n FROM virtual_settlements WHERE position_id=?",
                (position_id,),
            ).fetchone()
        return int(row["n"] or 0) + 1

    def insert_settlement(self, data: Dict) -> Dict:
        with self._get_conn() as conn:
            cur = conn.execute(
                """INSERT INTO virtual_settlements
                   (position_id, attempt, settle_at, exit_price, filled_qty, gross,
                    sell_fee, withdraw_fee, net, pnl, pnl_pct, status, reason,
                    random_draw, fail_probability, liquidity_score,
                    settle_snapshot_json, steam_shadow_json, model_version, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    data["position_id"], int(data["attempt"]), data["settle_at"],
                    _to_float(data.get("exit_price")), _to_int(data.get("filled_qty")),
                    _to_float(data.get("gross")), _to_float(data.get("sell_fee")),
                    _to_float(data.get("withdraw_fee")), _to_float(data.get("net")),
                    _to_float(data.get("pnl")), _to_float(data.get("pnl_pct")),
                    data["status"], data.get("reason", ""), data.get("random_draw"),
                    data.get("fail_probability"), data.get("liquidity_score"),
                    json.dumps(data.get("settle_snapshot") or {}, ensure_ascii=False),
                    json.dumps(data.get("steam_shadow") or {}, ensure_ascii=False),
                    MODEL_VERSION, _iso(_now()),
                ),
            )
            conn.commit()
            sid = cur.lastrowid
        return self.get_settlement(sid)

    def get_settlement(self, settlement_id: int) -> Optional[Dict]:
        with self._get_conn() as conn:
            row = conn.execute("SELECT * FROM virtual_settlements WHERE id=?", (settlement_id,)).fetchone()
        return dict(row) if row else None

    def list_settlements(self, account_id: int, limit: int = 50) -> List[Dict]:
        with self._get_conn() as conn:
            rows = conn.execute(
                """SELECT s.*, p.item_name, p.icon_url, p.qty, p.buy_cost, p.bought_at
                   FROM virtual_settlements s
                   JOIN virtual_positions p ON p.id = s.position_id
                   WHERE p.account_id=?
                   ORDER BY s.id DESC LIMIT ?""",
                (account_id, int(limit)),
            ).fetchall()
        return [dict(r) for r in rows]


class VirtualTradingService:
    def __init__(self, buff_fetcher, steam_fetcher, db_path: Optional[str] = None):
        self.buff_fetcher = buff_fetcher
        self.steam_fetcher = steam_fetcher
        self.db = VirtualTradingDB(db_path)
        self.market_intel = MarketIntel(steam_fetcher=steam_fetcher)
        self._quote_cache: Dict[str, Dict] = {}

    def set_fetchers(self, buff_fetcher, steam_fetcher):
        self.buff_fetcher = buff_fetcher
        self.steam_fetcher = steam_fetcher
        if self.market_intel:
            self.market_intel.set_steam_fetcher(steam_fetcher)
        self._quote_cache.clear()

    # ---- config / account ----
    def get_config(self) -> Dict:
        return {
            "tiers": TIERS,
            "default_tier": DEFAULT_TIER,
            "lock_hours": LOCK_HOURS,
            "grace_hours": GRACE_HOURS,
            "buff_sell_fee": BUFF_SELL_FEE,
            "buff_withdraw_fee": BUFF_WITHDRAW_FEE,
            "steam_wallet_haircut": STEAM_WALLET_HAIRCUT,
            "model_version": MODEL_VERSION,
            "fee_note": "BUFF 卖出 1.5% + 提现 1%；Steam 5% + CS2 10%，每项最低 0.01，按分取整。",
        }

    def ensure_account(self, tier: str = DEFAULT_TIER) -> Dict:
        account = self.db.get_active_account()
        if account:
            return self._account_view(account)
        return self._account_view(self.db.create_account(tier))

    def reset_account(self, tier: str) -> Dict:
        if tier not in TIERS:
            raise VirtualError(f"未知档位: {tier}")
        return self._account_view(self.db.create_account(tier))

    def _account_view(self, account: Dict) -> Dict:
        positions = self.db.list_positions(account["id"], include_closed=False)
        locked_value = 0.0
        for p in positions:
            last_bid = _to_float(p.get("last_bid")) or _to_float(p.get("bid"))
            locked_value += max(0.0, last_bid) * int(p.get("qty") or 0)
        equity = _to_float(account.get("cash")) + locked_value
        return {
            "id": account["id"],
            "tier": account["tier"],
            "tier_name": TIERS.get(account["tier"], {}).get("name", account["tier"]),
            "initial_capital": _round2(account.get("initial_capital")),
            "cash": _round2(account.get("cash")),
            "locked_value": _round2(locked_value),
            "equity": _round2(equity),
            "active_positions": len(positions),
            "created_at": account.get("created_at"),
            "reset_at": account.get("reset_at"),
        }

    # ---- quotes ----
    def get_quote(self, goods_id: str, market_hash_name: str = "", qty: int = 1,
                  force: bool = False) -> Dict:
        goods_id = str(goods_id or "").strip()
        if not goods_id:
            raise VirtualError("缺少 goods_id")
        qty = max(1, int(qty or 1))
        cache_key = f"{goods_id}:{market_hash_name}:{qty}"
        if not force and cache_key in self._quote_cache:
            cached = self._quote_cache[cache_key]
            if (_now() - datetime.fromisoformat(cached["_cached_at"])).total_seconds() < 60:
                return cached

        if not self.buff_fetcher:
            raise VirtualError("BUFF 数据源未初始化")
        try:
            raw = self.buff_fetcher.fetch_item_price(
                market_hash_name=market_hash_name or goods_id,
                goods_id=goods_id,
            )
        except Exception as exc:
            raise VirtualError(f"获取 BUFF 报价失败：{exc}") from exc

        ask = _to_float(raw.get("price_low"))
        bid = _to_float(raw.get("buy_order"))
        if ask <= 0:
            raise VirtualError("BUFF 报价无效：最低在售价为 0")

        daily_volume = 0
        vol7_pct = 2.0
        try:
            series = self.buff_fetcher.fetch_goods_series(goods_id, days=7)
            if series:
                volumes = [max(0, _to_int(p.get("sell_num"))) for p in series]
                daily_volume = int(round(sum(volumes) / max(1, len(volumes))))
                vol7_pct = _vol7_from_series(series)
        except Exception as exc:
            logger.warning("虚拟盘获取成交量失败: %s", exc)

        ask_volume = max(0, _to_int(raw.get("ask_volume")))
        bid_volume = max(0, _to_int(raw.get("bid_volume")))
        # 页面只给最低在售/最高求购时，用成交量做一个保守深度代理，并明确标记。
        depth_source = "reported"
        if bid > 0 and bid_volume <= 0:
            bid_volume = max(1, min(10, int(daily_volume / 2) or 1))
            depth_source = "proxy"
        if ask_volume <= 0:
            ask_volume = max(1, min(100, int(daily_volume) or 1))

        spread_pct = 0.0
        if ask > 0 and bid > 0:
            mid = (ask + bid) / 2.0
            spread_pct = round(max(0.0, (ask - bid) / mid * 100.0), 2)

        quote = {
            "goods_id": goods_id,
            "market_hash_name": (raw.get("market_hash_name") or market_hash_name or raw.get("item_name") or goods_id),
            "item_name": raw.get("item_name") or market_hash_name or goods_id,
            "icon_url": raw.get("icon_url") or "",
            "exterior": raw.get("exterior") or "",
            "rarity": raw.get("rarity") or "",
            "ask": _round2(ask),
            "bid": _round2(bid),
            "ask_volume": ask_volume,
            "bid_volume": bid_volume,
            "daily_volume": daily_volume,
            "listed_count": max(ask_volume, _to_int(raw.get("listed_count"))),
            "spread_pct": spread_pct,
            "price_avg_7d": _round2(_to_float(raw.get("price_avg_7d"))),
            "vol7_pct": vol7_pct,
            "depth_source": depth_source,
            "source": "buff",
            "timestamp": _iso(_now()),
            "_cached_at": _iso(_now()),
        }

        steam_quote = self._steam_quote(quote)
        quote["steam"] = steam_quote
        quote["market_intel"] = self.market_intel.augment(
            quote, steam_quote=steam_quote, qty=qty, goods_id=goods_id,
        )
        liquidity = calc_liquidity(quote, qty)
        fail_probability = calc_fail_probability(
            quote, qty, liquidity, lead_shock_z=_to_float(quote["market_intel"].get("lead_shock_z")),
        )
        quote["liquidity_score"] = liquidity
        quote["fail_probability"] = fail_probability
        quote["buff_fee"] = self.fee_breakdown(quote["ask"])

        self._quote_cache[cache_key] = quote
        return quote

    def _steam_quote(self, buff_quote: Dict) -> Dict:
        """Steam 对照报价。拿不到就明确标记不可用，不用 BUFF 价硬造。"""
        name = (buff_quote.get("market_hash_name") or "").strip()
        if not name or not self.steam_fetcher:
            return {"available": False, "reason": "缺少 Steam market_hash_name"}

        # Steam 接口在弱网下可能重试很久；MVP 里给它一个短超时，避免整张 BUFF 报价被拖死。
        box: Dict[str, object] = {}

        def worker():
            try:
                box["raw"] = self.steam_fetcher.fetch_item_price(name)
            except Exception as exc:  # noqa: BLE001
                box["error"] = exc

        t = threading.Thread(target=worker, name="virtual-steam-quote", daemon=True)
        t.start()
        t.join(6.0)
        if t.is_alive():
            logger.info("Steam 对照报价超时，已跳过")
            return {"available": False, "reason": "Steam 报价超时，已跳过（不影响 BUFF 模拟买入）"}

        exc = box.get("error")
        if exc:
            logger.info("Steam 对照报价失败: %s", exc)
            return {"available": False, "reason": f"Steam 报价失败: {exc}"}

        raw = box.get("raw") or {}
        buy = _to_float(raw.get("price_low"))
        if buy <= 0:
            return {"available": False, "reason": "Steam 最低价无效"}
        exit_proxy = _to_float(raw.get("price_avg_7d")) or round(buy * 0.95, 2)
        net = steam_seller_net(exit_proxy)
        cash_eq = round(net * STEAM_WALLET_HAIRCUT, 2)
        be = steam_break_even_buyer(buy, STEAM_WALLET_HAIRCUT)
        return {
            "available": True,
            "market_hash_name": name,
            "buy_price": _round2(buy),
            "exit_price": _round2(exit_proxy),
            "seller_net": _round2(net),
            "cash_equivalent": _round2(cash_eq),
            "wallet_haircut": STEAM_WALLET_HAIRCUT,
            "effective_fee_pct": round((1.0 - net / max(buy, 0.01)) * 100.0, 2),
            "break_even_buyer": _round2(be),
            "break_even_change_pct": round((be / max(buy, 0.01) - 1.0) * 100.0, 2),
            "exit_proxy": True,
        }

    def fee_breakdown(self, price: float) -> Dict:
        price = max(0.0, _to_float(price))
        sell_fee = round(price * BUFF_SELL_FEE, 2)
        after_fee = price - sell_fee
        withdraw_fee = round(after_fee * BUFF_WITHDRAW_FEE, 2)
        net = round(after_fee - withdraw_fee, 2)
        factor = (1.0 - BUFF_SELL_FEE) * (1.0 - BUFF_WITHDRAW_FEE)
        breakeven = round(price / factor, 2) if factor > 0 else 0.0
        steam_buyer = price
        steam_net = steam_seller_net(steam_buyer)
        steam_be = steam_break_even_buyer(steam_buyer, STEAM_WALLET_HAIRCUT)
        return {
            "price": _round2(price),
            "buff": {
                "sell_fee": sell_fee,
                "withdraw_fee": withdraw_fee,
                "net": net,
                "effective_fee_pct": round((1.0 - net / price) * 100.0, 3) if price > 0 else 0.0,
                "breakeven_sell_price": breakeven,
                "breakeven_change_pct": round((breakeven / price - 1.0) * 100.0, 3) if price > 0 else 0.0,
            },
            "steam": {
                "buyer_price": _round2(steam_buyer),
                "seller_net": _round2(steam_net),
                "effective_fee_pct": round((1.0 - steam_net / steam_buyer) * 100.0, 3) if steam_buyer > 0 else 0.0,
                "wallet_haircut": STEAM_WALLET_HAIRCUT,
                "cash_equivalent": _round2(steam_net * STEAM_WALLET_HAIRCUT),
                "breakeven_buyer": _round2(steam_be),
                "breakeven_change_pct": round((steam_be / steam_buyer - 1.0) * 100.0, 3) if steam_buyer > 0 else 0.0,
            },
        }

    # ---- portfolio ----
    def get_portfolio(self, tier: str = DEFAULT_TIER, limit: int = 50) -> Dict:
        account = self.ensure_account(tier)
        positions = self.db.list_positions(account["id"], include_closed=True)
        settlements = self.db.list_settlements(account["id"], limit=limit)
        now = _now()

        out_positions = []
        for p in positions:
            lock_until = _parse_iso(p.get("lock_until"))
            grace_until = _parse_iso(p.get("grace_until"))
            remaining = 0
            if p["status"] == "LOCKED" and lock_until:
                remaining = max(0, int((lock_until - now).total_seconds()))
            elif p["status"] == "GRACE" and grace_until:
                remaining = max(0, int((grace_until - now).total_seconds()))
            last_bid = _to_float(p.get("last_bid")) or _to_float(p.get("bid"))
            out_positions.append({
                **p,
                "buy_snapshot": json.loads(p.get("buy_snapshot_json") or "{}"),
                "steam_shadow": json.loads(p.get("steam_shadow_json") or "{}"),
                "last_bid": _round2(last_bid),
                "market_value": _round2(last_bid * int(p.get("qty") or 0)),
                "remaining_seconds": remaining,
                "can_settle": (
                    (p["status"] == "LOCKED" and lock_until and lock_until <= now)
                    or (p["status"] == "GRACE" and grace_until and grace_until <= now)
                    or (p["status"] == "GRACE" and not grace_until)
                ),
            })

        return {
            "account": account,
            "positions": out_positions,
            "settlements": settlements,
            "stats": self._stats(account["id"]),
        }

    def _stats(self, account_id: int) -> Dict:
        settlements = self.db.list_settlements(account_id, limit=500)
        closed = [s for s in settlements if s.get("status") in ("SOLD", "WRITTEN_OFF", "BUNDLED")]
        wins = [s for s in closed if _to_float(s.get("pnl")) > 0]
        total_pnl = sum(_to_float(s.get("pnl")) for s in closed)
        total_fees = sum(_to_float(s.get("sell_fee")) + _to_float(s.get("withdraw_fee")) for s in settlements)
        no_fill = [s for s in settlements if s.get("status") == "NO_FILL"]
        return {
            "closed_trades": len(closed),
            "wins": len(wins),
            "win_rate": round(len(wins) / len(closed) * 100.0, 2) if closed else 0.0,
            "total_pnl": _round2(total_pnl),
            "total_fees": _round2(total_fees),
            "no_fill_count": len(no_fill),
            "settlement_count": len(settlements),
        }

    # ---- buy ----
    def buy(self, goods_id: str, market_hash_name: str = "", qty: int = 1) -> Dict:
        qty = max(1, int(qty or 1))
        if qty > 3:
            raise VirtualError("同一具体款最多持有 3 件")
        account = self.ensure_account(DEFAULT_TIER)
        cfg = TIERS[account["tier"]]
        positions = self.db.list_positions(account["id"], include_closed=False)
        same = [p for p in positions if str(p.get("goods_id")) == str(goods_id)]
        if len(same) + qty > 3:
            raise VirtualError("同一具体款最多持有 3 件")
        if len(positions) >= cfg["max_positions"]:
            raise VirtualError(f"{cfg['name']}最多同时持有 {cfg['max_positions']} 件")

        today = _now().date().isoformat()
        today_buys = 0
        for p in self.db.list_positions(account["id"], include_closed=True):
            if (p.get("bought_at") or "").startswith(today):
                today_buys += 1
        if today_buys >= cfg["max_daily_buys"]:
            raise VirtualError(f"{cfg['name']}今日最多买入 {cfg['max_daily_buys']} 笔")

        quote = self.get_quote(goods_id, market_hash_name, qty=qty)
        buy_cost = _round2(quote["ask"] * qty)
        max_single = _round2(min(account["initial_capital"], account["equity"]) * cfg["single_limit"])
        if buy_cost > max_single:
            raise VirtualError(f"单笔金额 ¥{buy_cost:.2f} 超过上限 ¥{max_single:.2f}")
        if buy_cost > account["cash"]:
            raise VirtualError("虚拟现金不足")
        min_cash = _round2(account["equity"] * cfg["min_cash_ratio"])
        if account["cash"] - buy_cost < min_cash:
            raise VirtualError(f"需保留至少 {cfg['min_cash_ratio'] * 100:.0f}% 现金（¥{min_cash:.2f}）")

        now = _now()
        buy_snapshot = {
            k: quote.get(k) for k in (
                "ask", "bid", "ask_volume", "bid_volume", "daily_volume",
                "listed_count", "spread_pct", "vol7_pct", "liquidity_score",
                "fail_probability", "depth_source", "timestamp",
            )
        }
        intel = quote.get("market_intel") or {}
        buy_snapshot["market_intel"] = {
            k: intel.get(k) for k in (
                "weighted_ask", "weighted_fair", "divergence_pct", "source_count",
                "confidence", "lead_shock_z", "lead_shock_source", "lead_return_pct",
                "market_index", "market_change_pct", "sources",
            )
        }
        steam_shadow = quote.get("steam") or {"available": False}
        position = self.db.insert_position({
            "account_id": account["id"],
            "goods_id": goods_id,
            "market_hash_name": quote.get("market_hash_name") or market_hash_name,
            "item_name": quote["item_name"],
            "icon_url": quote.get("icon_url", ""),
            "exterior": quote.get("exterior", ""),
            "qty": qty,
            "ask": quote["ask"],
            "bid": quote["bid"],
            "ask_volume": quote["ask_volume"],
            "bid_volume": quote["bid_volume"],
            "daily_volume": quote["daily_volume"],
            "spread_pct": quote["spread_pct"],
            "buy_cost": buy_cost,
            "bought_at": _iso(now),
            "lock_until": _iso(now + timedelta(hours=LOCK_HOURS)),
            "buy_snapshot": buy_snapshot,
            "steam_shadow": steam_shadow,
            "fail_probability": quote["fail_probability"],
            "random_seed": uuid.uuid4().hex,
        })
        new_cash = _round2(account["cash"] - buy_cost)
        self.db.update_account_cash(account["id"], new_cash)
        self.db.add_ledger(account["id"], position["id"], "VIRTUAL_BUY", -buy_cost, new_cash,
                           f"模拟买入 {quote['item_name']} ×{qty}")
        return {
            "position": position,
            "account": self._account_view(self.db.get_account(account["id"])),
            "quote": quote,
        }

    # ---- settlement ----
    def settle_position(self, position_id: int) -> Dict:
        position = self.db.get_position(position_id)
        if not position:
            raise VirtualError("持仓不存在")
        if position["status"] in ("SOLD", "WRITTEN_OFF"):
            raise VirtualError("该持仓已结算")
        now = _now()
        lock_until = _parse_iso(position.get("lock_until"))
        if position["status"] == "LOCKED" and lock_until and lock_until > now:
            raise VirtualError("7 天锁定期未结束，不能结算")

        quote = self.get_quote(
            position["goods_id"],
            position.get("market_hash_name") or "",
            qty=int(position.get("qty") or 1),
            force=True,
        )
        qty = int(position.get("qty") or 1)
        bid = _to_float(quote.get("bid"))
        liquidity = calc_liquidity(quote, qty)
        fail_probability = calc_fail_probability(
            quote, qty, liquidity,
            lead_shock_z=_to_float((quote.get("market_intel") or {}).get("lead_shock_z")),
        )
        attempt = self.db.next_attempt(position_id)
        seed = f"{position.get('random_seed')}:{attempt}:{MODEL_VERSION}"
        u = deterministic_uniform(seed)
        buy_cost = _to_float(position.get("buy_cost"))
        steam_shadow = quote.get("steam") or json.loads(position.get("steam_shadow_json") or "{}")

        # 没有买盘：直接进入宽限期；宽限期后再无买盘则记无法变现。
        if bid <= 0:
            if position["status"] == "LOCKED":
                grace_until = now + timedelta(hours=GRACE_HOURS)
                self.db.update_position(position_id, status="GRACE", grace_until=_iso(grace_until),
                                        last_bid=0, fail_probability=1.0)
                row = self.db.insert_settlement({
                    "position_id": position_id, "attempt": attempt, "settle_at": _iso(now),
                    "exit_price": 0, "filled_qty": 0, "gross": 0, "sell_fee": 0,
                    "withdraw_fee": 0, "net": 0, "pnl": 0, "pnl_pct": 0,
                    "status": "NO_FILL", "reason": "T+7 无有效买盘，进入 24 小时宽限期",
                    "random_draw": u, "fail_probability": 1.0,
                    "liquidity_score": liquidity, "settle_snapshot": quote,
                    "steam_shadow": steam_shadow,
                })
                return {"settlement": row, "position": self.db.get_position(position_id)}

            self.db.update_position(position_id, status="WRITTEN_OFF", last_bid=0)
            self.db.add_ledger(position["account_id"], position_id, "VIRTUAL_WRITEOFF",
                               -buy_cost, self.db.get_account(position["account_id"])["cash"],
                               "宽限期后仍无买盘，虚拟价值记 0")
            row = self.db.insert_settlement({
                "position_id": position_id, "attempt": attempt, "settle_at": _iso(now),
                "exit_price": 0, "filled_qty": 0, "gross": 0, "sell_fee": 0,
                "withdraw_fee": 0, "net": 0, "pnl": -buy_cost,
                "pnl_pct": -100.0, "status": "WRITTEN_OFF",
                "reason": "宽限期后仍无买盘，虚拟价值记 0",
                "random_draw": u, "fail_probability": 1.0,
                "liquidity_score": liquidity, "settle_snapshot": quote,
                "steam_shadow": steam_shadow,
            })
            return {"settlement": row, "position": self.db.get_position(position_id)}

        # 随机失败：先进入宽限期；宽限期结束再失败则记无法变现。
        if u < fail_probability:
            if position["status"] == "LOCKED":
                grace_until = now + timedelta(hours=GRACE_HOURS)
                self.db.update_position(position_id, status="GRACE", grace_until=_iso(grace_until),
                                        last_bid=bid, fail_probability=fail_probability)
                reason = f"随机未成交（u={u:.4f} < p={fail_probability:.4f}），进入宽限期"
                row = self.db.insert_settlement({
                    "position_id": position_id, "attempt": attempt, "settle_at": _iso(now),
                    "exit_price": bid, "filled_qty": 0, "gross": 0, "sell_fee": 0,
                    "withdraw_fee": 0, "net": 0, "pnl": 0, "pnl_pct": 0,
                    "status": "NO_FILL", "reason": reason,
                    "random_draw": u, "fail_probability": fail_probability,
                    "liquidity_score": liquidity, "settle_snapshot": quote,
                    "steam_shadow": steam_shadow,
                })
                return {"settlement": row, "position": self.db.get_position(position_id)}

            self.db.update_position(position_id, status="WRITTEN_OFF", last_bid=bid)
            self.db.add_ledger(position["account_id"], position_id, "VIRTUAL_WRITEOFF",
                               -buy_cost, self.db.get_account(position["account_id"])["cash"],
                               "宽限期后仍随机未成交，虚拟价值记 0")
            row = self.db.insert_settlement({
                "position_id": position_id, "attempt": attempt, "settle_at": _iso(now),
                "exit_price": bid, "filled_qty": 0, "gross": 0, "sell_fee": 0,
                "withdraw_fee": 0, "net": 0, "pnl": -buy_cost, "pnl_pct": -100.0,
                "status": "WRITTEN_OFF", "reason": "宽限期后仍未能成交，虚拟价值记 0",
                "random_draw": u, "fail_probability": fail_probability,
                "liquidity_score": liquidity, "settle_snapshot": quote,
                "steam_shadow": steam_shadow,
            })
            return {"settlement": row, "position": self.db.get_position(position_id)}

        # 正常成交：按 bid 卖出，扣滑点与 BUFF 费用。
        slippage = calc_slippage(quote, qty)
        exit_price = _round2(bid * (1.0 - slippage))
        gross = _round2(exit_price * qty)
        sell_fee = _round2(gross * BUFF_SELL_FEE)
        withdraw_fee = _round2((gross - sell_fee) * BUFF_WITHDRAW_FEE)
        net = _round2(gross - sell_fee - withdraw_fee)
        pnl = _round2(net - buy_cost)
        pnl_pct = round(pnl / buy_cost * 100.0, 2) if buy_cost else 0.0

        self.db.update_position(position_id, status="SOLD", last_bid=bid,
                                fail_probability=fail_probability)
        account = self.db.get_account(position["account_id"])
        new_cash = _round2(_to_float(account.get("cash")) + net)
        self.db.update_account_cash(position["account_id"], new_cash)
        self.db.add_ledger(position["account_id"], position_id, "VIRTUAL_SELL", net, new_cash,
                           f"模拟卖出 {position.get('item_name')} ×{qty}")
        row = self.db.insert_settlement({
            "position_id": position_id, "attempt": attempt, "settle_at": _iso(now),
            "exit_price": exit_price, "filled_qty": qty, "gross": gross,
            "sell_fee": sell_fee, "withdraw_fee": withdraw_fee, "net": net,
            "pnl": pnl, "pnl_pct": pnl_pct, "status": "SOLD",
            "reason": f"正常成交，滑点 {slippage * 100:.2f}%",
            "random_draw": u, "fail_probability": fail_probability,
            "liquidity_score": liquidity, "settle_snapshot": quote,
            "steam_shadow": steam_shadow,
        })
        return {"settlement": row, "position": self.db.get_position(position_id)}

    def settle_due(self, limit: int = 3) -> List[Dict]:
        account = self.ensure_account(DEFAULT_TIER)
        now = _now()
        due = []
        for p in self.db.list_positions(account["id"], include_closed=False):
            lock_until = _parse_iso(p.get("lock_until"))
            grace_until = _parse_iso(p.get("grace_until"))
            if p["status"] == "LOCKED" and lock_until and lock_until <= now:
                due.append(p["id"])
            elif p["status"] == "GRACE" and grace_until and grace_until <= now:
                due.append(p["id"])
            if len(due) >= limit:
                break
        results = []
        for pid in due:
            try:
                results.append(self.settle_position(pid))
            except Exception as exc:
                logger.warning("自动结算 %s 失败: %s", pid, exc)
                results.append({"position_id": pid, "error": str(exc)})
        return results

    def history(self, limit: int = 50) -> Dict:
        account = self.ensure_account(DEFAULT_TIER)
        return {
            "account": account,
            "settlements": self.db.list_settlements(account["id"], limit=limit),
            "stats": self._stats(account["id"]),
        }

    # ---- history replay ----
    def replay(self, goods_id: str, market_hash_name: str = "",
              days: int = 30, qty: int = 1) -> Dict:
        """用 BUFF 历史价格序列回放“买入 → 锁 168 小时 → 卖出”。

        每个可入场的时间点都模拟一次，返回胜率/平均盈亏，并给出最近一个完整窗口的净值曲线。
        这里只做研究，不写账户、不写流水。
        """
        goods_id = str(goods_id or "").strip()
        if not goods_id:
            raise VirtualError("缺少 goods_id")
        qty = max(1, int(qty or 1))
        days = max(7, min(90, int(days or 30)))
        if not self.buff_fetcher:
            raise VirtualError("BUFF 数据源未初始化")
        try:
            series = self.buff_fetcher.fetch_goods_series(goods_id, days=days)
        except Exception as exc:
            raise VirtualError(f"获取历史价格失败：{exc}") from exc
        if not series or len(series) < 2:
            raise VirtualError("历史价格点不足，无法回放")

        # 去重并按时间升序
        clean = []
        seen = set()
        for p in series:
            ts = _to_int(p.get("ts"))
            price = _to_float(p.get("price"))
            if ts <= 0 or price <= 0 or ts in seen:
                continue
            seen.add(ts)
            clean.append({
                "ts": ts,
                "date": p.get("date") or "",
                "price": round(price, 2),
                "buy_max": round(_to_float(p.get("buy_max")), 2),
                "sell_num": max(0, _to_int(p.get("sell_num"))),
            })
        clean.sort(key=lambda x: x["ts"])
        if len(clean) < 2:
            raise VirtualError("历史价格点不足，无法回放")

        hold_ms = LOCK_HOURS * 3600 * 1000
        vol7 = _vol7_from_series([{"price": p["price"]} for p in clean])
        entries = []
        for i, entry in enumerate(clean):
            exit_idx = next((j for j in range(i + 1, len(clean))
                             if clean[j]["ts"] - entry["ts"] >= hold_ms), None)
            if exit_idx is None:
                continue
            exit_p = clean[exit_idx]
            ask = _to_float(exit_p.get("price"))
            bid = _to_float(exit_p.get("buy_max")) or round(ask * 0.95, 2)
            volume = max(0, _to_int(exit_p.get("sell_num")) or _to_int(entry.get("sell_num")))
            spread = 0.0
            if ask > 0 and bid > 0:
                spread = round(max(0.0, (ask - bid) / ((ask + bid) / 2.0) * 100.0), 2)
            q = {
                "ask": ask, "bid": bid, "ask_volume": max(1, volume),
                "bid_volume": max(1, min(20, volume // 10 or 1)),
                "daily_volume": volume, "listed_count": max(1, volume),
                "spread_pct": spread, "vol7_pct": vol7,
            }
            liq = calc_liquidity(q, qty)
            fail_p = calc_fail_probability(q, qty, liq, lead_shock_z=0.0)
            u = deterministic_uniform(
                f"replay:{goods_id}:{entry['ts']}:{exit_p['ts']}:{qty}:{MODEL_VERSION}"
            )
            buy_cost = _round2(entry["price"] * qty)
            if bid <= 0 or u < fail_p:
                status = "WRITTEN_OFF"
                exit_price = 0.0
                gross = sell_fee = withdraw_fee = net = 0.0
                pnl = -buy_cost
                pnl_pct = -100.0
                reason = "无买盘" if bid <= 0 else f"随机未成交 u={u:.4f} < p={fail_p:.4f}"
            else:
                status = "SOLD"
                slip = calc_slippage(q, qty)
                exit_price = _round2(bid * (1.0 - slip))
                gross = _round2(exit_price * qty)
                sell_fee = _round2(gross * BUFF_SELL_FEE)
                withdraw_fee = _round2((gross - sell_fee) * BUFF_WITHDRAW_FEE)
                net = _round2(gross - sell_fee - withdraw_fee)
                pnl = _round2(net - buy_cost)
                pnl_pct = round(pnl / buy_cost * 100.0, 2) if buy_cost else 0.0
                reason = f"正常成交，滑点 {slip * 100:.2f}%"
            entries.append({
                "entry_ts": entry["ts"], "exit_ts": exit_p["ts"],
                "entry_date": entry["date"], "exit_date": exit_p["date"],
                "entry_price": entry["price"], "exit_price": exit_price,
                "buy_cost": buy_cost, "gross": gross,
                "sell_fee": sell_fee, "withdraw_fee": withdraw_fee,
                "net": net, "pnl": pnl, "pnl_pct": pnl_pct,
                "status": status, "reason": reason,
                "fail_probability": fail_p, "liquidity": liq,
                "volume": volume, "spread_pct": spread,
            })

        if not entries:
            raise VirtualError("这段时间内没有完整的 168 小时窗口，增加回放天数")

        def curve_for(e):
            pts = []
            entry = next(x for x in clean if x["ts"] == e["entry_ts"])
            for p in clean:
                if p["ts"] < e["entry_ts"] or p["ts"] > e["exit_ts"]:
                    continue
                bid = p["buy_max"] or round(p["price"] * 0.95, 2)
                value = _round2(bid * qty)
                pts.append({
                    "ts": p["ts"], "date": p["date"],
                    "price": p["price"], "bid": round(bid, 2),
                    "market_value": value,
                    "pnl_pct": round((value - entry["price"] * qty) / (entry["price"] * qty) * 100.0, 2)
                    if entry["price"] else 0.0,
                })
            return pts

        last = entries[-1]
        curve = curve_for(last)
        sold = [e for e in entries if e["status"] == "SOLD"]
        failed = [e for e in entries if e["status"] == "WRITTEN_OFF"]
        avg_pnl = round(sum(e["pnl_pct"] for e in entries) / len(entries), 2)
        win_rate = round(len(sold) / len(entries) * 100.0, 2) if entries else 0.0
        best = max(entries, key=lambda x: x["pnl_pct"])
        worst = min(entries, key=lambda x: x["pnl_pct"])
        peak = 0.0
        max_dd = 0.0
        for p in curve:
            peak = max(peak, p["pnl_pct"])
            max_dd = min(max_dd, p["pnl_pct"] - peak)
        return {
            "goods_id": goods_id,
            "market_hash_name": market_hash_name,
            "days": days,
            "hold_hours": LOCK_HOURS,
            "qty": qty,
            "source": "buff_price_history",
            "series_points": len(clean),
            "window": {"entry": last["entry_date"], "exit": last["exit_date"]},
            "summary": {
                "samples": len(entries),
                "sold": len(sold),
                "failed": len(failed),
                "win_rate": win_rate,
                "avg_pnl_pct": avg_pnl,
                "best_pnl_pct": best["pnl_pct"],
                "worst_pnl_pct": worst["pnl_pct"],
                "max_drawdown_pct": round(max_dd, 2),
            },
            "curve": curve,
            "entries": entries[-12:],
            "note": "历史回放只研究历史价格序列，不写入虚拟账户，也不代表未来收益。",
        }
