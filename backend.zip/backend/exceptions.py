"""
CS饰品交易数据分析系统 - 自定义异常模块
"""

from typing import Optional


class BaseTradingError(Exception):
    """所有交易异常的基类"""
    pass


class DataFetchError(BaseTradingError):
    """数据采集失败异常"""
    def __init__(self, message: str, status_code: Optional[int] = None, retry_count: int = 0):
        self.status_code = status_code
        self.retry_count = retry_count
        super().__init__(f"[数据采集失败] {message} (状态码: {status_code}, 重试次数: {retry_count})")


class RiskAnalysisError(BaseTradingError):
    """风险分析异常"""
    def __init__(self, message: str, item_name: Optional[str] = None):
        self.item_name = item_name
        detail = f" (饰品: {item_name})" if item_name else ""
        super().__init__(f"[风险分析失败] {message}{detail}")


class DecisionError(BaseTradingError):
    """采购决策异常"""
    def __init__(self, message: str, decision_params: Optional[dict] = None):
        self.decision_params = decision_params or {}
        super().__init__(f"[决策异常] {message}")


class APIRateLimitError(BaseTradingError):
    """API频率限制异常"""
    def __init__(self, message: str, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(f"[频率限制] {message} (请在 {retry_after} 秒后重试)")


class AuthenticationError(BaseTradingError):
    """认证失败异常"""
    def __init__(self, message: str = "认证失败"):
        super().__init__(f"[认证错误] {message}")


class DatabaseError(BaseTradingError):
    """数据库操作异常"""
    def __init__(self, message: str, operation: Optional[str] = None):
        self.operation = operation
        detail = f" (操作: {operation})" if operation else ""
        super().__init__(f"[数据库错误] {message}{detail}")


class TradeExecutionError(BaseTradingError):
    """交易执行异常"""
    def __init__(self, message: str, order_info: Optional[dict] = None):
        self.order_info = order_info or {}
        super().__init__(f"[交易执行失败] {message}")


class InsufficientBalanceError(TradeExecutionError):
    """余额不足异常"""
    def __init__(self, required: float, available: float, platform: str = ""):
        self.required = required
        self.available = available
        super().__init__(
            f"余额不足: 需要 ¥{required:,.2f}，可用 ¥{available:,.2f}"
            + (f" ({platform})" if platform else ""),
            order_info={'required': required, 'available': available, 'platform': platform}
        )
