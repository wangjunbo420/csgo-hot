"""
阶段3：自动化采购决策引擎
【核心功能】平衡响应速度与误判风险，强制人工复核环节
"""

import sqlite3
import struct
import logging
from typing import Dict, List, Optional
from datetime import datetime, timedelta

from config import TradeConfig
from exceptions import DecisionError, DatabaseError

logger = logging.getLogger(__name__)


class TradeDatabase:
    """交易决策数据库管理"""

    def __init__(self, db_path: str = TradeConfig.DATABASE_PATH):
        self.db_path = db_path
        self._init_db()

    def _get_conn(self):
        """获取带 WAL 模式和超时配置的数据库连接"""
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def get_executions(self, limit: int = 20) -> List[Dict]:
        """获取执行记录（决策确认 / 下单 / 拒绝等操作留痕）"""
        try:
            with sqlite3.connect(self.db_path, timeout=30) as conn:
                conn.text_factory = str
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT e.id, e.decision_id, e.action, e.timestamp, e.details,
                           d.item_name, d.current_price
                    FROM execution_log e
                    LEFT JOIN trade_decisions d ON d.id = e.decision_id
                    ORDER BY e.id DESC
                    LIMIT ?
                ''', (limit,))
                columns = [desc[0] for desc in cursor.description]
                rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
                for row in rows:
                    try:
                        row['current_price'] = float(row.get('current_price') or 0)
                    except (TypeError, ValueError):
                        row['current_price'] = 0.0
                return rows
        except sqlite3.Error as e:
            raise DatabaseError(f"获取执行记录失败: {e}", operation="get_executions")

    def _init_db(self):
        """初始化数据库表"""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS trade_decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    current_price REAL NOT NULL,
                    suggested_quantity INTEGER NOT NULL,
                    stop_loss_price REAL NOT NULL,
                    risk_level TEXT NOT NULL,
                    price_deviation REAL NOT NULL,
                    decision_status TEXT NOT NULL DEFAULT 'pending',
                    notes TEXT,
                    created_at TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS execution_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    decision_id INTEGER NOT NULL,
                    action TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    details TEXT,
                    FOREIGN KEY (decision_id) REFERENCES trade_decisions(id)
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS trade_orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    decision_id INTEGER,
                    platform TEXT NOT NULL,
                    order_type TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    price REAL NOT NULL,
                    quantity INTEGER NOT NULL,
                    order_id TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    error_message TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (decision_id) REFERENCES trade_decisions(id)
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS positions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    platform TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    asset_id TEXT,
                    buy_price REAL NOT NULL,
                    quantity INTEGER NOT NULL,
                    buy_date TEXT NOT NULL,
                    min_sell_date TEXT,
                    sell_order_id TEXT,
                    status TEXT NOT NULL DEFAULT 'holding',
                    pnl REAL DEFAULT 0,
                    created_at TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS delivery_orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    buff_order_id TEXT NOT NULL UNIQUE,
                    item_name TEXT NOT NULL,
                    asset_id TEXT,
                    buyer_name TEXT,
                    price REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    delivery_method TEXT NOT NULL DEFAULT 'auto',
                    steam_trade_offer_id TEXT,
                    error_message TEXT,
                    detected_at TEXT NOT NULL,
                    accepted_at TEXT,
                    delivered_at TEXT,
                    created_at TEXT NOT NULL
                )
            ''')
            conn.commit()
            logger.info(f"数据库初始化完成: {self.db_path}")

    def save_decision(self, decision: Dict) -> int:
        """保存采购决策到数据库"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                # 强制类型转换，避免 SQLite 将数值存为 blob
                current_price = float(decision['price']) if decision['price'] is not None else 0.0
                stop_loss = float(decision['stop_loss']) if decision.get('stop_loss') is not None else 0.0
                quantity = int(decision['quantity']) if decision.get('quantity') is not None else 0
                price_deviation = float(decision['price_deviation']) if decision.get('price_deviation') is not None else 0.0

                cursor.execute('''
                    INSERT INTO trade_decisions
                    (timestamp, item_name, current_price, suggested_quantity,
                     stop_loss_price, risk_level, price_deviation, decision_status, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    str(decision['timestamp']),
                    str(decision['item']),
                    current_price,
                    quantity,
                    stop_loss,
                    str(decision['risk_level']),
                    price_deviation,
                    str(decision.get('status', 'pending')),
                    str(decision.get('reason', '')),
                    datetime.now().isoformat(),
                ))
                decision_id = cursor.lastrowid
                conn.commit()
                logger.info(f"决策已保存，ID: {decision_id}")
                return decision_id
        except sqlite3.Error as e:
            raise DatabaseError(f"保存决策失败: {e}", operation="save_decision")

    def log_execution(self, decision_id: int, action: str, details: Optional[str] = None):
        """记录执行日志"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO execution_log (decision_id, action, timestamp, details)
                    VALUES (?, ?, ?, ?)
                ''', (decision_id, action, datetime.now().isoformat(), details))
                conn.commit()
        except sqlite3.Error as e:
            raise DatabaseError(f"记录执行日志失败: {e}", operation="log_execution")

    def save_order(self, order: Dict) -> int:
        """保存订单记录"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO trade_orders
                    (decision_id, platform, order_type, item_name, price, quantity,
                     order_id, status, error_message, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    order.get('decision_id'),
                    str(order['platform']),
                    str(order['order_type']),
                    str(order['item_name']),
                    float(order['price']),
                    int(order['quantity']),
                    order.get('order_id', ''),
                    str(order.get('status', 'pending')),
                    order.get('error_message', ''),
                    datetime.now().isoformat(),
                    datetime.now().isoformat(),
                ))
                order_id = cursor.lastrowid
                conn.commit()
                logger.info(f"订单已保存，ID: {order_id}")
                return order_id
        except sqlite3.Error as e:
            raise DatabaseError(f"保存订单失败: {e}", operation="save_order")

    def update_order_status(self, order_pk: int, status: str,
                            order_id: str = None, error_message: str = None):
        """更新订单状态"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                if order_id is not None:
                    cursor.execute('''
                        UPDATE trade_orders
                        SET status = ?, order_id = ?, error_message = ?, updated_at = ?
                        WHERE id = ?
                    ''', (status, order_id, error_message or '',
                          datetime.now().isoformat(), order_pk))
                else:
                    cursor.execute('''
                        UPDATE trade_orders
                        SET status = ?, error_message = ?, updated_at = ?
                        WHERE id = ?
                    ''', (status, error_message or '',
                          datetime.now().isoformat(), order_pk))
                conn.commit()
                logger.info(f"订单 {order_pk} 状态更新为: {status}")
        except sqlite3.Error as e:
            raise DatabaseError(f"更新订单状态失败: {e}", operation="update_order_status")

    def claim_decision_for_execution(self, decision_id: int) -> bool:
        """原子抢占决策用于执行：仅当 decision_status='confirmed' 时置为 'executing'。

        返回是否抢占成功（受影响行数==1）。用于防止同一 confirmed 决策被重复买入：
        并发或超时重试场景下只有第一个调用能抢到，其余返回 False。
        """
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE trade_decisions
                    SET decision_status = 'executing'
                    WHERE id = ? AND decision_status = 'confirmed'
                ''', (decision_id,))
                conn.commit()
                return cursor.rowcount == 1
        except sqlite3.Error as e:
            raise DatabaseError(
                f"抢占决策失败: {e}", operation="claim_decision_for_execution"
            )

    def set_decision_status(self, decision_id: int, status: str,
                            expect: str = None) -> bool:
        """更新决策状态。expect 非空时仅当当前状态==expect 才更新（乐观锁/状态机）。

        返回是否更新成功（受影响行数==1）。
        """
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                if expect is not None:
                    cursor.execute('''
                        UPDATE trade_decisions
                        SET decision_status = ?
                        WHERE id = ? AND decision_status = ?
                    ''', (status, decision_id, expect))
                else:
                    cursor.execute('''
                        UPDATE trade_decisions
                        SET decision_status = ?
                        WHERE id = ?
                    ''', (status, decision_id))
                conn.commit()
                return cursor.rowcount == 1
        except sqlite3.Error as e:
            raise DatabaseError(
                f"更新决策状态失败: {e}", operation="set_decision_status"
            )

    def get_orders(self, status: str = None, platform: str = None,
                   limit: int = 50) -> List[Dict]:
        """查询订单列表"""
        try:
            with self._get_conn() as conn:
                conn.text_factory = str
                cursor = conn.cursor()
                query = 'SELECT * FROM trade_orders WHERE 1=1'
                params = []
                if status:
                    query += ' AND status = ?'
                    params.append(status)
                if platform:
                    query += ' AND platform = ?'
                    params.append(platform)
                query += ' ORDER BY created_at DESC LIMIT ?'
                params.append(limit)
                cursor.execute(query, params)
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except sqlite3.Error as e:
            raise DatabaseError(f"查询订单失败: {e}", operation="get_orders")

    def save_position(self, position: Dict) -> int:
        """保存持仓记录"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO positions
                    (platform, item_name, asset_id, buy_price, quantity,
                     buy_date, min_sell_date, sell_order_id, status, pnl, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    str(position['platform']),
                    str(position['item_name']),
                    position.get('asset_id', ''),
                    float(position['buy_price']),
                    int(position['quantity']),
                    str(position['buy_date']),
                    position.get('min_sell_date', ''),
                    position.get('sell_order_id', ''),
                    str(position.get('status', 'holding')),
                    float(position.get('pnl', 0)),
                    datetime.now().isoformat(),
                ))
                pos_id = cursor.lastrowid
                conn.commit()
                logger.info(f"持仓已保存，ID: {pos_id}")
                return pos_id
        except sqlite3.Error as e:
            raise DatabaseError(f"保存持仓失败: {e}", operation="save_position")

    def update_position(self, position_pk: int, **kwargs):
        """更新持仓记录字段"""
        try:
            allowed = {'sell_order_id', 'status', 'pnl', 'asset_id'}
            updates = {k: v for k, v in kwargs.items() if k in allowed}
            if not updates:
                return
            set_clause = ', '.join(f'{k} = ?' for k in updates)
            values = list(updates.values())
            values.append(position_pk)
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    f'UPDATE positions SET {set_clause} WHERE id = ?', values
                )
                conn.commit()
                logger.info(f"持仓 {position_pk} 已更新: {updates}")
        except sqlite3.Error as e:
            raise DatabaseError(f"更新持仓失败: {e}", operation="update_position")

    def get_positions(self, status: str = None, platform: str = None,
                      limit: int = 50) -> List[Dict]:
        """查询持仓列表"""
        try:
            with self._get_conn() as conn:
                conn.text_factory = str
                cursor = conn.cursor()
                query = 'SELECT * FROM positions WHERE 1=1'
                params = []
                if status:
                    query += ' AND status = ?'
                    params.append(status)
                if platform:
                    query += ' AND platform = ?'
                    params.append(platform)
                query += ' ORDER BY created_at DESC LIMIT ?'
                params.append(limit)
                cursor.execute(query, params)
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except sqlite3.Error as e:
            raise DatabaseError(f"查询持仓失败: {e}", operation="get_positions")

    # ── 发货记录 ──────────────────────────────────────────────

    def save_delivery(self, delivery: Dict) -> int:
        """保存发货记录"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO delivery_orders
                    (buff_order_id, item_name, asset_id, buyer_name, price,
                     status, delivery_method, steam_trade_offer_id, error_message,
                     detected_at, accepted_at, delivered_at, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    str(delivery['buff_order_id']),
                    str(delivery['item_name']),
                    delivery.get('asset_id', ''),
                    delivery.get('buyer_name', ''),
                    float(delivery['price']),
                    str(delivery.get('status', 'pending')),
                    str(delivery.get('delivery_method', 'auto')),
                    delivery.get('steam_trade_offer_id', ''),
                    delivery.get('error_message', ''),
                    delivery.get('detected_at', datetime.now().isoformat()),
                    delivery.get('accepted_at', ''),
                    delivery.get('delivered_at', ''),
                    datetime.now().isoformat(),
                ))
                delivery_pk = cursor.lastrowid
                conn.commit()
                logger.info(f"发货记录已保存，ID: {delivery_pk}")
                return delivery_pk
        except sqlite3.IntegrityError:
            # buff_order_id UNIQUE 冲突 → 已存在
            existing = self.get_delivery_by_buff_order_id(delivery['buff_order_id'])
            return existing['id'] if existing else 0
        except sqlite3.Error as e:
            raise DatabaseError(f"保存发货记录失败: {e}", operation="save_delivery")

    def update_delivery_status(self, delivery_pk: int, status: str, **kwargs):
        """更新发货状态"""
        try:
            allowed = {'status', 'steam_trade_offer_id', 'error_message',
                       'accepted_at', 'delivered_at'}
            updates = {'status': status}
            updates.update({k: v for k, v in kwargs.items() if k in allowed})
            set_clause = ', '.join(f'{k} = ?' for k in updates)
            values = list(updates.values())
            values.append(delivery_pk)
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    f'UPDATE delivery_orders SET {set_clause} WHERE id = ?', values
                )
                conn.commit()
                logger.info(f"发货记录 {delivery_pk} 状态更新为: {status}")
        except sqlite3.Error as e:
            raise DatabaseError(f"更新发货状态失败: {e}", operation="update_delivery_status")

    def get_deliveries(self, status: str = None, limit: int = 50) -> List[Dict]:
        """查询发货记录"""
        try:
            with self._get_conn() as conn:
                conn.text_factory = str
                cursor = conn.cursor()
                query = 'SELECT * FROM delivery_orders WHERE 1=1'
                params = []
                if status:
                    query += ' AND status = ?'
                    params.append(status)
                query += ' ORDER BY created_at DESC LIMIT ?'
                params.append(limit)
                cursor.execute(query, params)
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except sqlite3.Error as e:
            raise DatabaseError(f"查询发货记录失败: {e}", operation="get_deliveries")

    def get_delivery_by_buff_order_id(self, buff_order_id: str) -> Optional[Dict]:
        """按 BUFF 订单号查询发货记录"""
        try:
            with self._get_conn() as conn:
                conn.text_factory = str
                cursor = conn.cursor()
                cursor.execute(
                    'SELECT * FROM delivery_orders WHERE buff_order_id = ?',
                    (str(buff_order_id),)
                )
                row = cursor.fetchone()
                if not row:
                    return None
                columns = [desc[0] for desc in cursor.description]
                return dict(zip(columns, row))
        except sqlite3.Error as e:
            raise DatabaseError(f"查询发货记录失败: {e}",
                                operation="get_delivery_by_buff_order_id")

    def get_delivery_stats(self) -> Dict:
        """获取发货统计"""
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    'SELECT status, COUNT(*) FROM delivery_orders GROUP BY status'
                )
                stats = {row[0]: row[1] for row in cursor.fetchall()}
                stats['total'] = sum(stats.values())
                return stats
        except sqlite3.Error as e:
            raise DatabaseError(f"获取发货统计失败: {e}", operation="get_delivery_stats")


class TradeDecisionEngine:
    """
    采购决策引擎

    决策规则:
    1. 仅当 风险评级="超跌机会" 且 价格偏离度 < -20% 时触发采购
    2. 采购量 = 总资金 * 2% / (当前价 * 10%)
    3. 采购前必须等待人工确认
    4. 所有操作记录存入 SQLite
    """

    def __init__(self, total_capital: float, config: TradeConfig = None):
        self.total_capital = total_capital
        self.config = config or TradeConfig()
        self.db = TradeDatabase(self.config.DATABASE_PATH)
        logger.info(f"决策引擎初始化，总资金: ¥{total_capital:,.2f}")

    def make_decision(self, risk_analysis: Dict, item_name: str,
                      current_price: float) -> Dict:
        """
        生成采购决策

        Returns:
            采购建议字典，包含 item, price, quantity, stop_loss, status 等
        """
        try:
            risk_level = risk_analysis['risk_level']
            price_deviation = risk_analysis['price_deviation']

            if not self._should_trade(risk_level, price_deviation):
                return self._create_no_trade_decision(
                    item_name, current_price, risk_level, price_deviation,
                    risk_analysis.get('reason', '')
                )

            quantity = self._calculate_quantity(current_price)
            stop_loss = self._calculate_stop_loss(current_price)
            min_sell_date = (datetime.now() + timedelta(days=self.config.T_PLUS_7_DAYS)).strftime('%Y-%m-%d')

            reason = (
                f"7日均价{risk_analysis.get('avg_price_7d', 'N/A')} → "
                f"当前价偏离{price_deviation * 100:.1f}%，"
                f"求购深度{risk_analysis.get('buy_depth', 'N/A')}x"
            )

            decision = {
                'item': item_name,
                'price': current_price,
                'quantity': quantity,
                'stop_loss': stop_loss,
                'risk_level': risk_level,
                'price_deviation': price_deviation,
                'reason': reason,
                'status': 'pending_manual_confirm',
                'timestamp': datetime.now().isoformat(),
                'min_sell_date': min_sell_date,
                'total_investment': round(current_price * quantity, 2),
                'max_loss': round((current_price - stop_loss) * quantity, 2),
            }

            # 显式安全校验（替代 assert）
            if decision['quantity'] <= 0:
                raise DecisionError("采购数量必须大于0", {'item': item_name})
            if decision['stop_loss'] >= decision['price']:
                raise DecisionError("止损价必须低于当前价", {'item': item_name})
            max_investment = self.total_capital * self.config.MAX_LOSS_RATE * 10
            if decision['total_investment'] > max_investment:
                raise DecisionError(
                    f"投资金额 ¥{decision['total_investment']:,.2f} 超出风险限制 ¥{max_investment:,.2f}",
                    {'item': item_name}
                )

            decision_id = self.db.save_decision(decision)
            decision['id'] = decision_id
            self.db.log_execution(decision_id, 'DECISION_CREATED', "生成采购建议")

            logger.info(f"采购决策已生成: {decision}")
            return decision

        except DecisionError:
            raise
        except KeyError as e:
            raise DecisionError(f"缺少必要字段: {e}", risk_analysis)
        except Exception as e:
            raise DecisionError(f"决策生成失败: {e}", {
                'item': item_name,
                'price': current_price,
                'risk_analysis': risk_analysis,
            })

    def _should_trade(self, risk_level: str, price_deviation: float) -> bool:
        """仅当 风险评级="超跌机会" 且 偏离度 < -20% 时返回 True"""
        if risk_level != '超跌机会':
            logger.info(f"风险等级为'{risk_level}'，不满足交易条件")
            return False
        if price_deviation >= self.config.MIN_DEVIATION_FOR_TRADE:
            logger.info(
                f"价格偏离度{price_deviation * 100:.1f}%"
                f"未达到阈值{self.config.MIN_DEVIATION_FOR_TRADE * 100:.1f}%"
            )
            return False
        return True

    def _calculate_quantity(self, current_price: float) -> int:
        """采购量 = 总资金 * 2% / (当前价 * 10%)"""
        if current_price <= 0:
            raise DecisionError(f"当前价格无效: {current_price}")
        if self.total_capital <= 0:
            raise DecisionError(f"总资金无效: {self.total_capital}")

        max_risk_amount = self.total_capital * self.config.MAX_LOSS_RATE
        risk_per_unit = current_price * self.config.STOP_LOSS_SPACE
        quantity = int(max_risk_amount / risk_per_unit)
        quantity = max(1, quantity)

        logger.info(
            f"采购量计算: ¥{self.total_capital:,.2f} × {self.config.MAX_LOSS_RATE * 100}% "
            f"÷ (¥{current_price:,.2f} × {self.config.STOP_LOSS_SPACE * 100}%) = {quantity}件"
        )
        return quantity

    def _calculate_stop_loss(self, current_price: float) -> float:
        """止损价 = 当前价 * (1 - 10%)"""
        stop_loss = round(current_price * (1 - self.config.STOP_LOSS_SPACE), 2)
        logger.info(f"止损价计算: ¥{current_price:,.2f} × 0.9 = ¥{stop_loss:,.2f}")
        return stop_loss

    def _create_no_trade_decision(self, item_name: str, current_price: float,
                                  risk_level: str, price_deviation: float,
                                  reason: str) -> Dict:
        """创建不交易决策记录"""
        decision = {
            'item': item_name,
            'price': current_price,
            'quantity': 0,
            'stop_loss': 0,
            'risk_level': risk_level,
            'price_deviation': price_deviation,
            'reason': reason,
            'status': 'no_trade',
            'timestamp': datetime.now().isoformat(),
            'min_sell_date': None,
            'total_investment': 0,
            'max_loss': 0,
        }
        decision_id = self.db.save_decision(decision)
        decision['id'] = decision_id
        logger.info(f"不交易决策: {item_name}, 原因: {reason}")
        return decision

    def confirm_manual(self, decision_id: int, confirmed: bool,
                       notes: Optional[str] = None) -> Dict:
        """
        人工确认/拒绝采购决策（原子操作：更新状态 + 写入日志在同一事务中）
        """
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                cursor = conn.cursor()

                # 查询决策
                cursor.execute('SELECT id FROM trade_decisions WHERE id = ?', (decision_id,))
                if not cursor.fetchone():
                    raise DecisionError(f"决策ID {decision_id} 不存在")

                new_status = 'confirmed' if confirmed else 'rejected'
                now = datetime.now().isoformat()

                # 更新状态
                cursor.execute('''
                    UPDATE trade_decisions
                    SET decision_status = ?, notes = ?
                    WHERE id = ?
                ''', (new_status, notes, decision_id))

                # 同一事务中写入执行日志
                action = 'MANUAL_CONFIRMED' if confirmed else 'MANUAL_REJECTED'
                cursor.execute('''
                    INSERT INTO execution_log (decision_id, action, timestamp, details)
                    VALUES (?, ?, ?, ?)
                ''', (decision_id, action, now, notes))

                conn.commit()

            logger.info(f"决策 {decision_id} 已{'确认' if confirmed else '拒绝'}")
            return {
                'id': decision_id,
                'status': new_status,
                'confirmed_at': now,
                'notes': notes,
            }

        except DecisionError:
            raise
        except sqlite3.Error as e:
            raise DatabaseError(f"确认决策失败: {e}", operation="confirm_manual")

    def get_decision_history(self, limit: int = 10) -> List[Dict]:
        """获取历史决策记录"""
        try:
            with sqlite3.connect(self.db.db_path) as conn:
                conn.text_factory = str  # 强制返回 str
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM trade_decisions
                    ORDER BY created_at DESC
                    LIMIT ?
                ''', (limit,))

                columns = [desc[0] for desc in cursor.description]
                results = []
                for row in cursor.fetchall():
                    record = dict(zip(columns, row))
                    record = self._sanitize_record(record)
                    results.append(record)
                return results

        except sqlite3.Error as e:
            raise DatabaseError(f"获取历史记录失败: {e}", operation="get_decision_history")

    @staticmethod
    def _sanitize_record(record: Dict) -> Dict:
        """清洗单条记录，修复数据库中可能存在的脏数据"""
        # 修复 numeric 字段（current_price / stop_loss_price 可能被存为 blob）
        for field in ('current_price', 'stop_loss_price'):
            val = record.get(field)
            if isinstance(val, bytes):
                try:
                    if len(val) == 8:
                        record[field] = float(struct.unpack('<d', val)[0])
                    else:
                        record[field] = 0.0
                except Exception:
                    record[field] = 0.0
            elif val is None:
                record[field] = 0.0
            else:
                try:
                    record[field] = float(val)
                except (TypeError, ValueError):
                    record[field] = 0.0

        # 修复整数/其他可能为 bytes 的字段
        for field in ('suggested_quantity',):
            val = record.get(field)
            if isinstance(val, bytes):
                try:
                    record[field] = int.from_bytes(val, 'little') if len(val) <= 8 else 0
                except Exception:
                    record[field] = 0
            elif val is None:
                record[field] = 0
            else:
                try:
                    record[field] = int(val)
                except (TypeError, ValueError):
                    record[field] = 0

        # 确保文本字段是 str 类型
        for field in ('timestamp', 'item_name', 'risk_level', 'decision_status', 'notes', 'created_at'):
            val = record.get(field)
            if isinstance(val, bytes):
                try:
                    record[field] = val.decode('utf-8', errors='replace')
                except Exception:
                    record[field] = ''
            elif val is None:
                record[field] = ''

        return record
