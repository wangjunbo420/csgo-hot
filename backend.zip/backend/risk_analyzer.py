"""
阶段2：风险评级算法模块
【核心功能】区分真实超跌与庄家砸盘，提供可验证的量化指标
"""

import logging
from typing import Dict, Optional
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

from config import RiskConfig
from exceptions import RiskAnalysisError

# 配置日志
logger = logging.getLogger(__name__)


class RiskAnalyzer:
    """
    饰品风险评级器
    
    【核心指标】
    1. 价格偏离度 = (当前价 - 7日均价) / 7日均价
    2. 流动性评分 = 近24小时成交量 / 近7日日均成交量
    3. 求购深度 = 求购价总量 / 当前最低售价
    
    【判定规则】
    - 价格偏离度 < -0.15 且 流动性评分 > 1.2 → "超跌机会"
    - 价格偏离度 < -0.1 且 求购深度 < 0.3 → "做盘风险"
    - 其他情况 → "观望"
    """
    
    def __init__(self, config: RiskConfig = None):
        self.config = config or RiskConfig()
    
    def analyze(self, df: pd.DataFrame) -> Dict:
        """
        对饰品数据进行风险评级
        
        Args:
            df: Pandas DataFrame，包含字段：
                - timestamp: 时间戳
                - price: 价格
                - volume: 成交量
                - buy_orders: 求购订单量
                - current_price: 当前最低售价（可选）
                - buy_order_price: 求购价（可选）
                
        Returns:
            风险分析结果字典:
            {
                "risk_level": "超跌机会" | "做盘风险" | "观望",
                "price_deviation": -0.167,        # 价格偏离度
                "liquidity_score": 1.35,           # 流动性评分
                "buy_depth": 1.5,                  # 求购深度
                "reason": "价格偏离-16.7%，流动性充足",
                "timestamp": "2026-05-13T10:30:00"
            }
            
        Raises:
            RiskAnalysisError: 分析失败时抛出
        """
        try:
            # 数据验证
            self._validate_dataframe(df)
            
            # 计算关键指标
            metrics = self._calculate_metrics(df)
            
            # 风险判定
            risk_level, reason = self._determine_risk(metrics)
            
            result = {
                'risk_level': risk_level,
                'price_deviation': metrics['price_deviation'],
                'liquidity_score': metrics['liquidity_score'],
                'buy_depth': metrics['buy_depth'],
                'reason': reason,
                'timestamp': datetime.now().isoformat()
            }
            
            # 显式输出校验（替代 assert，确保 -O 模式下仍然生效）
            valid_levels = ['超跌机会', '做盘风险', '观望']
            if result['risk_level'] not in valid_levels:
                raise RiskAnalysisError(f"风险等级无效: {result['risk_level']}")
            if not (-1.0 <= result['price_deviation'] <= 1.0):
                raise RiskAnalysisError(f"价格偏离度超出合理范围: {result['price_deviation']}")
            if result['liquidity_score'] < 0:
                raise RiskAnalysisError(f"流动性评分为负: {result['liquidity_score']}")
            
            logger.info(f"风险分析完成: {result}")
            return result
            
        except RiskAnalysisError:
            raise
        except Exception as e:
            raise RiskAnalysisError(f"分析过程异常: {str(e)}")
    
    def _validate_dataframe(self, df: pd.DataFrame):
        """验证DataFrame数据完整性"""
        required_columns = ['timestamp', 'price', 'volume']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            raise RiskAnalysisError(f"缺少必要字段: {missing_columns}")
        
        if df.empty:
            raise RiskAnalysisError("DataFrame为空")
        
        if len(df) < 2:
            raise RiskAnalysisError("数据点不足，至少需要2条记录")
    
    def _calculate_metrics(self, df: pd.DataFrame) -> Dict:
        """
        计算关键风险指标
        
        Args:
            df: 价格数据DataFrame
            
        Returns:
            指标字典
        """
        # 确保时间戳为datetime类型
        df = df.copy()
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        # 获取最新数据点
        latest = df.iloc[-1]
        current_price = latest['price']
        
        # 1. 计算7日均价
        if 'current_price' in df.columns:
            current_price = latest['current_price']
        
        seven_days_ago = df['timestamp'].max() - timedelta(days=7)
        df_7d = df[df['timestamp'] >= seven_days_ago]
        avg_price_7d = df_7d['price'].mean()
        
        # 价格偏离度 = (当前价 - 7日均价) / 7日均价
        if avg_price_7d > 0:
            price_deviation = (current_price - avg_price_7d) / avg_price_7d
        else:
            price_deviation = 0.0
            logger.warning("7日均价为0，价格偏离度设为0")
        
        # 2. 计算流动性评分
        # 近24小时成交量
        one_day_ago = df['timestamp'].max() - timedelta(days=1)
        df_24h = df[df['timestamp'] >= one_day_ago]
        volume_24h = df_24h['volume'].sum()
        
        # 近7日日均成交量（总量/7天，而非数据点均值）
        volume_7d_daily = df_7d['volume'].sum() / 7

        # 流动性评分 = 近24小时成交量 / 近7日日均成交量
        liquidity_score = volume_24h / volume_7d_daily if volume_7d_daily > 0 else 0
        
        # 3. 计算求购深度
        if 'buy_orders' in df.columns and 'buy_order_price' in df.columns:
            total_buy_orders = df_24h['buy_orders'].sum()
            buy_order_price = latest.get('buy_order_price', current_price)
            # 求购深度 = 求购价总量 / 当前最低售价
            buy_depth = (total_buy_orders * buy_order_price) / current_price if current_price > 0 else 0
        else:
            # 如果没有求购数据，使用默认值
            buy_depth = 1.0
        
        return {
            'price_deviation': round(price_deviation, 4),
            'liquidity_score': round(liquidity_score, 4),
            'buy_depth': round(buy_depth, 4),
            'current_price': current_price,
            'avg_price_7d': round(avg_price_7d, 2),
            'volume_24h': volume_24h,
            'volume_7d_avg': round(volume_7d_daily, 2)
        }
    
    def _determine_risk(self, metrics: Dict) -> tuple:
        """
        根据指标判定风险等级
        【严格遵循判定规则】
        
        Args:
            metrics: 计算出的指标字典
            
        Returns:
            (风险等级, 原因说明)
        """
        price_deviation = metrics['price_deviation']
        liquidity_score = metrics['liquidity_score']
        buy_depth = metrics['buy_depth']
        
        # 规则1: 超跌机会
        # 价格偏离度 < -0.15 且 流动性评分 > 1.2
        if (price_deviation < self.config.OVERSOLD_THRESHOLD and 
            liquidity_score > self.config.HIGH_LIQUIDITY_THRESHOLD):
            reason = (
                f"价格偏离{price_deviation*100:.1f}%，"
                f"流动性评分{liquidity_score:.2f}，"
                f"求购深度{buy_depth:.2f}x"
            )
            return '超跌机会', reason
        
        # 规则2: 做盘风险
        # 价格偏离度 < -0.1 且 求购深度 < 0.3
        if (price_deviation < self.config.MANIPULATION_THRESHOLD and 
            buy_depth < self.config.LOW_BUY_DEPTH_THRESHOLD):
            reason = (
                f"价格偏离{price_deviation*100:.1f}%，"
                f"求购深度骤降至{buy_depth:.2f}，疑似庄家砸盘"
            )
            return '做盘风险', reason
        
        # 规则3: 观望
        reason = (
            f"价格偏离{price_deviation*100:.1f}%，"
            f"流动性评分{liquidity_score:.2f}，"
            f"不满足交易条件"
        )
        return '观望', reason


def create_test_dataframe() -> pd.DataFrame:
    """创建测试数据DataFrame"""
    data = [
        {
            'timestamp': '2026-05-10 10:00:00',
            'price': 1200.0,
            'volume': 150,
            'buy_orders': 50,
            'buy_order_price': 1150.0
        },
        {
            'timestamp': '2026-05-11 10:00:00',
            'price': 1100.0,
            'volume': 200,
            'buy_orders': 30,
            'buy_order_price': 1000.0
        },
    ]
    return pd.DataFrame(data)


if __name__ == '__main__':
    # 测试风险分析器
    logging.basicConfig(level=logging.INFO)
    
    analyzer = RiskAnalyzer()
    test_df = create_test_dataframe()
    
    try:
        result = analyzer.analyze(test_df)
        print(f"\n=== 风险分析结果 ===")
        print(f"风险等级: {result['risk_level']}")
        print(f"原因: {result['reason']}")
        print(f"价格偏离度: {result['price_deviation']*100:.1f}%")
        print(f"流动性评分: {result['liquidity_score']:.2f}")
        print(f"求购深度: {result['buy_depth']:.2f}")
    except RiskAnalysisError as e:
        print(f"分析失败: {e}")
