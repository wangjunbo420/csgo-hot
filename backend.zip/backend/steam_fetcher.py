"""
Steam 社区市场数据采集模块
【合规性声明】使用 Steam 社区市场公开接口，严格遵守速率限制（≤8次/分钟）
接口为非官方但广泛使用的公开端点，无需认证凭据。
"""

import re
import time
import random
import logging
import requests
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from urllib.parse import quote

from base_fetcher import BaseFetcher
from data_fetcher import RateLimiter
from exceptions import DataFetchError, APIRateLimitError

logger = logging.getLogger(__name__)


# ---- Steam API 配置（硬编码默认值，后续迁移至 config.py 的 SteamAPIConfig） ----

STEAM_BASE_URL = "https://steamcommunity.com/market"
STEAM_APPID = 730            # CS2
STEAM_CURRENCY = 23          # CNY（人民币）
STEAM_MAX_REQUESTS_PER_MINUTE = 8
STEAM_REQUEST_INTERVAL = 7.5  # 秒 — 保守间隔
STEAM_RANDOM_DELAY_MIN = 1.0
STEAM_RANDOM_DELAY_MAX = 3.0
STEAM_MAX_RETRY_COUNT = 3
STEAM_TIMEOUT = 15           # 秒


class SteamMarketFetcher(BaseFetcher):
    """
    Steam 社区市场数据采集器

    实现 BaseFetcher 接口，提供与 BuffDataFetcher 一致的使用方式：
        with SteamMarketFetcher() as fetcher:
            data = fetcher.fetch_item_price("AK-47 | Fire Serpent (Field-Tested)")
    """

    def __init__(self):
        self.base_url = STEAM_BASE_URL
        self.appid = STEAM_APPID
        self.currency = STEAM_CURRENCY
        self.max_retry_count = STEAM_MAX_RETRY_COUNT
        self.timeout = STEAM_TIMEOUT
        self.random_delay_min = STEAM_RANDOM_DELAY_MIN
        self.random_delay_max = STEAM_RANDOM_DELAY_MAX

        self.rate_limiter = RateLimiter(
            max_requests=STEAM_MAX_REQUESTS_PER_MINUTE,
            time_window=60,
        )
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': (
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/125.0.0.0 Safari/537.36'
            ),
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        })

        logger.info("Steam 社区市场数据采集器已初始化 (appid=%d, currency=%d/CNY)", self.appid, self.currency)

    # ---- 上下文管理器（BaseFetcher 已提供，这里显式覆写以保持一致性） ----

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    # ---- 内部工具方法 ----

    @staticmethod
    def _parse_price(price_str: str) -> Optional[float]:
        """
        解析 Steam 价格字符串为浮点数

        支持格式:
            "¥ 1,234.56"  → 1234.56
            "¥1,234.56"   → 1234.56
            "$12.34"       → 12.34
            "1,234.56"     → 1234.56
            "--"           → None  (无交易数据)
            ""             → None
        """
        if not price_str or not isinstance(price_str, str):
            return None

        cleaned = price_str.strip()
        if cleaned in ('--', '-', ''):
            return None

        # 移除货币符号及前缀
        cleaned = re.sub(r'^[¥$€£￥]\s*', '', cleaned)
        # 移除千位分隔符（逗号）
        cleaned = cleaned.replace(',', '')
        # 移除非数字字符（保留小数点和负号）
        cleaned = re.sub(r'[^\d.\-]', '', cleaned)

        if not cleaned:
            return None

        try:
            return round(float(cleaned), 2)
        except ValueError:
            logger.warning("无法解析价格字符串: '%s'", price_str)
            return None

    @staticmethod
    def _parse_volume(volume_str) -> int:
        """
        解析成交量字符串为整数

        支持: "123" → 123, "1,234" → 1234, None → 0
        """
        if volume_str is None:
            return 0
        if isinstance(volume_str, int):
            return volume_str
        try:
            return int(str(volume_str).replace(',', ''))
        except (ValueError, TypeError):
            return 0

    def _add_random_delay(self):
        """添加随机延迟，模拟人类请求模式"""
        delay = random.uniform(self.random_delay_min, self.random_delay_max)
        logger.debug("添加随机延迟: %.2f秒", delay)
        time.sleep(delay)

    def _make_request(self, url: str, params: Optional[Dict] = None,
                      retry_count: int = 0) -> Dict:
        """
        发送 HTTP 请求（带重试机制和频率控制）

        Returns:
            解析后的 JSON 响应字典

        Raises:
            DataFetchError: 请求失败且重试耗尽
            APIRateLimitError: 被 Steam 限流（HTTP 429）
        """
        try:
            self.rate_limiter.wait_if_needed()

            response = self.session.get(
                url,
                params=params,
                timeout=self.timeout,
            )

            # Steam 限流检测
            if response.status_code == 429:
                retry_after = int(response.headers.get('Retry-After', 60))
                logger.warning("Steam API 频率限制，等待 %d 秒后重试", retry_after)
                raise APIRateLimitError(
                    "Steam API 频率限制",
                    retry_after=retry_after,
                )

            response.raise_for_status()

            data = response.json()
            return data

        except requests.exceptions.Timeout:
            logger.warning("请求超时 (重试 %d/%d)", retry_count + 1, self.max_retry_count)
            if retry_count >= self.max_retry_count:
                raise DataFetchError(
                    "Steam API 请求超时，已达最大重试次数",
                    retry_count=retry_count,
                )
            raise DataFetchError("Steam API 请求超时", retry_count=retry_count)

        except requests.exceptions.ConnectionError as e:
            logger.error("连接错误: %s", e)
            if retry_count >= self.max_retry_count:
                raise DataFetchError(
                    "Steam API 连接失败，已达最大重试次数",
                    retry_count=retry_count,
                )
            raise DataFetchError("Steam API 连接错误", retry_count=retry_count)

        except APIRateLimitError:
            raise

        except requests.exceptions.HTTPError as e:
            logger.error("HTTP 错误: %s (状态码: %d)", e, response.status_code)
            raise DataFetchError(
                f"Steam API HTTP 错误: {response.status_code}",
                status_code=response.status_code,
                retry_count=retry_count,
            )

        except ValueError as e:
            logger.error("JSON 解析失败: %s", e)
            raise DataFetchError(f"Steam API 响应解析失败: {e}", retry_count=retry_count)

        except Exception as e:
            logger.error("未知错误: %s", e)
            raise DataFetchError(f"Steam API 请求异常: {e}", retry_count=retry_count)

    # ---- 公开接口实现 ----

    def fetch_item_price(self, market_hash_name: str, game: str = 'csgo',
                         **kwargs) -> Dict:
        """
        获取饰品当前价格数据

        通过 Steam priceoverview 接口获取最低价和中位价，
        并估算求购价（price_low * 0.95，与 BUFF 策略一致）。

        Args:
            market_hash_name: 饰品市场哈希名称，如 "AK-47 | Fire Serpent (Field-Tested)"
            game: 游戏标识（当前仅支持 csgo / CS2，appid=730）
            **kwargs: 兼容 BaseFetcher 接口的额外参数（如 min_paintwear，此处忽略）

        Returns:
            {
                'item_name': str,
                'price_low': float,
                'price_avg_7d': float,
                'buy_order': float,
                'paintwear': None,
                'timestamp': str (ISO),
            }

        Raises:
            DataFetchError: 获取或解析失败
        """
        logger.info("获取 Steam 饰品价格: %s", market_hash_name)

        url = f"{self.base_url}/priceoverview/"
        params = {
            'appid': self.appid,
            'market_hash_name': market_hash_name,
            'currency': self.currency,
        }

        for attempt in range(self.max_retry_count + 1):
            try:
                data = self._make_request(url, params, retry_count=attempt)

                if not data.get('success'):
                    raise DataFetchError(
                        f"Steam API 返回 success=false: {data}",
                        retry_count=attempt,
                    )

                result = self._parse_price_overview(data, market_hash_name)
                self._add_random_delay()
                return result

            except APIRateLimitError as e:
                logger.warning("触发频率限制，等待 %d 秒", e.retry_after)
                time.sleep(e.retry_after)
                if attempt == self.max_retry_count:
                    raise DataFetchError(
                        "Steam API 频率限制，重试次数已耗尽",
                        retry_count=attempt,
                    )

            except DataFetchError as e:
                logger.warning("尝试 %d/%d 失败: %s", attempt + 1, self.max_retry_count + 1, e)
                if attempt == self.max_retry_count:
                    raise
                # 指数退避
                backoff = 2 ** attempt
                logger.info("指数退避等待 %d 秒", backoff)
                time.sleep(backoff)

    def _parse_price_overview(self, data: Dict, market_hash_name: str) -> Dict:
        """
        解析 priceoverview API 响应

        响应示例:
            {
                "success": true,
                "lowest_price": "¥ 1,234.56",
                "median_price": "¥ 1,200.00",
                "volume": "123",
                "quantity": "45"
            }
        """
        price_low = self._parse_price(data.get('lowest_price'))
        median_price = self._parse_price(data.get('median_price'))
        volume = self._parse_volume(data.get('volume'))

        # 如果没有 lowest_price，尝试使用 median_price 作为备选
        if price_low is None and median_price is not None:
            price_low = median_price
            logger.info("lowest_price 缺失，使用 median_price 作为 price_low: %.2f", price_low)

        if price_low is None or price_low <= 0:
            raise DataFetchError(
                f"无法获取有效最低售价 for '{market_hash_name}'，"
                f"原始响应: lowest_price={data.get('lowest_price')!r}"
            )

        # 7日均价：priceoverview 接口不直接提供，使用 median_price 近似
        # 若 median_price 也缺失，使用 price_low 作为兜底
        price_avg_7d = median_price if median_price and median_price > 0 else price_low

        # 求购价估算：与 BUFF 策略一致，取最低售价的 95%
        buy_order = round(price_low * 0.95, 2)

        result = {
            'item_name': market_hash_name,
            'price_low': price_low,
            'price_avg_7d': price_avg_7d,
            'buy_order': buy_order,
            'paintwear': None,  # Steam 不提供磨损值
            'timestamp': datetime.now().isoformat(),
        }

        logger.info(
            "Steam 价格数据: %s | 最低=%.2f | 均价=%.2f | 求购=%.2f | 成交量=%d",
            market_hash_name, price_low, price_avg_7d, buy_order, volume,
        )
        return result

    def fetch_price_history(self, market_hash_name: str, days: int = 7) -> List[Tuple[str, float, int]]:
        """
        获取历史价格数据（按日聚合）

        Steam pricehistory 接口返回小时级数据，此方法将其聚合为日级：
        - 日价格 = 当日所有小时数据的加权平均价（按成交量加权）
        - 日成交量 = 当日所有小时数据成交量之和

        Args:
            market_hash_name: 饰品市场哈希名称
            days: 获取最近 N 天的数据（默认 7 天）

        Returns:
            [(date_str, avg_price, total_volume), ...] 按日期升序排列
            date_str 格式: "YYYY-MM-DD"

        Raises:
            DataFetchError: 获取或解析失败
        """
        logger.info("获取 Steam 历史价格: %s (最近 %d 天)", market_hash_name, days)

        url = f"{self.base_url}/pricehistory/"
        params = {
            'appid': self.appid,
            'market_hash_name': market_hash_name,
        }

        for attempt in range(self.max_retry_count + 1):
            try:
                data = self._make_request(url, params, retry_count=attempt)

                if not data.get('success'):
                    raise DataFetchError(
                        f"Steam pricehistory API 返回 success=false: {data}",
                        retry_count=attempt,
                    )

                raw_prices = data.get('prices', [])
                if not raw_prices:
                    logger.warning("Steam 未返回历史价格数据: %s", market_hash_name)
                    self._add_random_delay()
                    return []

                daily_data = self._aggregate_hourly_to_daily(raw_prices)
                result = self._filter_and_sort_history(daily_data, days)

                self._add_random_delay()

                logger.info(
                    "获取到 %d 天历史数据（原始 %d 条小时记录 → %d 天）",
                    len(result), len(raw_prices), len(daily_data),
                )
                return result

            except APIRateLimitError as e:
                logger.warning("触发频率限制，等待 %d 秒", e.retry_after)
                time.sleep(e.retry_after)
                if attempt == self.max_retry_count:
                    raise DataFetchError(
                        "Steam API 频率限制，重试次数已耗尽",
                        retry_count=attempt,
                    )

            except DataFetchError as e:
                logger.warning("尝试 %d/%d 失败: %s", attempt + 1, self.max_retry_count + 1, e)
                if attempt == self.max_retry_count:
                    raise
                backoff = 2 ** attempt
                time.sleep(backoff)

    def _aggregate_hourly_to_daily(self, raw_prices: List) -> Dict[str, Dict]:
        """
        将小时级价格数据聚合为日级

        Args:
            raw_prices: Steam 原始数据，格式为 [datetime_str, price, volume], ...]
                例: [["Jun 01 2026 01: +0", 1234.56, 10], ...]

        Returns:
            {date_str: {'total_value': float, 'total_volume': int}}
            其中 total_value 用于计算加权平均价
        """
        daily: Dict[str, Dict] = {}

        for entry in raw_prices:
            if not isinstance(entry, (list, tuple)) or len(entry) < 3:
                logger.debug("跳过无效历史记录条目: %s", entry)
                continue

            datetime_str, price, volume = entry[0], entry[1], entry[2]

            try:
                price = float(price)
                volume = int(volume)
            except (ValueError, TypeError):
                logger.debug("跳过无法解析的历史记录: price=%s, volume=%s", price, volume)
                continue

            # 解析日期字符串 → date_str (YYYY-MM-DD)
            date_str = self._parse_steam_datetime(datetime_str)
            if date_str is None:
                logger.debug("跳过无法解析日期的历史记录: '%s'", datetime_str)
                continue

            if date_str not in daily:
                daily[date_str] = {'total_value': 0.0, 'total_volume': 0}

            daily[date_str]['total_value'] += price * volume
            daily[date_str]['total_volume'] += volume

        return daily

    @staticmethod
    def _parse_steam_datetime(dt_str: str) -> Optional[str]:
        """
        解析 Steam 历史价格中的日期时间字符串

        格式: "Jun 01 2026 01: +0"
        其中 "+0" 表示 UTC 偏移，": " 后面是时区偏移。

        Returns:
            "YYYY-MM-DD" 格式的日期字符串，解析失败返回 None
        """
        if not dt_str or not isinstance(dt_str, str):
            return None

        try:
            # 移除时区偏移部分（": +0"）
            # 格式示例: "Jun 01 2026 01: +0" 或 "Jun 01 2026 01:00 +0"
            # 取冒号前的部分再拼接日期部分
            # 更稳健的做法：提取 "Mon DD YYYY HH" 部分
            match = re.match(
                r'(\w{3})\s+(\d{1,2})\s+(\d{4})\s+(\d{1,2})',
                dt_str.strip(),
            )
            if not match:
                return None

            month_abbr, day, year, hour = match.groups()
            # 构造可解析的字符串
            clean_str = f"{month_abbr} {int(day):02d} {year} {int(hour):02d}:00"
            dt = datetime.strptime(clean_str, "%b %d %Y %H:%M")
            return dt.strftime("%Y-%m-%d")

        except (ValueError, AttributeError) as e:
            logger.debug("日期解析失败 '%s': %s", dt_str, e)
            return None

    @staticmethod
    def _filter_and_sort_history(daily: Dict[str, Dict],
                                 days: int) -> List[Tuple[str, float, int]]:
        """
        过滤最近 N 天的数据并按日期升序排列

        Returns:
            [(date_str, avg_price, total_volume), ...]
        """
        cutoff = datetime.now() - timedelta(days=days)
        cutoff_str = cutoff.strftime("%Y-%m-%d")

        result = []
        for date_str, agg in sorted(daily.items()):
            if date_str < cutoff_str:
                continue

            total_volume = agg['total_volume']
            if total_volume <= 0:
                continue

            avg_price = round(agg['total_value'] / total_volume, 2)
            result.append((date_str, avg_price, total_volume))

        return result

    def search_items(self, query: str, appid: Optional[int] = None,
                     start: int = 0, count: int = 10) -> List[Dict]:
        """
        搜索 Steam 社区市场物品（扩展方法，非 BaseFetcher 接口）

        Args:
            query: 搜索关键词
            appid: 游戏 appid（默认使用实例配置）
            start: 分页起始位置
            count: 每页返回数量（最大 100）

        Returns:
            [{'hash_name': str, 'name': str, ...}, ...]

        Raises:
            DataFetchError: 搜索失败
        """
        logger.info("搜索 Steam 市场物品: '%s'", query)

        url = f"{self.base_url}/search/render/"
        params = {
            'query': query,
            'appid': appid or self.appid,
            'start': start,
            'count': min(count, 100),
            'norender': 1,
        }

        for attempt in range(self.max_retry_count + 1):
            try:
                data = self._make_request(url, params, retry_count=attempt)

                if not data.get('success'):
                    raise DataFetchError(
                        f"Steam search API 返回 success=false: {data}",
                        retry_count=attempt,
                    )

                results = data.get('results', [])
                logger.info("搜索 '%s' 返回 %d 条结果", query, len(results))
                self._add_random_delay()
                return results

            except APIRateLimitError as e:
                logger.warning("触发频率限制，等待 %d 秒", e.retry_after)
                time.sleep(e.retry_after)
                if attempt == self.max_retry_count:
                    raise DataFetchError(
                        "Steam API 频率限制，重试次数已耗尽",
                        retry_count=attempt,
                    )

            except DataFetchError as e:
                logger.warning("搜索尝试 %d/%d 失败: %s",
                               attempt + 1, self.max_retry_count + 1, e)
                if attempt == self.max_retry_count:
                    raise
                time.sleep(2 ** attempt)

    def validate_auth(self) -> bool:
        """
        验证认证状态

        Steam 社区市场公开接口无需认证，始终返回 True。
        如果后续添加了 Steam Web API Key 支持，可在此处验证。
        """
        logger.debug("Steam 社区市场无需认证凭据，validate_auth 返回 True")
        return True

    def close(self):
        """关闭 HTTP 会话，释放资源"""
        self.session.close()
        logger.info("Steam 数据采集器已关闭")
