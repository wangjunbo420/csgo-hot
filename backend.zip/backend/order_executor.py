"""
订单执行引擎

连接「决策确认」→「实际下单」的桥梁。
职责：
1. 安全检查（金额限制、余额检查）
2. 调用 trader 执行下单
3. 更新数据库状态
4. 写入审计日志
"""

import logging
from typing import Dict, Optional
from datetime import datetime, timedelta

from config import TradeConfig
from base_trader import BaseTrader
from trade_engine import TradeDatabase
from exceptions import (
    TradeExecutionError,
    InsufficientBalanceError,
    DecisionError,
)

logger = logging.getLogger(__name__)


class OrderExecutor:
    """订单执行引擎"""

    def __init__(self, config: TradeConfig = None):
        self.config = config or TradeConfig()
        self.db = TradeDatabase(self.config.DATABASE_PATH)

    # ── 买入 ──────────────────────────────────────────────────────

    def execute_buy(self, decision: Dict, platform: str,
                    trader: BaseTrader, item_id: str = None,
                    order_options: Dict = None) -> Dict:
        """
        执行买入订单

        Args:
            decision: 决策记录（含 id, item, price, quantity, min_sell_date 等）
            platform: 'buff' 或 'steam'
            trader: 已认证的交易执行器实例
            item_id: 物品标识（BUFF: goods_id, Steam: market_hash_name）
                     若为 None，则使用 decision['item']
            order_options: 真实下单附加参数（BUFF: pay_method / pay_password / steamid），
                     空值会被剔除，不会发给平台

        Returns:
            {'order_pk': int, 'order_id': str, 'status': str}
        """
        decision_id = decision.get('id')
        item_name = decision['item']
        price = decision['price']
        quantity = decision['quantity']
        total_cost = price * quantity

        extra = {k: v for k, v in (order_options or {}).items() if v not in (None, "")}

        if item_id is None:
            item_id = item_name

        # 1. 安全检查
        self._safety_check(total_cost, platform, trader)

        # 2. 创建订单记录（pending）
        order_pk = self.db.save_order({
            'decision_id': decision_id,
            'platform': platform,
            'order_type': 'buy',
            'item_name': item_name,
            'price': price,
            'quantity': quantity,
            'status': 'executing',
        })
        if decision_id:
            self.db.log_execution(
                decision_id, 'ORDER_EXECUTING',
                f"开始执行买入订单，平台: {platform}"
            )

        # 3. 调用 trader 下单
        #    这一步成功即代表 BUFF 侧已成交、资金已支出。
        #    因此「下单阶段失败」与「下单成功但本地记账失败」必须严格区分：
        #      - 下单阶段失败 → 未成交，标记 failed，调用方可安全重试。
        #      - 下单成功后记账失败 → 已花钱，绝不可标记 failed（否则诱发重复买入），
        #        改标 filled_pending_record 并告警，由人工核对补登。
        try:
            result = trader.place_buy_order(
                item_id=item_id, price=price, quantity=quantity, **extra
            )
        except (TradeExecutionError, InsufficientBalanceError) as e:
            # 下单阶段失败：尚未成交，可安全重试
            self.db.update_order_status(order_pk, 'failed', error_message=str(e))
            if decision_id:
                self.db.log_execution(
                    decision_id, 'ORDER_FAILED', f"买入订单执行失败: {e}"
                )
            raise

        except Exception as e:
            # 下单阶段异常（网络 / API 错误等）：尚未成交，可安全重试
            error_msg = str(e)
            self.db.update_order_status(
                order_pk, 'failed', error_message=error_msg
            )
            if decision_id:
                self.db.log_execution(
                    decision_id, 'ORDER_FAILED', f"买入订单异常: {error_msg}"
                )
            raise TradeExecutionError(
                f"买入下单异常: {error_msg}",
                order_info={'item': item_name, 'platform': platform}
            )

        # ── 下单已成功，资金已支出。以下记账失败不得回滚为 failed ──
        platform_order_id = result.get('order_id', '')
        try:
            # 4. 更新订单状态为 filled
            self.db.update_order_status(
                order_pk, 'filled', order_id=platform_order_id
            )

            # 5. 写入持仓
            min_sell_date = decision.get('min_sell_date', '')
            if not min_sell_date:
                min_sell_date = (
                    datetime.now() + timedelta(days=self.config.T_PLUS_7_DAYS)
                ).strftime('%Y-%m-%d')

            position_pk = self.db.save_position({
                'platform': platform,
                'item_name': item_name,
                'asset_id': result.get('asset_id', ''),
                'buy_price': price,
                'quantity': quantity,
                'buy_date': datetime.now().strftime('%Y-%m-%d'),
                'min_sell_date': min_sell_date,
                'status': 'holding',
            })

            # 6. 审计日志
            if decision_id:
                self.db.log_execution(
                    decision_id, 'ORDER_FILLED',
                    f"买入成功，订单ID: {platform_order_id}，持仓ID: {position_pk}"
                )

            logger.info(
                f"买入成功: {item_name} x{quantity} @ ¥{price:,.2f}"
                f" (订单: {platform_order_id})"
            )
            return {
                'order_pk': order_pk,
                'position_pk': position_pk,
                'order_id': platform_order_id,
                'status': 'filled',
                'item_name': item_name,
                'quantity': quantity,
                'total_cost': total_cost,
            }

        except Exception as e:
            # ⚠ 已成交但本地记账失败：绝不可标记 failed（会诱发重复买入），
            #    标记为待补登并告警，由人工核对持仓后补登。
            record_err = str(e)
            logger.critical(
                f"⚠ 已成交但记账失败，需人工核对！订单: {platform_order_id} "
                f"物品: {item_name} x{quantity} @ ¥{price:,.2f} — {record_err}"
            )
            try:
                self.db.update_order_status(
                    order_pk, 'filled_pending_record',
                    order_id=platform_order_id,
                    error_message=f"成交后记账失败，请人工核对: {record_err}",
                )
            except Exception:
                pass
            if decision_id:
                try:
                    self.db.log_execution(
                        decision_id, 'ORDER_FILLED_PENDING_RECORD',
                        f"已成交待补登（订单 {platform_order_id}），记账失败: {record_err}"
                    )
                except Exception:
                    pass
            return {
                'order_pk': order_pk,
                'position_pk': None,
                'order_id': platform_order_id,
                'status': 'filled_pending_record',
                'item_name': item_name,
                'quantity': quantity,
                'total_cost': total_cost,
                'warning': '订单已成交，但本地记账失败，请人工核对持仓后再操作',
            }

    # ── 卖出 ──────────────────────────────────────────────────────

    def execute_sell(self, position: Dict, sell_price: float,
                     platform: str, trader: BaseTrader,
                     item_id: str = None) -> Dict:
        """
        执行卖出挂单

        Args:
            position: 持仓记录（含 id, item_name, asset_id, buy_price 等）
            sell_price: 售价
            platform: 'buff' 或 'steam'
            trader: 已认证的交易执行器实例
            item_id: 物品标识

        Returns:
            {'order_pk': int, 'order_id': str, 'status': str}
        """
        position_pk = position['id']
        item_name = position['item_name']
        asset_id = position.get('asset_id', '')
        quantity = position.get('quantity', 1)
        buy_price = position.get('buy_price', 0)

        if item_id is None:
            item_id = item_name

        # 1. 安全检查：T+7 限制
        min_sell_date = position.get('min_sell_date', '')
        if min_sell_date:
            today = datetime.now().strftime('%Y-%m-%d')
            if today < min_sell_date:
                raise TradeExecutionError(
                    f"物品尚未到可售日期（最早: {min_sell_date}）",
                    order_info={'item': item_name, 'min_sell_date': min_sell_date}
                )

        # 2. 创建卖出订单记录
        order_pk = self.db.save_order({
            'decision_id': None,
            'platform': platform,
            'order_type': 'sell',
            'item_name': item_name,
            'price': sell_price,
            'quantity': quantity,
            'status': 'executing',
        })

        # 3. 调用 trader 卖出
        try:
            result = trader.place_sell_order(
                item_id=item_id, asset_id=asset_id, price=sell_price
            )
            sell_order_id = result.get('order_id', '')

            # 4. 更新订单状态
            self.db.update_order_status(
                order_pk, 'filled', order_id=sell_order_id
            )

            # 5. 更新持仓状态为 listed
            pnl = (sell_price - buy_price) * quantity
            self.db.update_position(
                position_pk,
                sell_order_id=sell_order_id,
                status='listed',
                pnl=round(pnl, 2),
            )

            logger.info(
                f"卖出挂单成功: {item_name} x{quantity} @ ¥{sell_price:,.2f}"
                f" (订单: {sell_order_id})"
            )
            return {
                'order_pk': order_pk,
                'order_id': sell_order_id,
                'status': 'filled',
                'item_name': item_name,
                'sell_price': sell_price,
                'estimated_pnl': round(pnl, 2),
            }

        except TradeExecutionError:
            self.db.update_order_status(order_pk, 'failed')
            raise

        except Exception as e:
            error_msg = str(e)
            self.db.update_order_status(
                order_pk, 'failed', error_message=error_msg
            )
            raise TradeExecutionError(
                f"卖出挂单异常: {error_msg}",
                order_info={'item': item_name, 'platform': platform}
            )

    # ── 取消订单 ──────────────────────────────────────────────────

    def cancel_order(self, order_pk: int, platform: str,
                     trader: BaseTrader) -> Dict:
        """取消挂单"""
        orders = self.db.get_orders(limit=1000)
        order = None
        for o in orders:
            if o['id'] == order_pk:
                order = o
                break
        if not order:
            raise TradeExecutionError(f"订单记录不存在: {order_pk}")

        platform_order_id = order.get('order_id', '')
        order_type = order.get('order_type', 'buy')

        try:
            result = trader.cancel_order(
                order_id=platform_order_id, order_type=order_type
            )
            self.db.update_order_status(order_pk, 'cancelled')

            # 如果是卖出订单，恢复持仓状态为 holding
            if order_type == 'sell':
                # 查找关联持仓
                positions = self.db.get_positions(platform=platform)
                for pos in positions:
                    if pos.get('sell_order_id') == platform_order_id:
                        self.db.update_position(
                            pos['id'], sell_order_id='', status='holding'
                        )
                        break

            logger.info(f"订单已取消: {order_pk} ({platform_order_id})")
            return {'order_pk': order_pk, 'status': 'cancelled'}

        except Exception as e:
            raise TradeExecutionError(
                f"取消订单失败: {e}",
                order_info={'order_pk': order_pk, 'platform': platform}
            )

    # ── 安全检查 ──────────────────────────────────────────────────

    def _safety_check(self, total_cost: float, platform: str,
                      trader: BaseTrader):
        """
        安全预检：
        1. 单笔金额不超过 MAX_SINGLE_TRADE_AMOUNT
        2. 账户余额充足
        """
        # 金额上限检查
        max_amount = self.config.MAX_SINGLE_TRADE_AMOUNT
        if total_cost > max_amount:
            raise TradeExecutionError(
                f"交易金额 ¥{total_cost:,.2f} 超过单笔上限 "
                f"¥{max_amount:,.2f}",
                order_info={'total_cost': total_cost, 'limit': max_amount}
            )

        # 余额检查：查询失败时为安全起见阻止交易，避免超额下单
        try:
            balance = trader.get_balance()
        except Exception as e:
            logger.error(f"余额查询失败，已阻止交易以防超额下单: {e}")
            raise TradeExecutionError(
                f"无法查询账户余额，已阻止交易以防超额下单: {e}",
                order_info={'total_cost': total_cost, 'platform': platform}
            )
        if balance < total_cost:
            raise InsufficientBalanceError(
                required=total_cost, available=balance, platform=platform
            )
