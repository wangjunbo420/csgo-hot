"""
Steam 账号登录模块

支持两种方式获取 Steam 交易 session:
1. 用户名 + 密码 + SteamGuard 2FA（需要 shared_secret）
2. 直接提供 session cookies

登录成功后返回 cookies 字典，供 SteamTrader 使用。

注意：
- Steam Web 登录流程复杂，且 Valve 可能随时更新接口
- 推荐使用 steampy 库（pip install steampy）处理登录
- 此模块提供基础实现，生产环境建议使用 steampy
"""

import time
import hmac
import hashlib
import base64
import struct
import logging
from typing import Dict, Optional

import requests

logger = logging.getLogger(__name__)


class SteamLogin:
    """Steam 登录管理器"""

    STEAM_LOGIN_URL = "https://steamcommunity.com/login/dologin/"
    STEAM_RSA_URL = "https://steamcommunity.com/login/getrsakey/"

    def login(self, username: str, password: str,
              shared_secret: Optional[str] = None) -> Dict:
        """
        使用用户名密码登录 Steam

        Args:
            username: Steam 用户名
            password: Steam 密码
            shared_secret: SteamGuard shared_secret（用于生成 2FA 验证码）

        Returns:
            {'success': bool, 'cookies': dict, 'message': str}
        """
        try:
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                              'AppleWebKit/537.36 (KHTML, like Gecko) '
                              'Chrome/120.0.0.0 Safari/537.36',
            })

            # 生成 2FA 验证码
            auth_code = ''
            if shared_secret:
                auth_code = self._generate_2fa_code(shared_secret)
                logger.info("已生成 SteamGuard 2FA 验证码")

            # 获取 RSA 密钥
            rsa_resp = session.post(self.STEAM_RSA_URL, data={
                'username': username,
                'donotcache': int(time.time() * 1000),
            })
            rsa_data = rsa_resp.json()

            if not rsa_data.get('success'):
                return {
                    'success': False,
                    'cookies': {},
                    'message': f"获取 RSA 密钥失败: {rsa_data.get('message', '未知错误')}",
                }

            # 注意：完整的 RSA 加密密码流程需要使用 pycryptodome 库
            # 这里简化处理，直接传递明文密码（实际生产环境不推荐）
            # 生产环境建议使用 steampy 库
            import base64 as b64
            try:
                from Crypto.PublicKey import RSA
                from Crypto.Cipher import PKCS1_v1_5
                rsa_key = RSA.import_key(b64.b64decode(rsa_data['publickey']))
                cipher = PKCS1_v1_5.new(rsa_key)
                encrypted_password = b64.b64encode(
                    cipher.encrypt(password.encode('utf-8'))
                ).decode('utf-8')
            except ImportError:
                raise RuntimeError(
                    "pycryptodome 未安装，无法加密密码，登录已中止。"
                    "请运行 pip install pycryptodome 后重试。"
                )

            # 执行登录
            login_data = {
                'username': username,
                'password': encrypted_password,
                'twofactorcode': auth_code,
                'emailauth': '',
                'loginfriendlyname': '',
                'captchagid': '-1',
                'captcha_text': '',
                'emailsteamid': '',
                'rsatimestamp': rsa_data.get('timestamp', ''),
                'remember_login': 'true',
                'donotcache': int(time.time() * 1000),
            }

            login_resp = session.post(self.STEAM_LOGIN_URL, data=login_data)
            login_result = login_resp.json()

            if login_result.get('success'):
                # 提取 cookies
                cookies = {}
                for cookie in session.cookies:
                    cookies[cookie.name] = cookie.value

                # 从 transfer parameters 中提取额外信息
                if login_result.get('transfer_parameters'):
                    params = login_result['transfer_parameters']
                    if 'steamid' in params:
                        cookies['steamid'] = params['steamid']

                logger.info(f"Steam 登录成功: {username}")
                return {
                    'success': True,
                    'cookies': cookies,
                    'message': '登录成功',
                }
            else:
                message = login_result.get('message', '登录失败')
                if login_result.get('requires_twofactor'):
                    message = '需要 SteamGuard 2FA 验证码，请提供 shared_secret'
                elif login_result.get('emailauth_needed'):
                    message = '需要邮箱验证码'
                elif login_result.get('captcha_needed'):
                    message = '需要验证码'

                logger.warning(f"Steam 登录失败: {message}")
                return {
                    'success': False,
                    'cookies': {},
                    'message': message,
                }

        except Exception as e:
            logger.error(f"Steam 登录异常: {e}")
            return {
                'success': False,
                'cookies': {},
                'message': f'登录异常: {str(e)}',
            }

    def login_with_cookies(self, session_cookies: Dict[str, str]) -> Dict:
        """
        直接使用已有 cookies 登录（跳过密码登录流程）

        Args:
            session_cookies: 包含 sessionid, steamLoginSecure 等

        Returns:
            {'success': bool, 'cookies': dict, 'message': str}
        """
        required = ['sessionid', 'steamLoginSecure']
        missing = [k for k in required if k not in session_cookies]
        if missing:
            return {
                'success': False,
                'cookies': {},
                'message': f'缺少必要的 cookies: {missing}',
            }
        return {
            'success': True,
            'cookies': session_cookies,
            'message': 'Cookie 登录成功',
        }

    @staticmethod
    def _generate_2fa_code(shared_secret: str) -> str:
        """
        根据 shared_secret 生成 SteamGuard 2FA 验证码

        算法与 Steam Mobile App 一致:
        1. 取当前时间戳 / 30 作为 counter
        2. HMAC-SHA1(shared_secret_bytes, counter_bytes)
        3. 取 hash 最后 4 bits 作为 offset
        4. 取 4 bytes 从 offset 开始，mask 掉最高位
        5. 用自定义 base-26 字符集编码为 5 位验证码
        """
        CHARSET = "23456789BCDFGHJKMNPQRTVWXY"
        timestamp = int(time.time())
        counter = timestamp // 30

        # HMAC-SHA1
        secret_bytes = base64.b64decode(shared_secret)
        counter_bytes = struct.pack('>Q', counter)
        hmac_hash = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()

        # Dynamic truncation
        offset = hmac_hash[-1] & 0x0F
        code_int = struct.unpack('>I', hmac_hash[offset:offset + 4])[0]
        code_int &= 0x7FFFFFFF

        # Base-26 encode
        code = []
        for _ in range(5):
            code.append(CHARSET[code_int % len(CHARSET)])
            code_int //= len(CHARSET)

        return ''.join(code)
