"""
数据获取器工厂 — 根据平台名称创建对应的 Fetcher 实例
"""

from typing import Optional
from base_fetcher import BaseFetcher


SUPPORTED_PLATFORMS = ['buff', 'steam']


class FetcherFactory:
    """平台数据获取器工厂"""

    @staticmethod
    def get(platform: str, cookie: Optional[str] = None) -> BaseFetcher:
        """
        根据平台名称创建对应的 Fetcher 实例

        Args:
            platform: 平台标识，'buff' 或 'steam'
            cookie: Cookie 字符串（仅 BUFF 需要）

        Returns:
            BaseFetcher 实例

        Raises:
            ValueError: 不支持的平台
        """
        platform = platform.lower().strip()

        if platform == 'buff':
            from data_fetcher import BuffDataFetcher
            return BuffDataFetcher(cookie=cookie)

        if platform == 'steam':
            from steam_fetcher import SteamMarketFetcher
            return SteamMarketFetcher()

        raise ValueError(
            f"不支持的平台: '{platform}'，可选: {', '.join(SUPPORTED_PLATFORMS)}"
        )
