"""
运行时路径解析

同一套代码同时支持「源码运行」与「安装版运行」（Electron 外壳 + 内置 Python）：

- 代码目录 app_root：本文件所在目录（源码运行是项目根，安装版是 resources\\backend）
- 数据目录 data_dir：默认 %LOCALAPPDATA%\\CSGO饰品交易分析\\data，
  可由环境变量 CSGO_DATA_DIR 覆盖（Electron 外壳启动后端时会显式传入）
- 日志目录 log_dir：数据目录下的 logs
"""

import os
import shutil

APP_NAME = "CSGO饰品交易分析"

_APP_ROOT = os.path.dirname(os.path.abspath(__file__))


def app_root() -> str:
    """代码根目录"""
    return _APP_ROOT


def data_dir() -> str:
    """数据目录（数据库、配置、日志都在这里，卸载程序不会删除）"""
    override = os.getenv("CSGO_DATA_DIR", "").strip()
    if override:
        d = os.path.abspath(override)
    else:
        base = os.getenv("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(base, APP_NAME, "data")
    os.makedirs(d, exist_ok=True)
    return d


def data_path(*parts) -> str:
    """数据目录下的某个文件路径（自动创建父目录）"""
    p = os.path.join(data_dir(), *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def log_dir() -> str:
    d = os.path.join(data_dir(), "logs")
    os.makedirs(d, exist_ok=True)
    return d


# 需要从旧版（源码目录）迁移到数据目录的文件
_LEGACY_FILES = ("trade_decisions.db", ".env")


def migrate_legacy() -> list:
    """首次以安装版运行时，把旧版留在源码目录里的数据库 / .env 搬到数据目录。

    只在新位置不存在同名文件时复制，绝不覆盖已有数据。
    返回实际迁移的文件名列表。
    """
    target = data_dir()
    migrated = []
    for name in _LEGACY_FILES:
        src = os.path.join(_APP_ROOT, name)
        dst = os.path.join(target, name)
        if os.path.exists(src) and not os.path.exists(dst):
            try:
                shutil.copy2(src, dst)
                migrated.append(name)
            except OSError:
                pass
    return migrated
