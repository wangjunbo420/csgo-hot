"""
CSGO饰品交易数据分析系统 - FastAPI 后端服务
"""

import sys
import os
import io
import json
import asyncio
import signal
import logging
import time
from datetime import datetime
from contextlib import asynccontextmanager
from typing import Dict, List, Optional

# ---- Fix Windows console Chinese encoding ----
# 安装版由 Electron 外壳以无控制台方式启动，此时 sys.stdout 可能为 None 或没有 buffer，
# 这里做容错处理，避免启动时 AttributeError 直接崩掉。
if sys.platform == 'win32':
    try:
        os.system('chcp 65001 >nul 2>&1')
    except Exception:
        pass
    for _stream_name in ('stdout', 'stderr'):
        _stream = getattr(sys, _stream_name, None)
        if _stream is not None and hasattr(_stream, 'buffer'):
            try:
                setattr(
                    sys,
                    _stream_name,
                    io.TextIOWrapper(_stream.buffer, encoding='utf-8', errors='replace'),
                )
            except Exception:
                pass

import pandas as pd
import os as _os

# ---- 内置 Python（嵌入式发行版）不会自动把脚本目录加入 sys.path，这里显式补上 ----
_APP_DIR = os.path.dirname(os.path.abspath(__file__))
if _APP_DIR not in sys.path:
    sys.path.insert(0, _APP_DIR)

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from config import APIConfig, SteamConfig, CORS_ORIGINS, TOTAL_CAPITAL, API_PORT, PROXY_PORT, DEFAULT_PLATFORM, AutoDeliveryConfig
import paths
from data_fetcher import BuffDataFetcher
from steam_fetcher import SteamMarketFetcher
from fetcher_factory import SUPPORTED_PLATFORMS
from exceptions import (
    BaseTradingError, DataFetchError, RiskAnalysisError,
    DecisionError, AuthenticationError, DatabaseError,
    TradeExecutionError, InsufficientBalanceError,
)
from packet_capture import CaptureManager
from risk_analyzer import RiskAnalyzer
from trade_engine import TradeDecisionEngine, TradeDatabase
from order_executor import OrderExecutor

# ---- 日志 ----
logger = logging.getLogger(__name__)

# ---- 关闭鉴权 token（启动时随机生成，防止未授权关停） ----
import secrets
_SHUTDOWN_TOKEN = secrets.token_urlsafe(24)


# ---- 应用状态管理（替代全局单例，避免竞态） ----
class AppState:
    def __init__(self):
        from qr_login import BuffQRLogin, BuffQRConfig
        api_config = APIConfig()
        self.cookie: str = api_config.COOKIE
        # 关键修复：浏览器 localStorage 是按「协议+主机+端口」隔离的，
        # 而桌面外壳每次启动都会换一个空闲端口，导致登录过的 Cookie 下次启动就"丢"了。
        # 这里把 Cookie 持久化到数据目录，后端启动时优先读回。
        self._cookie_file = os.path.join(paths.data_dir(), "buff_cookie.json")
        stored_cookie = self._load_stored_cookie()
        if stored_cookie:
            self.cookie = stored_cookie
        self.buff_fetcher: BuffDataFetcher = BuffDataFetcher(cookie=self.cookie)
        self.steam_fetcher: SteamMarketFetcher = SteamMarketFetcher()
        self.current_platform: str = DEFAULT_PLATFORM
        self.analyzer: RiskAnalyzer = RiskAnalyzer()
        self.engine: TradeDecisionEngine = TradeDecisionEngine(total_capital=TOTAL_CAPITAL)
        self.capture: CaptureManager = CaptureManager(proxy_port=PROXY_PORT)
        self.qr_login: BuffQRLogin = BuffQRLogin(BuffQRConfig())
        # 交易执行器
        self.buff_trader = None  # 延迟初始化（需要 cookie）
        self.steam_trader = None  # 延迟初始化（需要 steam session）
        self.order_executor: OrderExecutor = OrderExecutor()
        self.trade_monitor = None  # 延迟初始化，需要 buff_trader
        self.recommender = None  # 每日推荐引擎，登录后惰性创建

    def _load_stored_cookie(self) -> str:
        """从数据目录读回上次登录保存的 Cookie（不存在/损坏则返回空）"""
        try:
            if not os.path.exists(self._cookie_file):
                return ""
            with open(self._cookie_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            cookie = str(data.get("cookie") or "")
            if cookie:
                logger.info("已从数据目录恢复上次登录的 BUFF Cookie")
            return cookie
        except Exception as e:
            logger.warning(f"读取本地 Cookie 失败: {e}")
            return ""

    def _store_cookie(self, cookie: str):
        """把 Cookie 写到数据目录，供下次启动恢复"""
        try:
            os.makedirs(os.path.dirname(self._cookie_file), exist_ok=True)
            payload = {"cookie": cookie, "updated_at": datetime.now().isoformat()}
            with open(self._cookie_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            try:
                os.chmod(self._cookie_file, 0o600)
            except Exception:
                pass
        except Exception as e:
            logger.warning(f"保存本地 Cookie 失败: {e}")

    def get_fetcher(self, platform: str = None):
        """获取指定平台的数据获取器（默认使用当前平台）"""
        p = (platform or self.current_platform).lower().strip()
        if p == 'steam':
            return self.steam_fetcher
        return self.buff_fetcher

    def update_cookie(self, cookie: str):
        self.buff_fetcher.close()
        self.cookie = cookie
        self._store_cookie(cookie)
        self.buff_fetcher = BuffDataFetcher(cookie=cookie)
        # 同时更新 BUFF trader
        self.buff_trader = None  # 重置，下次使用时重新创建
        self.recommender = None  # 推荐引擎跟着 Cookie 一起重建

    def ensure_recommender(self):
        """惰性创建每日推荐引擎（需要 BUFF 登录态）"""
        if self.recommender is None:
            from recommender import DailyRecommender
            self.recommender = DailyRecommender(fetcher=self.buff_fetcher)
        return self.recommender

    def get_trader(self, platform: str):
        """获取指定平台的交易执行器（延迟初始化）"""
        import requests as _requests
        p = platform.lower().strip()
        if p == 'buff':
            if self.buff_trader is None:
                if not self.cookie:
                    raise AuthenticationError("BUFF 未设置 Cookie，请先登录")
                from buff_trader import BuffTrader
                session = _requests.Session()
                session.headers.update({
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Cookie": self.cookie,
                })
                # 解析 cookie 字符串并设置到 session cookies
                for item in self.cookie.split(';'):
                    item = item.strip()
                    if '=' in item:
                        key, val = item.split('=', 1)
                        session.cookies.set(key.strip(), val.strip())
                self.buff_trader = BuffTrader(session=session)
            return self.buff_trader
        if p == 'steam':
            if self.steam_trader is None:
                raise AuthenticationError("Steam 未登录，请先登录")
            return self.steam_trader
        raise ValueError(f"不支持的平台: {p}")

    def update_capital(self, capital: float):
        self.engine = TradeDecisionEngine(total_capital=capital)

    def set_platform(self, platform: str):
        """切换当前平台"""
        p = platform.lower().strip()
        if p not in SUPPORTED_PLATFORMS:
            raise ValueError(f"不支持的平台: {p}")
        self.current_platform = p

    def reset_qr_session(self):
        """重置扫码登录 session（获取新二维码前调用）"""
        from qr_login import BuffQRLogin, BuffQRConfig
        self.qr_login.close()
        self.qr_login = BuffQRLogin(BuffQRConfig())

    def ensure_trade_monitor(self):
        """延迟初始化 TradeMonitor（顺便把 buff_trader 拉起来，否则监控永远没数据）"""
        if self.buff_trader is None and self.cookie:
            try:
                self.get_trader("buff")
            except AuthenticationError:
                self.buff_trader = None
        if self.trade_monitor is None and self.buff_trader is not None:
            from trade_monitor import TradeMonitor
            self.trade_monitor = TradeMonitor(
                buff_trader=self.buff_trader,
                config=AutoDeliveryConfig(),
            )
        return self.trade_monitor

    async def shutdown(self):
        if self.trade_monitor and self.trade_monitor.is_running:
            await self.trade_monitor.stop()
        self.buff_fetcher.close()
        self.steam_fetcher.close()
        self.qr_login.close()
        await self.capture.shutdown()


# ---- Lifespan（启动/关闭钩子） ----
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 首次以安装版运行时，把旧版留在源码目录的数据库/.env 迁移到数据目录
    migrated = paths.migrate_legacy()
    if migrated:
        logger.info(f"已迁移旧数据到 {paths.data_dir()}: {', '.join(migrated)}")
    app.state.app_state = AppState()
    logger.info(f"应用已启动，数据目录: {paths.data_dir()}")
    yield
    await app.state.app_state.shutdown()
    logger.info("应用已关闭")


app = FastAPI(
    title="CSGO饰品交易分析系统",
    version="2.0.0",
    lifespan=lifespan,
)


# ---- CORS（从环境变量读取，不再使用 *） ----
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- 请求日志中间件 ----
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    elapsed = time.time() - start
    logger.info(f"{request.method} {request.url.path} → {response.status_code} ({elapsed:.3f}s)")
    return response


# ---- 全局异常处理 ----
@app.exception_handler(BaseTradingError)
async def trading_error_handler(request: Request, exc: BaseTradingError):
    status = 400
    if isinstance(exc, (DataFetchError, AuthenticationError)):
        status = 502
    elif isinstance(exc, DatabaseError):
        status = 500
    return JSONResponse(status_code=status, content={"detail": str(exc)})


# ---- Pydantic 模型 ----
class PriceDataResponse(BaseModel):
    item_name: str
    price_low: float
    price_avg_7d: float
    buy_order: float
    paintwear: Optional[float] = None
    timestamp: str
    # 明确告诉前端「这份价格属于哪个具体饰品」
    goods_id: Optional[str] = None
    icon_url: Optional[str] = None
    exterior: Optional[str] = None
    rarity: Optional[str] = None
    matched_name: Optional[str] = None
    match_type: Optional[str] = None   # selected / exact / unique
    query_name: Optional[str] = None


class PriceHistoryPoint(BaseModel):
    date: str
    price: float
    volume: int = 0          # 兼容旧字段：BUFF 侧是「在售数量」
    sell_num: int = 0
    buy_max: float = 0.0
    ts: int = 0              # 毫秒时间戳，前端按真实时间画 X 轴


class PriceHistoryResponse(BaseModel):
    item_name: str
    days: int
    history: List[PriceHistoryPoint]


class RiskAnalysisResponse(BaseModel):
    risk_level: str
    price_deviation: float
    liquidity_score: float
    buy_depth: float
    reason: str
    timestamp: str


class TradeDecisionResponse(BaseModel):
    id: Optional[int] = None
    item: str
    price: float
    quantity: int
    stop_loss: float
    risk_level: str
    price_deviation: float
    reason: str
    status: str
    timestamp: str
    min_sell_date: Optional[str] = None
    total_investment: float
    max_loss: float
    liquidity_score: Optional[float] = None
    buy_depth: Optional[float] = None


class ItemSearchRequest(BaseModel):
    market_hash_name: str = Field(..., min_length=1, max_length=200)
    game: str = "csgo"
    platform: Optional[str] = None
    goods_id: Optional[str] = None  # 从联想列表选中的具体饰品 ID（传了就按它查，不再猜名字）


class AnalyzeRequest(BaseModel):
    item_name: str = Field(..., min_length=1)
    price_data: List[Dict] = Field(..., min_length=2)


class SettingsRequest(BaseModel):
    cookie: Optional[str] = None
    total_capital: Optional[float] = Field(None, gt=0)
    max_loss_rate: Optional[float] = Field(None, gt=0, lt=100)


class QRLoginStartResponse(BaseModel):
    uuid: str
    qrcode_image: str
    expires_at: int


class QRLoginPollRequest(BaseModel):
    uuid: str


class QRLoginPollResponse(BaseModel):
    status: str
    message: str
    cookie: Optional[str] = None


class ConfirmRequest(BaseModel):
    confirmed: bool
    notes: Optional[str] = None


class CaptureStatusResponse(BaseModel):
    status: str
    cookie: Optional[str] = None
    message: Optional[str] = None
    error: Optional[str] = None
    port: Optional[int] = None
    cert_dir: Optional[str] = None


class ProxyStartRequest(BaseModel):
    port: int = Field(default=8888, ge=1024, le=65535)


class CaptureApplyRequest(BaseModel):
    cookie: str = Field(..., min_length=10)


# ---- 交易请求模型 ----

class TradeBuyRequest(BaseModel):
    decision_id: int
    platform: str = "buff"
    item_id: Optional[str] = None  # BUFF: goods_id, Steam: market_hash_name
    # 真实下单参数（BUFF 用）：支付方式、支付密码、绑定 Steam 账号（多账号时指定收货账号）
    pay_method: Optional[str] = None
    pay_password: Optional[str] = None
    steamid: Optional[str] = None


class TradeSellRequest(BaseModel):
    position_id: int
    sell_price: float = Field(..., gt=0)
    platform: str = "buff"
    item_id: Optional[str] = None


class TradeCancelRequest(BaseModel):
    order_pk: int
    platform: str = "buff"


class SteamLoginRequest(BaseModel):
    username: str = Field(..., min_length=1)
    password: str = Field(..., min_length=1)
    shared_secret: Optional[str] = None  # SteamGuard 共享密钥


# ---- 发货相关模型 ----

class DeliveryToggleRequest(BaseModel):
    enabled: bool


class DeliveryManualAcceptRequest(BaseModel):
    delivery_pk: int


# ---- 工具函数 ----
def _state(request: Request) -> AppState:
    return request.app.state.app_state


# ==================== API 端点 ====================

@app.get("/api/health")
async def health_check():
    return {
        "status": "ok",
        "service": "CSGO Trading Analysis System",
        "version": "2.0.0",
    }


@app.get("/api/init")
async def get_init_token():
    """返回前端初始化所需数据（含 shutdown token，不暴露在 health 端点）"""
    return {"shutdown_token": _SHUTDOWN_TOKEN}


@app.get("/api/platforms")
async def list_platforms():
    """返回所有可用数据平台"""
    platforms = [
        {"id": "buff", "name": "网易 BUFF", "requires_auth": True},
        {"id": "steam", "name": "Steam 社区市场", "requires_auth": False},
    ]
    return {"platforms": platforms}


@app.get("/api/platform/current")
async def get_current_platform(req: Request):
    """返回当前选中的数据平台"""
    state = _state(req)
    return {"platform": state.current_platform}


@app.post("/api/platform/current")
async def set_current_platform(body: dict, req: Request):
    """切换当前数据平台"""
    state = _state(req)
    platform = body.get('platform', '')
    try:
        state.set_platform(platform)
        return {"status": "ok", "platform": state.current_platform}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/validate-cookie")
async def validate_cookie(req: Request, platform: str = Query(default=None)):
    """验证当前平台的认证凭据是否有效"""
    state = _state(req)
    p = platform or state.current_platform

    if p == 'steam':
        return {"valid": True, "message": "Steam 社区市场无需认证"}

    if not state.cookie:
        return {"valid": False, "message": "未设置 Cookie"}
    try:
        fetcher = state.get_fetcher(p)
        if fetcher.validate_auth():
            return {"valid": True, "message": "Cookie 有效"}
        return {"valid": False, "message": "Cookie 无效或已过期"}
    except Exception as e:
        logger.warning(f"Cookie 验证失败: {e}")
        return {"valid": False, "message": f"Cookie 无效或已过期: {e}"}


# ---- 扫码登录 ----

@app.post("/api/qrlogin/start", response_model=QRLoginStartResponse)
async def qrlogin_start(req: Request):
    """开始扫码登录 — 重置 session 并获取新二维码"""
    state = _state(req)
    try:
        state.reset_qr_session()
        result = state.qr_login.start_login()
        return QRLoginStartResponse(
            uuid=result['uuid'],
            qrcode_image=result['qrcode_image'],
            expires_at=result['expires_at'],
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"获取二维码失败: {e}")


@app.post("/api/qrlogin/poll", response_model=QRLoginPollResponse)
async def qrlogin_poll(request: QRLoginPollRequest, req: Request):
    """轮询扫码状态 — 共用 /start 的同一个 session"""
    state = _state(req)
    try:
        result = state.qr_login.poll_status(request.uuid)
        return QRLoginPollResponse(
            status=result['status'],
            message=result['message'],
            cookie=result.get('cookie'),
        )
    except Exception as e:
        return QRLoginPollResponse(status='ERROR', message=str(e))


# ---- 设置 ----

@app.get("/api/settings")
async def get_settings(req: Request):
    """返回当前登录状态，供前端在重启后正确显示「已登录」"""
    state = _state(req)
    cookie = state.cookie or ""
    has_session = "session=" in cookie and len(cookie) > 20
    return {
        "has_cookie": bool(cookie),
        "has_session": has_session,
        "cookie_length": len(cookie),
        "total_capital": TOTAL_CAPITAL,
        "platform": state.current_platform,
    }


@app.post("/api/settings")
async def update_settings(request: SettingsRequest, req: Request):
    state = _state(req)
    if request.cookie is not None:
        state.update_cookie(request.cookie)
    if request.total_capital is not None:
        state.update_capital(request.total_capital)
    return {"status": "ok", "message": "设置已更新"}


# ---- 饰品搜索 ----

@app.get("/api/items/search")
async def search_item_suggestions(
    req: Request,
    q: str = Query(..., min_length=1, description="搜索关键字"),
    game: str = Query("csgo"),
    limit: int = Query(8, ge=1, le=30),
    platform: Optional[str] = Query(None),
):
    """输入联想：返回候选饰品列表（含 goods_id / 名称 / 最低价 / 在售数 / 图标）"""
    state = _state(req)
    p = (platform or state.current_platform or 'buff').lower()
    if p != 'buff':
        raise HTTPException(status_code=400, detail="Steam 平台暂不支持联想搜索，请直接输入完整英文名称")
    fetcher = state.get_fetcher('buff')
    if not hasattr(fetcher, 'search_items'):
        raise HTTPException(status_code=501, detail="当前数据源不支持联想搜索")
    try:
        items = fetcher.search_items(q, game=game, limit=limit)
        return {"query": q, "items": items}
    except DataFetchError as e:
        raise HTTPException(status_code=502, detail=str(e))


@app.post("/api/item/search")
async def search_item(request: ItemSearchRequest, req: Request):
    state = _state(req)
    platform = request.platform or state.current_platform
    fetcher = state.get_fetcher(platform)

    # BUFF 需要 Cookie，Steam 不需要
    if platform == 'buff' and not state.cookie:
        raise HTTPException(status_code=401, detail="未设置 Cookie，请先登录")
    try:
        if platform == 'buff' and not request.goods_id:
            # 先解析名称：名字不唯一就返回候选，让用户自己选，绝不拿第一个结果报价
            resolved = fetcher.resolve_item(request.market_hash_name, request.game)
            if resolved['match_type'] == 'ambiguous':
                return JSONResponse(status_code=200, content={
                    "ambiguous": True,
                    "query": request.market_hash_name,
                    "message": f"「{request.market_hash_name}」对应多个饰品，请选择具体饰品后再查询价格",
                    "candidates": resolved['candidates'],
                })
            result = fetcher.fetch_item_price(
                market_hash_name=request.market_hash_name,
                game=request.game,
                goods_id=resolved['goods_id'],
            )
            result['matched_name'] = resolved['name'] or request.market_hash_name
            result['match_type'] = resolved['match_type']
            return PriceDataResponse(**result)
        result = fetcher.fetch_item_price(
            market_hash_name=request.market_hash_name,
            game=request.game,
            goods_id=request.goods_id,
        )
        return PriceDataResponse(**result)
    except DataFetchError as e:
        raise HTTPException(status_code=502, detail=str(e))


@app.get("/api/item/price-history", response_model=PriceHistoryResponse)
async def get_price_history(
    market_hash_name: str = Query(..., min_length=1, max_length=200),
    days: int = Query(7, ge=1, le=30),
    platform: str = Query(default=None),
    goods_id: Optional[str] = Query(default=None),
    req: Request = None,
):
    state = _state(req)
    p = platform or state.current_platform
    fetcher = state.get_fetcher(p)

    if p == 'buff' and not state.cookie:
        raise HTTPException(status_code=401, detail="未设置 Cookie，请先登录")
    try:
        if p == 'buff':
            series = fetcher.fetch_price_history_series(market_hash_name, days, goods_id=goods_id)
            history = [
                {
                    "date": point.get("date", ""),
                    "price": point.get("price", 0),
                    "volume": point.get("sell_num", 0),
                    "sell_num": point.get("sell_num", 0),
                    "buy_max": point.get("buy_max", 0),
                    "ts": point.get("ts", 0),
                }
                for point in series
            ]
        else:
            raw = fetcher.fetch_price_history(market_hash_name, days)
            history = [{"date": d, "price": p, "volume": v} for d, p, v in raw]
        return PriceHistoryResponse(
            item_name=market_hash_name,
            days=days,
            history=history,
        )
    except DataFetchError as e:
        raise HTTPException(status_code=502, detail=str(e))


# ---- 风险分析 ----

@app.post("/api/analyze", response_model=RiskAnalysisResponse)
async def analyze_risk(request: AnalyzeRequest, req: Request):
    state = _state(req)
    try:
        df = pd.DataFrame(request.price_data)
        result = state.analyzer.analyze(df)
        return RiskAnalysisResponse(**result)
    except RiskAnalysisError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ---- 交易决策 ----

@app.post("/api/decision", response_model=TradeDecisionResponse)
async def make_decision(request: AnalyzeRequest, req: Request):
    state = _state(req)
    try:
        df = pd.DataFrame(request.price_data)
        risk_result = state.analyzer.analyze(df)
        decision = state.engine.make_decision(
            risk_analysis=risk_result,
            item_name=request.item_name,
            current_price=request.price_data[-1]['price'],
        )
        decision['liquidity_score'] = risk_result.get('liquidity_score')
        decision['buy_depth'] = risk_result.get('buy_depth')
        return TradeDecisionResponse(**decision)
    except RiskAnalysisError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except DecisionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---- 决策历史 ----

@app.get("/api/decisions")
async def get_decisions(limit: int = Query(default=10, ge=1, le=100), req: Request = None):
    state = _state(req)
    try:
        decisions = state.engine.get_decision_history(limit=limit)
        return {"decisions": decisions}
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/executions")
async def get_executions(limit: int = Query(default=20, ge=1, le=200), req: Request = None):
    """执行记录（确认/拒绝/下单留痕）"""
    state = _state(req)
    try:
        return {"executions": state.engine.db.get_executions(limit=limit)}
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---- 确认决策 ----

@app.post("/api/decision/{decision_id}/confirm")
async def confirm_decision(decision_id: int, body: ConfirmRequest, req: Request):
    state = _state(req)
    try:
        result = state.engine.confirm_manual(
            decision_id=decision_id,
            confirmed=body.confirmed,
            notes=body.notes,
        )
        return result
    except DecisionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))


# ---- 推荐饰品 ----

@app.get("/api/item/suggestions")
async def get_suggestions():
    from config import MONITORED_ITEMS
    return {"items": MONITORED_ITEMS}


# ---- 我的库存（BUFF Steam 库存真实数据）----

@app.get("/api/inventory")
async def get_inventory(
    game: str = Query('csgo'),
    page_num: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=100),
    platform: str = Query(default='buff'),
    req: Request = None,
):
    state = _state(req)
    p = platform or 'buff'
    if p != 'buff':
        raise HTTPException(status_code=400, detail="库存页目前只支持 BUFF 平台（Steam 库存由 BUFF 接口读取）")
    if not state.cookie:
        raise HTTPException(status_code=401, detail="未登录：请先在「登录设置」扫码或一键登录后再查看库存")
    try:
        fetcher = state.get_fetcher('buff')
        return fetcher.fetch_inventory(game=game, page_num=page_num, page_size=page_size)
    except AuthenticationError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except DataFetchError as e:
        raise HTTPException(status_code=502, detail=str(e))


# ==================== 交易执行 ====================

@app.post("/api/trade/buy")
async def trade_buy(body: TradeBuyRequest, req: Request):
    """执行买入订单（需已确认的决策）"""
    state = _state(req)
    try:
        trader = state.get_trader(body.platform)

        # 查询决策记录
        db = TradeDatabase()
        decisions = state.engine.get_decision_history(limit=500)
        decision = None
        for d in decisions:
            if d.get('id') == body.decision_id:
                decision = d
                break
        if not decision:
            raise HTTPException(status_code=404, detail=f"决策 ID {body.decision_id} 不存在")

        # 原子抢占：仅当决策仍为 confirmed 时置为 executing，
        # 防止同一 confirmed 决策被并发 / 超时重试重复买入（受影响行数=0 即拒绝）
        if not db.claim_decision_for_execution(body.decision_id):
            raise HTTPException(
                status_code=409,
                detail="决策未确认，或已在执行 / 已执行，拒绝重复买入",
            )

        # 构造决策字典
        decision_dict = {
            'id': decision['id'],
            'item': decision.get('item_name', ''),
            'price': decision.get('current_price', 0),
            'quantity': decision.get('suggested_quantity', 0),
            'min_sell_date': '',
        }

        try:
            result = state.order_executor.execute_buy(
                decision=decision_dict,
                platform=body.platform,
                trader=trader,
                item_id=body.item_id,
                order_options={
                    "pay_method": body.pay_method,
                    "pay_password": body.pay_password,
                    "steamid": body.steamid,
                },
            )
        except Exception:
            # execute_buy 抛异常 = 下单阶段失败（尚未成交，见 order_executor 的成交后记账处理）。
            # 回滚决策为 confirmed，便于用户修正后重试。
            # 注意：成交后记账失败不会走到这里——execute_buy 会返回 filled_pending_record。
            db.set_decision_status(body.decision_id, 'confirmed', expect='executing')
            raise

        # 成功（含 filled_pending_record，均代表已成交）→ 决策置为终态 executed
        db.set_decision_status(body.decision_id, 'executed', expect='executing')
        return result

    except (TradeExecutionError, InsufficientBalanceError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    except AuthenticationError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"交易执行失败: {e}")


@app.post("/api/trade/sell")
async def trade_sell(body: TradeSellRequest, req: Request):
    """执行卖出挂单"""
    state = _state(req)
    try:
        trader = state.get_trader(body.platform)
        db = TradeDatabase()

        # 查询持仓
        positions = db.get_positions(platform=body.platform, limit=500)
        position = None
        for p in positions:
            if p.get('id') == body.position_id:
                position = p
                break
        if not position:
            raise HTTPException(status_code=404, detail=f"持仓 ID {body.position_id} 不存在")

        result = state.order_executor.execute_sell(
            position=position,
            sell_price=body.sell_price,
            platform=body.platform,
            trader=trader,
            item_id=body.item_id,
        )
        return result

    except (TradeExecutionError, InsufficientBalanceError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    except AuthenticationError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"卖出执行失败: {e}")


@app.post("/api/trade/cancel")
async def trade_cancel(body: TradeCancelRequest, req: Request):
    """取消挂单"""
    state = _state(req)
    try:
        trader = state.get_trader(body.platform)
        result = state.order_executor.cancel_order(
            order_pk=body.order_pk,
            platform=body.platform,
            trader=trader,
        )
        return result
    except TradeExecutionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except AuthenticationError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"取消订单失败: {e}")


@app.get("/api/trade/orders")
async def trade_orders(
    req: Request,
    status: str = Query(default=None),
    platform: str = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
):
    """查询订单列表"""
    state = _state(req)
    try:
        db = TradeDatabase()
        p = platform or state.current_platform
        orders = db.get_orders(status=status, platform=p, limit=limit)
        return {"orders": orders}
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/trade/positions")
async def trade_positions(
    req: Request,
    status: str = Query(default=None),
    platform: str = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
):
    """查询持仓列表"""
    state = _state(req)
    try:
        db = TradeDatabase()
        p = platform or state.current_platform
        positions = db.get_positions(status=status, platform=p, limit=limit)
        return {"positions": positions}
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/trade/balance")
async def trade_balance(req: Request, platform: str = Query(default=None)):
    """查询账户余额（BUFF 走真实接口 /api/asset/get_brief_asset/）"""
    state = _state(req)
    p = platform or state.current_platform
    try:
        trader = state.get_trader(p)
        detail = None
        if hasattr(trader, "get_balance_detail"):
            detail = trader.get_balance_detail()
            balance = detail.get("available", 0.0)
        else:
            balance = trader.get_balance()
        return {"platform": p, "balance": balance, "detail": detail}
    except AuthenticationError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except DataFetchError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"查询余额失败: {e}")


@app.post("/api/trade/steam-login")
async def steam_login(body: SteamLoginRequest, req: Request):
    """Steam 账号登录（获取交易 session）"""
    state = _state(req)
    try:
        from steam_login import SteamLogin
        login = SteamLogin()
        result = login.login(
            username=body.username,
            password=body.password,
            shared_secret=body.shared_secret,
        )
        if result.get('success'):
            # 初始化 SteamTrader
            from steam_trader import SteamTrader
            state.steam_trader = SteamTrader(session_cookies=result['cookies'])
            return {"status": "ok", "message": "Steam 登录成功"}
        raise HTTPException(status_code=401, detail=result.get('message', '登录失败'))
    except HTTPException:
        # 登录失败等业务错误直接透出，不要被下面的兜底分支改写成 500
        raise
    except ImportError as e:
        raise HTTPException(
            status_code=501,
            detail=(
                "Steam 登录缺少依赖 pycryptodome（RSA 加密需要）。"
                "安装版已内置该依赖；若是源码运行，请执行: pip install pycryptodome"
                f"（原始错误：{e}）"
            ),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Steam 登录失败: {e}")


# ==================== 秒发货 (Auto Delivery) ====================

@app.get("/api/delivery/status")
async def delivery_status(req: Request):
    """查询自动发货监控状态"""
    state = _state(req)
    monitor = state.ensure_trade_monitor()
    if monitor is None:
        return {
            "running": False,
            "enabled": False,
            "auto_accept": False,
            "total_detected": 0,
            "total_delivered": 0,
            "total_failed": 0,
            "last_poll": None,
            "last_error": "BUFF 未登录，自动发货未就绪" if not state.cookie else None,
            "poll_interval": 30,
            "max_delivery_amount": 0,
            "pending_count": 0,
        }
    return monitor.stats


@app.post("/api/delivery/toggle")
async def delivery_toggle(body: DeliveryToggleRequest, req: Request):
    """开启/关闭自动发货"""
    state = _state(req)
    if body.enabled:
        # 需要 buff_trader 已初始化
        try:
            trader = state.get_trader("buff")
        except AuthenticationError:
            raise HTTPException(
                status_code=401,
                detail="BUFF 未登录，无法启动自动发货"
            )
        monitor = state.ensure_trade_monitor()
        if monitor is None:
            raise HTTPException(status_code=500, detail="无法初始化发货监控")
        monitor.toggle(True)
        if not monitor.is_running:
            await monitor.start()
        return {"status": "enabled", "message": "自动发货已开启"}
    else:
        monitor = state.trade_monitor
        if monitor:
            monitor.toggle(False)
            await monitor.stop()
        return {"status": "disabled", "message": "自动发货已关闭"}


@app.get("/api/delivery/pending")
async def delivery_pending(
    req: Request,
    limit: int = Query(default=20, ge=1, le=100),
):
    """查询待发货列表：先从 BUFF 真实接口拉一次（mode=2），再返回本地留痕"""
    state = _state(req)
    monitor = state.ensure_trade_monitor()
    live_error = None
    if monitor is None:
        live_error = "BUFF 未登录，无法读取待发货（先扫码/一键登录）"
    else:
        try:
            await monitor.poll_once()
        except Exception as e:
            live_error = f"拉取待发货失败：{e}"
            logger.warning(f"拉取待发货失败: {e}")
    db = TradeDatabase()
    deliveries = db.get_deliveries(status="pending", limit=limit)
    return {"deliveries": deliveries, "live_error": live_error}


@app.get("/api/delivery/history")
async def delivery_history(
    req: Request,
    status: str = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
):
    """查询发货历史"""
    db = TradeDatabase()
    deliveries = db.get_deliveries(status=status, limit=limit)
    return {"deliveries": deliveries}


@app.post("/api/delivery/accept")
async def delivery_accept(body: DeliveryManualAcceptRequest, req: Request):
    """手动确认发货"""
    state = _state(req)
    monitor = state.ensure_trade_monitor()
    if monitor is None:
        raise HTTPException(status_code=400, detail="BUFF 交易器未初始化")
    try:
        result = await monitor.manual_accept(body.delivery_pk)
        return result
    except TradeExecutionError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/delivery/accept-all")
async def delivery_accept_all(req: Request):
    """一键发货：把当前所有待发货订单交给 BUFF 真实发货接口"""
    state = _state(req)
    monitor = state.ensure_trade_monitor()
    if monitor is None:
        raise HTTPException(status_code=400, detail="BUFF 交易器未初始化，请先登录")
    try:
        return await monitor.manual_accept_all()
    except TradeExecutionError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ==================== 每日推荐购入 ====================

def _recommend_budget(state) -> Optional[float]:
    """用当前 BUFF 可用余额作为「买得起」的判断基准；拿不到就不标记"""
    try:
        trader = state.get_trader('buff')
        balance = trader.get_balance_detail()
        return float(balance.get('available') or 0) or None
    except Exception:
        return None


@app.get("/api/recommend/daily")
async def recommend_daily(
    req: Request,
    limit: int = Query(default=8, ge=3, le=12),
    refresh: bool = Query(default=False),
):
    """每日推荐：综合整体趋势/热门分类/热销在售/涨幅榜 + 30 天历史打分"""
    state = _state(req)
    if not state.cookie:
        raise HTTPException(status_code=401, detail="BUFF 未登录，无法生成推荐（先扫码或一键登录）")
    recommender = state.ensure_recommender()
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            lambda: recommender.build(limit=limit, budget=_recommend_budget(state), force=refresh),
        )
    except DataFetchError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        logger.exception("生成每日推荐失败")
        raise HTTPException(status_code=500, detail=f"生成每日推荐失败: {e}")


@app.post("/api/recommend/refresh")
async def recommend_refresh(req: Request, limit: int = Query(default=8, ge=3, le=12)):
    """强制重算推荐（忽略当天缓存）"""
    state = _state(req)
    if not state.cookie:
        raise HTTPException(status_code=401, detail="BUFF 未登录，无法生成推荐")
    recommender = state.ensure_recommender()
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            lambda: recommender.build(limit=limit, budget=_recommend_budget(state), force=True),
        )
    except DataFetchError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        logger.exception("刷新每日推荐失败")
        raise HTTPException(status_code=500, detail=f"刷新每日推荐失败: {e}")


@app.post("/api/delivery/refresh")
async def delivery_refresh(req: Request):
    """强制刷新：立即查询一次待发货"""
    state = _state(req)
    monitor = state.trade_monitor
    if monitor is None:
        raise HTTPException(status_code=400, detail="自动发货监控未初始化")
    await monitor.poll_once()
    return {"status": "ok", "message": "已刷新待发货列表"}


# ==================== 抓包 (Packet Capture) ====================

@app.post("/api/capture/browser/start", response_model=CaptureStatusResponse)
async def capture_browser_start(req: Request):
    """启动浏览器，等待用户登录 BUFF"""
    state = _state(req)
    browser = state.capture.get_browser()
    result = await browser.start()
    return CaptureStatusResponse(**result)


@app.get("/api/capture/browser/poll", response_model=CaptureStatusResponse)
async def capture_browser_poll(req: Request):
    """轮询浏览器登录状态"""
    state = _state(req)
    browser = state.capture.get_browser()
    result = await browser.poll()
    return CaptureStatusResponse(**result)


@app.post("/api/capture/browser/stop", response_model=CaptureStatusResponse)
async def capture_browser_stop(req: Request):
    """关闭浏览器"""
    state = _state(req)
    browser = state.capture.get_browser()
    result = await browser.stop()
    return CaptureStatusResponse(**result)


@app.post("/api/capture/proxy/start", response_model=CaptureStatusResponse)
async def capture_proxy_start(body: ProxyStartRequest, req: Request):
    """启动本地 HTTPS 代理服务器"""
    state = _state(req)
    proxy = state.capture.get_proxy(port=body.port)
    result = await proxy.start()
    return CaptureStatusResponse(**result)


@app.get("/api/capture/proxy/poll", response_model=CaptureStatusResponse)
async def capture_proxy_poll(req: Request):
    """轮询代理拦截状态"""
    state = _state(req)
    proxy = state.capture.get_proxy()
    result = proxy.poll()
    return CaptureStatusResponse(**result)


@app.post("/api/capture/proxy/stop", response_model=CaptureStatusResponse)
async def capture_proxy_stop(req: Request):
    """停止代理服务器"""
    state = _state(req)
    proxy = state.capture.get_proxy()
    result = await proxy.stop()
    return CaptureStatusResponse(**result)


@app.post("/api/capture/apply")
async def capture_apply(body: CaptureApplyRequest, req: Request):
    """将抓包获取的 Cookie 应用到系统"""
    state = _state(req)
    state.update_cookie(body.cookie)
    logger.info("抓包 Cookie 已应用到系统")
    return {"status": "ok", "message": "Cookie 已应用，系统已就绪"}


# ---- 系统关闭 ----
@app.post("/api/shutdown", summary="关闭系统")
async def shutdown_system(req: Request):
    """关闭后端服务，终止所有进程（需携带启动时生成的 shutdown token）"""
    token = req.headers.get("X-Shutdown-Token", "")
    if not token or not secrets.compare_digest(token, _SHUTDOWN_TOKEN):
        raise HTTPException(status_code=403, detail="shutdown token 无效")
    import threading
    def _shutdown():
        import time
        time.sleep(0.5)
        os.kill(os.getpid(), signal.SIGTERM)
    threading.Thread(target=_shutdown, daemon=True).start()
    return {"status": "ok", "message": "shutting down"}


# ---- 静态文件服务（前端构建产物） ----
_DIST_DIR = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "dist")
if _os.path.isdir(_DIST_DIR):
    app.mount("/assets", StaticFiles(directory=_os.path.join(_DIST_DIR, "assets")), name="static-assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        """SPA 回退：所有非 /api 路径返回 index.html"""
        index_file = _os.path.join(_DIST_DIR, "index.html")
        # 解析目标路径并校验仍在 _DIST_DIR 之内，防止 ../ 路径遍历读取 dist 外文件
        # （如 ../.env、../trade_decisions.db、源码等）。realpath 会规范化 .. 与符号链接。
        candidate = _os.path.realpath(_os.path.join(_DIST_DIR, full_path))
        dist_root = _os.path.realpath(_DIST_DIR)
        if (candidate == dist_root or candidate.startswith(dist_root + _os.sep)) \
                and _os.path.isfile(candidate):
            return FileResponse(candidate)
        # 非法路径或文件不存在 → SPA 路由回退到 index.html
        return FileResponse(index_file)


# ---- 启动 ----
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=API_PORT)
