"""
免登录多源行情聚合（虚拟盘增强）

数据源：
- BUFF：主报价，已有登录态时最准
- Skinport：公开 API，无需登录，CNY，覆盖全量饰品
- Steam：社区市场公开接口，弱网/被墙时自动跳过
- CSQAQ：公开大盘指数，作为领先市场冲击变量

设计原则：
- 任何一个源失败都不影响 BUFF 主流程
- 多源价格做加权，权重按数据质量和深度归一化
- 记录每次快照，后续用“较早更新源”的价格变化计算 lead_shock_z
"""

from __future__ import annotations

import gzip
import json
import logging
import math
import os
import sqlite3
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import paths

logger = logging.getLogger(__name__)

SOURCE_WEIGHTS = {
    "buff": 0.55,
    "skinport": 0.25,
    "steam": 0.20,
}

SKINPORT_URL = "https://api.skinport.com/v1/items"
CSQAQ_INDEX_URL = "https://api.csqaq.com/api/v1/current_data?type=init"


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _float(v, default=0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _clip(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


class SkinportCache:
    """Skinport 全量价格缓存。

    Skinport 只提供全量接口（约 15 MB），不能按单品查询；所以启动时后台拉一次，
    落盘 gzip 缓存，默认 6 小时刷新。首次请求最多等 6 秒，拿不到就跳过，不阻塞 BUFF。
    """

    def __init__(self, cache_path: Optional[str] = None, ttl_seconds: int = 21600):
        self.cache_path = cache_path or paths.data_path("cache/skinport_cny.json.gz")
        self.ttl_seconds = ttl_seconds
        self.items: Dict[str, Dict] = {}
        self.updated_at = 0.0
        self.last_error = ""
        self._lock = threading.Lock()
        self._event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        os.makedirs(os.path.dirname(self.cache_path), exist_ok=True)
        self._load_disk()
        if not self.items or self._stale():
            self.start_refresh()

    def _load_disk(self):
        try:
            with gzip.open(self.cache_path, "rt", encoding="utf-8") as f:
                payload = json.load(f)
            items = payload.get("items") or {}
            if isinstance(items, dict) and items:
                self.items = items
                self.updated_at = _float(payload.get("updated_at"))
                self._event.set()
                logger.info("Skinport 缓存已加载：%d 件", len(items))
        except FileNotFoundError:
            pass
        except Exception as exc:  # noqa: BLE001
            self.last_error = str(exc)
            logger.warning("Skinport 缓存读取失败: %s", exc)

    def _stale(self) -> bool:
        return (time.time() - self.updated_at) > self.ttl_seconds

    def start_refresh(self):
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._refresh, name="skinport-refresh", daemon=True)
            self._thread.start()

    def _refresh(self):
        try:
            import requests

            session = requests.Session()
            session.headers.update({
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) CSGO-Trading-Analyzer/2.0",
                "Accept": "application/json",
                "Accept-Encoding": "br, gzip, deflate",
            })
            r = session.get(
                SKINPORT_URL,
                params={"app_id": 730, "currency": "CNY"},
                timeout=45,
            )
            r.raise_for_status()
            data = r.json()
            items = {}
            for row in data or []:
                name = (row.get("market_hash_name") or "").strip()
                if not name:
                    continue
                items[name] = {
                    "market_hash_name": name,
                    "currency": row.get("currency") or "CNY",
                    "suggested_price": _float(row.get("suggested_price")),
                    "min_price": _float(row.get("min_price")),
                    "max_price": _float(row.get("max_price")),
                    "mean_price": _float(row.get("mean_price")),
                    "median_price": _float(row.get("median_price")),
                    "quantity": int(row.get("quantity") or 0),
                    "updated_at": int(row.get("updated_at") or 0),
                }
            if not items:
                raise RuntimeError("Skinport 返回空数据")
            with self._lock:
                self.items = items
                self.updated_at = time.time()
                self.last_error = ""
            payload = {"updated_at": self.updated_at, "items": items}
            tmp = self.cache_path + ".tmp"
            with gzip.open(tmp, "wt", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, self.cache_path)
            logger.info("Skinport 缓存刷新完成：%d 件", len(items))
        except Exception as exc:  # noqa: BLE001
            self.last_error = str(exc)
            logger.warning("Skinport 刷新失败: %s", exc)
        finally:
            self._event.set()

    def get(self, market_hash_name: str, wait_seconds: float = 5.0) -> Optional[Dict]:
        if not market_hash_name:
            return None
        if not self.items and not self._event.is_set():
            self._event.wait(timeout=wait_seconds)
        with self._lock:
            return self.items.get(market_hash_name)

    def status(self) -> Dict:
        return {
            "available": bool(self.items),
            "count": len(self.items),
            "age_seconds": int(time.time() - self.updated_at) if self.updated_at else None,
            "stale": self._stale() if self.updated_at else True,
            "error": self.last_error,
        }


class CSQAQIndex:
    """CSQAQ 公开大盘指数（无需 ApiToken）。"""

    def __init__(self, ttl_seconds: int = 60):
        self.ttl_seconds = ttl_seconds
        self._cache: Dict = {}
        self._at = 0.0
        self._lock = threading.Lock()

    def get(self) -> Dict:
        with self._lock:
            if self._cache and (time.time() - self._at) < self.ttl_seconds:
                return self._cache
        try:
            import requests

            r = requests.get(
                CSQAQ_INDEX_URL,
                headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"},
                timeout=5,
            )
            r.raise_for_status()
            body = r.json()
            data = body.get("data") or {}
            rows = data.get("sub_index_data") or []
            target = next(
                (x for x in rows if x.get("name_key") == "init" or x.get("name") == "饰品指数"),
                rows[0] if rows else None,
            )
            if not target:
                return {}
            result = {
                "source": "csqaq",
                "name": target.get("name") or "饰品指数",
                "index": _float(target.get("market_index")),
                "change": _float(target.get("chg_num")),
                "change_pct": _float(target.get("chg_rate")),
                "updated_at": target.get("updated_at") or "",
            }
            with self._lock:
                self._cache = result
                self._at = time.time()
            return result
        except Exception as exc:  # noqa: BLE001
            logger.info("CSQAQ 大盘指数不可用: %s", exc)
            return {}


class MarketIntelDB:
    """记录多源快照，用于计算领先/滞后变化。"""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or paths.data_path("market_intel.db")
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with sqlite3.connect(self.db_path, timeout=20) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS source_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    goods_id TEXT,
                    market_hash_name TEXT,
                    source TEXT NOT NULL,
                    ask REAL DEFAULT 0,
                    bid REAL DEFAULT 0,
                    fair REAL DEFAULT 0,
                    volume INTEGER DEFAULT 0,
                    ts TEXT NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_source_snapshots_name_ts "
                "ON source_snapshots(market_hash_name, source, ts)"
            )
            conn.commit()

    def record(self, goods_id: str, name: str, sources: List[Dict]):
        now = _now_iso()
        rows = []
        for s in sources:
            if not s.get("available"):
                continue
            rows.append((
                str(goods_id), name, s.get("source"), _float(s.get("ask")),
                _float(s.get("bid")), _float(s.get("fair")), int(s.get("volume") or 0), now,
            ))
        if not rows:
            return
        with sqlite3.connect(self.db_path, timeout=20) as conn:
            conn.executemany(
                """INSERT INTO source_snapshots
                   (goods_id, market_hash_name, source, ask, bid, fair, volume, ts)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                rows,
            )
            conn.commit()

    def lead_return(self, name: str, source: str, current_ask: float,
                    min_age_minutes: int = 20, max_age_hours: int = 24) -> Optional[float]:
        """用 20 分钟前到 24 小时内的旧快照，算该源的价格变化。"""
        if not name or current_ask <= 0:
            return None
        now = datetime.now()
        older = (now - timedelta(minutes=min_age_minutes)).isoformat(timespec="seconds")
        oldest = (now - timedelta(hours=max_age_hours)).isoformat(timespec="seconds")
        try:
            with sqlite3.connect(self.db_path, timeout=20) as conn:
                row = conn.execute(
                    """SELECT ask FROM source_snapshots
                       WHERE market_hash_name=? AND source=? AND ts<=? AND ts>=?
                       ORDER BY ts DESC LIMIT 1""",
                    (name, source, older, oldest),
                ).fetchone()
            if not row:
                return None
            old_ask = _float(row[0])
            if old_ask <= 0:
                return None
            return current_ask / old_ask - 1.0
        except Exception:
            return None


class MarketIntel:
    """把多源报价合成一个加权估值，并给出领先市场冲击。"""

    def __init__(self, db_path: Optional[str] = None, steam_fetcher=None):
        self.db = MarketIntelDB(db_path)
        self.skinport = SkinportCache()
        self.csqaq = CSQAQIndex()
        self.steam_fetcher = steam_fetcher

    def set_steam_fetcher(self, fetcher):
        self.steam_fetcher = fetcher

    def augment(self, quote: Dict, steam_quote: Optional[Dict] = None,
                qty: int = 1, goods_id: str = "") -> Dict:
        name = (quote.get("market_hash_name") or "").strip()
        ask = _float(quote.get("ask"))
        bid = _float(quote.get("bid"))
        buff_fair = (ask + bid) / 2.0 if ask > 0 and bid > 0 else ask
        sources = [{
            "source": "buff",
            "label": "BUFF",
            "available": ask > 0,
            "ask": round(ask, 2),
            "bid": round(bid, 2),
            "fair": round(buff_fair, 2),
            "volume": int(quote.get("daily_volume") or 0),
            "weight": SOURCE_WEIGHTS["buff"],
            "note": "主报价 / 实际买入价",
        }]

        skin = self.skinport.get(name, wait_seconds=5.0) if name else None
        if skin:
            s_ask = _float(skin.get("min_price")) or _float(skin.get("suggested_price"))
            s_fair = _float(skin.get("suggested_price")) or _float(skin.get("median_price")) or s_ask
            sources.append({
                "source": "skinport",
                "label": "Skinport",
                "available": s_ask > 0,
                "ask": round(s_ask, 2),
                "bid": 0.0,
                "fair": round(s_fair, 2),
                "volume": int(skin.get("quantity") or 0),
                "weight": SOURCE_WEIGHTS["skinport"],
                "note": "免登录公开盘",
            })
        else:
            sources.append({
                "source": "skinport",
                "label": "Skinport",
                "available": False,
                "ask": 0.0,
                "bid": 0.0,
                "fair": 0.0,
                "volume": 0,
                "weight": SOURCE_WEIGHTS["skinport"],
                "note": self.skinport.status().get("error") or "缓存加载中",
            })

        if steam_quote and steam_quote.get("available"):
            sources.append({
                "source": "steam",
                "label": "Steam",
                "available": True,
                "ask": round(_float(steam_quote.get("buy_price")), 2),
                "bid": round(_float(steam_quote.get("exit_price")) * 0.95, 2),
                "fair": round(_float(steam_quote.get("exit_price")), 2),
                "volume": 0,
                "weight": SOURCE_WEIGHTS["steam"],
                "note": "公开社区市场，弱网时可能缺失",
            })
        else:
            sources.append({
                "source": "steam",
                "label": "Steam",
                "available": False,
                "ask": 0.0,
                "bid": 0.0,
                "fair": 0.0,
                "volume": 0,
                "weight": SOURCE_WEIGHTS["steam"],
                "note": (steam_quote or {}).get("reason") or "未获取",
            })

        avail = [s for s in sources if s.get("available") and s.get("ask", 0) > 0]
        total_w = sum(s["weight"] for s in avail) or 1.0
        for s in sources:
            s["weight_pct"] = round((s["weight"] / total_w) * 100.0, 1) if s.get("available") else 0.0
        weighted_ask = sum(s["ask"] * s["weight"] for s in avail) / total_w if avail else ask
        weighted_fair = sum(s["fair"] * s["weight"] for s in avail) / total_w if avail else buff_fair
        asks = [s["ask"] for s in avail]
        divergence = 0.0
        if len(asks) >= 2 and weighted_fair > 0:
            divergence = round((max(asks) - min(asks)) / weighted_fair * 100.0, 2)

        # 领先冲击：优先用较早更新源（Skinport）的历史变化，否则用 CSQAQ 大盘。
        lead_return = None
        skin_ask = next((s["ask"] for s in sources if s["source"] == "skinport" and s["available"]), 0)
        if name and skin_ask:
            lead_return = self.db.lead_return(name, "skinport", skin_ask)
        market = self.csqaq.get()
        lead_z = 0.0
        lead_source = "none"
        if lead_return is not None:
            lead_z = _clip(lead_return / 0.02, -2.0, 2.0)
            lead_source = "skinport_history"
        elif market:
            lead_z = _clip(_float(market.get("change_pct")) / 1.5, -2.0, 2.0)
            lead_source = "csqaq_index"
        confidence = "low"
        if len(avail) >= 3 and divergence <= 8:
            confidence = "high"
        elif len(avail) >= 2 and divergence <= 15:
            confidence = "medium"

        result = {
            "weighted_ask": round(weighted_ask, 2),
            "weighted_fair": round(weighted_fair, 2),
            "weighted_bid": round(bid, 2),
            "divergence_pct": divergence,
            "source_count": len(avail),
            "sources": sources,
            "confidence": confidence,
            "lead_shock_z": round(lead_z, 4),
            "lead_shock_source": lead_source,
            "lead_return_pct": round((lead_return or 0.0) * 100.0, 3),
            "market_index": market.get("index"),
            "market_change_pct": market.get("change_pct"),
            "market_index_at": market.get("updated_at"),
            "valuation_gap_pct": round((weighted_fair / buff_fair - 1.0) * 100.0, 2) if buff_fair else 0.0,
            "skinport": self.skinport.status(),
        }
        self.db.record(goods_id or quote.get("goods_id"), name, sources)
        return result
