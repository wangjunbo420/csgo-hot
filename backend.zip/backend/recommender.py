"""
每日「推荐购入」引擎

数据全部来自 BUFF 真实接口，综合四路信号：
1. 整体趋势  /api/market/leaderboard/price_trend/overview   （大盘热度、7 日涨跌）
2. 热门分类  /api/market/leaderboard/price_trend/list       （各品类 7 日涨跌幅）
3. 热销在售  /api/index/popular_sell_order                  （真实成交人气）
4. 涨幅榜    /api/market/leaderboard/goods_price_incr/v3    （短期动量）
再对每个候选拉 30 天价格历史 / sell_num / 最高求购，按金融学的多因子加权打分：

    综合分 = 动量 25 + 板块 15 + 流动性 20 + 估值 15 + 风险 15 + 人气 10

每个因子先做横截面百分位归一化（0~100），避免"价格量纲不同"直接相加的偏差；
最终给 0~100 分 + 评级 + 可解释的理由标签。

结果按天缓存（12 小时），避免频繁打 BUFF 接口。
"""
from __future__ import annotations

import json
import logging
import math
import os
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import paths
from exceptions import DataFetchError

logger = logging.getLogger(__name__)

# 品类关键词 → 与 BUFF 分类榜单的 name 对齐
# 顺序很重要：先按武器类型匹配，再看印花/箱子等（否则「印花集」这种皮肤名会被误判成印花）
CATEGORY_KEYWORDS = [
    ("手套", ["手套"]),
    ("匕首", ["★", "匕首", "刀"]),
    ("狙击枪", ["AWP", "SSG 08", "SCAR-20", "G3SG1"]),
    ("步枪", ["AK-47", "M4A4", "M4A1", "加利尔", "FAMAS", "AUG", "SG 553"]),
    ("微型冲锋枪", ["MP9", "MAC-10", "UMP-45", "P90", "PP-野牛", "MP7", "MP5"]),
    ("手枪", ["格洛克", "USP", "P250", "沙漠之鹰", "Tec-9", "CZ75", "Five-SeveN", "R8"]),
    ("霰弹枪", ["新星", "XM1014", "MAG-7", "Sawed-Off", "截短霰弹枪"]),
    ("机枪", ["M249", "内格夫"]),
    ("印花", ["印花 |", "印花（", "Sticker |"]),
    ("挂件", ["挂件 |", "挂件（", "Charm |"]),
    ("探员", ["探员 |", "探员（"]),
    ("武器箱", ["武器箱", "Case"]),
]

WEIGHTS = {"momentum": 25, "sector": 15, "liquidity": 20, "valuation": 15, "risk": 15, "popularity": 10}
MAX_CANDIDATES = 18
MIN_PRICE = 20.0          # 单价过低，手续费/点差占比太高，不进推荐
MIN_SELL_NUM = 5.0        # 30 天平均在售太少 → 流动性差，不进推荐
AFFORDABLE_BONUS = 5.0    # 预算内可买的给一点加分，避免榜单全是"看得买不起"


def _rank_score(c: Dict) -> float:
    """人气原始分：榜单名次越靠前越高（不直接做百分位，避免同档并列全被归一成 0）"""
    score = 0.0
    hot_rank = c.get("hot_rank")
    if hot_rank:
        try:
            score += max(0.0, 100.0 - (int(hot_rank) - 1) * 8.0)
        except (TypeError, ValueError):
            score += 40.0
    incr_rank = c.get("incr_rank")
    if incr_rank:
        try:
            score += max(0.0, 60.0 - (int(incr_rank) - 1) * 4.0)
        except (TypeError, ValueError):
            score += 20.0
    return score if score > 0 else 15.0


def _pct(values: List[Optional[float]]) -> List[float]:
    """横截面百分位归一化：返回 0~100（值越大越好）。None 视为最差的一半。"""
    valid = [v for v in values if v is not None]
    if not valid:
        return [50.0] * len(values)
    out = []
    for v in values:
        if v is None:
            out.append(35.0)
            continue
        count_less = sum(1 for x in valid if x < v)
        out.append(round(100.0 * count_less / max(1, len(valid) - 1), 1))
    return out


def _daily_close(series: List[Dict]) -> List[float]:
    """把小时级采样压成每日收盘价（取每天最后一个点）"""
    by_day: Dict[str, float] = {}
    for p in series:
        ts = p.get("ts") or 0
        try:
            day = datetime.fromtimestamp(ts / 1000).strftime("%Y-%m-%d")
        except (OSError, OverflowError, ValueError):
            continue
        by_day[day] = p["price"]
    return [by_day[k] for k in sorted(by_day)]


def _std(values: List[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    var = sum((v - mean) ** 2 for v in values) / (len(values) - 1)
    return math.sqrt(var)


class DailyRecommender:
    def __init__(self, fetcher, db_path: Optional[str] = None):
        self.fetcher = fetcher
        self.db_path = db_path or os.path.join(paths.data_dir(), "trade_decisions.db")
        self._ensure_table()

    # ---------- 缓存 ----------
    def _conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_table(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS daily_recommendations (
                    rec_date TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)

    def _load_cache(self, rec_date: str) -> Optional[Dict]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT payload, created_at FROM daily_recommendations WHERE rec_date = ?",
                (rec_date,),
            ).fetchone()
        if not row:
            return None
        try:
            payload = json.loads(row["payload"])
        except (TypeError, ValueError):
            return None
        payload["created_at"] = row["created_at"]
        return payload

    def _save_cache(self, rec_date: str, payload: Dict):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO daily_recommendations (rec_date, payload, created_at) VALUES (?, ?, ?)",
                (rec_date, json.dumps(payload, ensure_ascii=False), datetime.now().isoformat()),
            )

    # ---------- 主流程 ----------
    def build(self, limit: int = 8, budget: Optional[float] = None, force: bool = False) -> Dict:
        today = datetime.now().strftime("%Y-%m-%d")
        cached = None if force else self._load_cache(today)
        if cached and self._fresh(cached.get("created_at", ""), hours=12):
            cached["cached"] = True
            if budget is not None:
                for item in cached.get("items", []):
                    item["affordable"] = item.get("price", 0) <= budget
            return cached

        insights = self.fetcher.fetch_market_insights()
        candidates = self._collect_candidates(insights)
        if not candidates:
            raise DataFetchError("推荐数据不可用：BUFF 榜单接口没有返回候选饰品")

        scored = []
        for cand in candidates[:MAX_CANDIDATES]:
            try:
                series = self.fetcher.fetch_goods_series(cand["goods_id"], days=30)
            except Exception as e:
                logger.warning(f"推荐候选 {cand.get('name')} 历史拉取失败: {e}")
                continue
            metrics = self._metrics(series)
            if not metrics:
                continue
            # 过滤掉“看着便宜但没法操作”的标的：单价太低 / 在售太薄 / 预算差太多
            if metrics["price"] < MIN_PRICE:
                continue
            if metrics["sell_num_avg"] and metrics["sell_num_avg"] < MIN_SELL_NUM:
                continue
            cand.update(metrics)
            cand["sector"] = self._sector_signal(cand.get("name", ""), insights.get("categories", []))
            scored.append(cand)

        if not scored:
            raise DataFetchError("推荐数据不可用：候选饰品都没有可用的 30 天价格历史")

        result = self._score(scored, insights, budget=budget, limit=limit)
        result["created_at"] = datetime.now().isoformat()
        result["cached"] = False
        self._save_cache(today, result)
        return result

    @staticmethod
    def _fresh(created_at: str, hours: int) -> bool:
        try:
            return datetime.now() - datetime.fromisoformat(created_at) < timedelta(hours=hours)
        except (TypeError, ValueError):
            return False

    def _collect_candidates(self, insights: Dict) -> List[Dict]:
        out: Dict[str, Dict] = {}
        for item in insights.get("hot_items", []):
            gid = str(item.get("goods_id") or "")
            if not gid:
                continue
            out[gid] = {
                "goods_id": gid,
                "name": item.get("name") or "",
                "market_hash_name": item.get("market_hash_name") or "",
                "icon_url": item.get("icon_url") or "",
                "hot_rank": item.get("hot_rank"),
                "source": "热销在售",
            }
        for item in insights.get("incr_items", []):
            gid = str(item.get("goods_id") or "")
            if not gid or not item.get("name"):
                continue
            if gid in out:
                out[gid]["incr_rank"] = item.get("rank")
                out[gid]["source"] += " / 涨幅榜"
                continue
            out[gid] = {
                "goods_id": gid,
                "name": item.get("name") or "",
                "market_hash_name": item.get("market_hash_name") or "",
                "icon_url": item.get("icon_url") or "",
                "incr_rank": item.get("rank"),
                "source": "涨幅榜",
            }
        return list(out.values())

    def _metrics(self, series: List[Dict]) -> Dict:
        if not series or len(series) < 3:
            return {}
        prices = [p["price"] for p in series]
        sells = [p.get("sell_num") or 0 for p in series]
        buys = [p.get("buy_max") or 0 for p in series]
        ts = [p.get("ts") or 0 for p in series]
        now = prices[-1]

        def price_at(days: int):
            target = ts[-1] - days * 86400 * 1000
            nearest = None
            for t, p in zip(ts, prices):
                if t >= target:
                    nearest = p
                    break
            return nearest if nearest else prices[0]

        p7 = price_at(7)
        p30 = prices[0]
        daily = _daily_close(series)
        rets = [(daily[i] / daily[i - 1] - 1) for i in range(1, len(daily)) if daily[i - 1] > 0]
        avg30 = sum(prices) / len(prices)
        max30, min30 = max(prices), min(prices)
        buy_now = next((b for b in reversed(buys) if b > 0), 0)

        return {
            "price": round(now, 2),
            "ret_7d": round((now / p7 - 1) * 100, 2) if p7 else 0.0,
            "ret_30d": round((now / p30 - 1) * 100, 2) if p30 else 0.0,
            "avg_30d": round(avg30, 2),
            "vs_avg30": round((now / avg30 - 1) * 100, 2) if avg30 else 0.0,
            "drawdown": round((now / max30 - 1) * 100, 2) if max30 else 0.0,
            "volatility": round(_std(rets) * 100, 2),
            "sell_num": int(sells[-1] if sells else 0),
            "sell_num_avg": int(sum(sells) / len(sells)) if sells else 0,
            "buy_max": round(buy_now, 2),
            "spread": round((now - buy_now) / now * 100, 2) if buy_now and now else 0.0,
            "points": len(series),
            "first_date": series[0].get("date", ""),
            "last_date": series[-1].get("date", ""),
        }

    def _sector_signal(self, name: str, categories: List[Dict]) -> Dict:
        category = ""
        for cat_name, keywords in CATEGORY_KEYWORDS:
            if any(k and k in (name or "") for k in keywords):
                category = cat_name
                break
        for cat in categories:
            if cat.get("name") and cat["name"] == category:
                return {"name": cat.get("name"), "incr_rate": cat.get("incr_rate", 0)}
        return {"name": category or "未分类", "incr_rate": 0.0}

    def _score(self, cands: List[Dict], insights: Dict, budget: Optional[float], limit: int) -> Dict:
        macro = insights.get("overview", {}) or {}
        hot7 = macro.get("hottest_7d") or 0
        over7 = macro.get("overview_7d") or 0
        # 大盘偏弱时，动量权重下调、风险权重上调
        risk_off = 1 if over7 < 0 else 0

        norms = {
            "momentum": _pct([0.55 * c["ret_7d"] + 0.45 * c["ret_30d"] for c in cands]),
            "sector": _pct([c["sector"].get("incr_rate", 0) for c in cands]),
            "liquidity": _pct([math.log1p(max(0, c["sell_num_avg"])) for c in cands]),
            "valuation": _pct([c["vs_avg30"] for c in cands]),  # 越低于均价越好 → 取负
            "risk": _pct([-(c["volatility"] * 1.2 - c["drawdown"]) for c in cands]),
            # 人气不能只看「上没上榜」（那样同处热销榜的候选分数全一样，百分位归一化后全变 0）。
            # 按榜单名次递减给分：热销榜第 1 名 100 分，每往后一名 -8；涨幅榜第 1 名 60 分，每名 -4。
            "popularity": _pct([_rank_score(c) for c in cands]),
        }
        # 估值项：低于 30 日均价才是"便宜"，方向取反
        max_vs = max([c["vs_avg30"] for c in cands] + [0])
        norms["valuation"] = _pct([max_vs - c["vs_avg30"] for c in cands])

        items = []
        for idx, c in enumerate(cands):
            score = (
                norms["momentum"][idx] * WEIGHTS["momentum"]
                + norms["sector"][idx] * WEIGHTS["sector"]
                + norms["liquidity"][idx] * WEIGHTS["liquidity"]
                + norms["valuation"][idx] * WEIGHTS["valuation"]
                + norms["risk"][idx] * WEIGHTS["risk"]
                + norms["popularity"][idx] * WEIGHTS["popularity"]
            ) / 100.0
            score = round(min(100.0, max(0.0, score)), 1)
            affordable = bool(budget and c["price"] <= budget)
            if affordable:
                score = round(min(100.0, score + AFFORDABLE_BONUS), 1)
            if score >= 74:
                rating = "强烈关注"
            elif score >= 64:
                rating = "值得关注"
            elif score >= 54:
                rating = "观察"
            else:
                rating = "暂不建议"

            reasons, warnings = self._reasons(c, risk_off)
            items.append({
                "goods_id": c["goods_id"],
                "name": c["name"],
                "market_hash_name": c.get("market_hash_name") or "",
                "icon_url": c.get("icon_url") or "",
                "price": c["price"],
                "ret_7d": c["ret_7d"],
                "ret_30d": c["ret_30d"],
                "avg_30d": c["avg_30d"],
                "vs_avg30": c["vs_avg30"],
                "drawdown": c["drawdown"],
                "volatility": c["volatility"],
                "sell_num": c["sell_num"],
                "sell_num_avg": c["sell_num_avg"],
                "buy_max": c["buy_max"],
                "spread": c["spread"],
                "category": c["sector"].get("name") or "未分类",
                "category_incr": c["sector"].get("incr_rate", 0),
                "hot_rank": c.get("hot_rank"),
                "source": c.get("source") or "",
                "score": score,
                "rating": rating,
                "factors": {
                    "动量": norms["momentum"][idx],
                    "板块": norms["sector"][idx],
                    "流动性": norms["liquidity"][idx],
                    "估值": norms["valuation"][idx],
                    "风险": norms["risk"][idx],
                    "人气": norms["popularity"][idx],
                },
                "reasons": reasons,
                "warnings": warnings,
                "affordable": (c["price"] <= budget) if budget else None,
            })

        items.sort(key=lambda x: x["score"], reverse=True)
        top = items[:limit]
        # 评级按当日候选池内的相对排名给（大盘整体偏弱时也能分出"相对最优"），
        # 同时保留绝对下限：分数太低一律"暂不建议"
        for idx, item in enumerate(top):
            if item["score"] < 42:
                item["rating"] = "暂不建议"
            elif idx < 2:
                item["rating"] = "强烈关注"
            elif idx < 4:
                item["rating"] = "值得关注"
            elif idx < 6:
                item["rating"] = "观察"
            else:
                item["rating"] = "暂不建议"
            item["rank"] = idx + 1

        return {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "items": top,
            "scanned": len(cands),
            "macro": {
                "online": macro.get("online"),
                "hottest_1d": macro.get("hottest_1d"),
                "hottest_7d": macro.get("hottest_7d"),
                "overview_1d": macro.get("overview_1d"),
                "overview_7d": macro.get("overview_7d"),
                "regime": "偏弱（提高风险权重）" if risk_off else "偏强/平稳",
            },
            "categories": [
                {"name": c.get("name"), "incr_rate": c.get("incr_rate", 0)}
                for c in (insights.get("categories") or [])[:10]
            ],
            "weights": WEIGHTS,
            "method": (
                "综合分 = 动量25 + 板块15 + 流动性20 + 估值15 + 风险15 + 人气10；"
                "每个因子先按候选池做百分位归一化，再线性加权。"
                "动量=7日与30日涨幅加权；板块=所属品类 7 日涨跌；流动性=30 天平均在售量（对数）；"
                "估值=相对 30 日均价的折价；风险=波动率与回撤；人气=热销在售/涨幅榜上榜情况。"
            ),
            "disclaimer": "基于公开行情与历史统计的概率性判断，不是收益承诺；饰品价格受赛事、版本、市场情绪影响，务必自己复核后小额试单。",
            "errors": insights.get("errors") or [],
        }

    def _reasons(self, c: Dict, risk_off: int):
        reasons, warnings = [], []
        if c["ret_7d"] > 2:
            reasons.append(f"7 日上涨 {c['ret_7d']:.1f}%")
        if c["ret_30d"] > 4:
            reasons.append(f"30 日上涨 {c['ret_30d']:.1f}%")
        if c["vs_avg30"] < -3:
            reasons.append(f"低于 30 日均价 {abs(c['vs_avg30']):.1f}%，有回归空间")
        if c["drawdown"] < -8:
            reasons.append(f"距 30 日高点回撤 {abs(c['drawdown']):.1f}%，风险已释放一部分")
        if c["sell_num_avg"] >= 50:
            reasons.append(f"30 天平均在售 {c['sell_num_avg']} 件，流动性好")
        if c["spread"] > 3:
            reasons.append(f"求购价距售价 {c['spread']:.1f}%，买盘较厚")
        if c.get("hot_rank"):
            reasons.append(f"热销在售榜第 {c['hot_rank']} 位")
        if (c.get("sector") or {}).get("incr_rate", 0) > 0.3:
            reasons.append(
                f"所属「{c['sector'].get('name') or '品类'}」7 日涨 {c['sector']['incr_rate']:.2f}%"
            )

        if c["volatility"] > 8:
            warnings.append(f"30 天日波动 {c['volatility']:.1f}%，波动偏大")
        if c["sell_num_avg"] and c["sell_num_avg"] < 15:
            warnings.append("在售量偏少，流动性偏薄")
        if c["ret_30d"] < -10:
            warnings.append("30 日趋势仍在下行，注意接飞刀")
        if c["price"] < 30:
            warnings.append("单价过低，手续费与点差占比高")
        if risk_off:
            warnings.append("大盘 7 日为负，建议控制仓位")

        return reasons[:4], warnings[:3]
