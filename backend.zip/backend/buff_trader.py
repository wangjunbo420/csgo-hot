import logging
from typing import Dict, List, Optional

import requests

from base_trader import BaseTrader
from data_fetcher import RateLimiter
from exceptions import DataFetchError

logger = logging.getLogger(__name__)


class BuffTrader(BaseTrader):
    """BUFF163 trading client implementing the BaseTrader interface."""

    BASE_URL = "https://buff.163.com"
    # 请求超时（秒）：BUFF 无响应时防止线程永久挂起、耗尽 run_in_executor 默认线程池
    TIMEOUT_WRITE = 10   # 下单 / 取消 / 确认发货等写操作
    TIMEOUT_READ = 15    # 余额 / 订单 / 库存 / 待发货 / 通知等查询

    def __init__(self, session: requests.Session, game: str = "csgo"):
        self.session = session
        self.game = game
        self.rate_limiter = RateLimiter()
        self._csrf_token = self._extract_csrf_token()

    def _extract_csrf_token(self) -> str:
        """Extract CSRF token from session cookies."""
        for cookie in self.session.cookies:
            if cookie.name == "csrf_token":
                return cookie.value
        logger.warning("csrf_token cookie not found in session")
        return ""

    def _headers(self, with_csrf: bool = False) -> Dict[str, str]:
        """Build request headers.

        注意：这里不再写死 Content-Type: application/json。
        Django 看到这个头会把 GET 的请求体当 JSON 解析，空体直接报
        "Invalid Argument / This field is required"（实测待发货列表就是这样挂的），
        POST 用 json= 时 requests 会自动带上正确的 Content-Type。
        """
        headers = {
            "Referer": "https://buff.163.com/",
            "Accept": "application/json, text/plain, */*",
        }
        if with_csrf:
            # 注意必须是 X-CSRFToken（Django 的 CSRF_HEADER_NAME 默认是 HTTP_X_CSRFTOKEN，
            # 写成 X-CSRF-Token 会被当成另一个头，服务端识别不到 → 403）
            headers["X-CSRFToken"] = self._csrf_token
        return headers

    def _check_response(self, resp: requests.Response, action: str) -> dict:
        """Validate BUFF API response and return the data payload."""
        resp.raise_for_status()
        body = resp.json()
        code = body.get("code")
        if code != "OK":
            # 把 BUFF 的英文错误码翻成人能看懂的话，避免前端只看到 404/500
            hint = {
                "Login Required": "未登录或登录已失效，请重新扫码/一键登录",
                "Access Denied": "账号无权限或触发了风控，请在 BUFF 网页上确认",
                "Invalid Argument": "参数不合法（缺少必填字段）",
                "Request Rate Will Be Limited": "操作太频繁，已被 BUFF 限速，请稍后再试",
            }.get(code, "")
            raise DataFetchError(
                f"BUFF 接口返回 {code}"
                + (f"：{hint}" if hint else "")
                + (f"（{body.get('error')}）" if body.get("error") else "")
            )
        return body.get("data", {})

    # ------------------------------------------------------------------
    # BaseTrader interface
    # ------------------------------------------------------------------

    def place_buy_order(
        self, item_id, price, quantity, **kwargs
    ) -> Dict:
        """Place a buy order.

        Returns {'order_id', 'status', 'total_cost'}.
        """
        self.rate_limiter.wait_if_needed()
        payload = {
            "game": self.game,
            "goods_id": str(item_id),
            "price": float(price),
            "num": int(quantity),
            "pay_method": kwargs.get("pay_method", "buff"),
            "allow_tradable_cooldown": 0,
            "passback_params": "",
            "specific": [],
            # 网页端下单固定带这个字段，缺失时 BUFF 会回 Invalid Argument（This field is required.）
            "hide_non_epay": bool(kwargs.get("hide_non_epay", False)),
        }
        # 网页端会带 password 键（未设置支付密码时为空串），缺 key 会被判 This field is required.
        payload["password"] = str(kwargs.get("pay_password") or "")
        # 网页端会带 steamid（单账号时是空字符串）；缺这个 key 会被判 This field is required.
        payload["steamid"] = str(kwargs.get("steamid") or "")
        try:
            # BUFF 的下单接口是表单编码（application/x-www-form-urlencoded），
            # 用 json= 提交会被判成空表单，统一返回 Invalid Argument / This field is required。
            resp = self.session.post(
                f"{self.BASE_URL}/api/market/buy_order/create",
                data=payload,
                headers=self._headers(with_csrf=True),
                timeout=self.TIMEOUT_WRITE,
            )
            data = self._check_response(resp, "place_buy_order")
            order_id = str(data.get("id") or data.get("buy_order_id") or "")
            return {
                "order_id": order_id,
                "status": data.get("status", "created"),
                "total_cost": float(price) * int(quantity),
            }
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"Failed to place buy order: {e}") from e

    def place_sell_order(
        self, item_id, asset_id, price, **kwargs
    ) -> Dict:
        """Place a sell order.

        Returns {'order_id', 'status'}.
        """
        self.rate_limiter.wait_if_needed()
        if not asset_id:
            raise DataFetchError(
                "BUFF 上架出售必须提供库存资产 assetid（请先在 BUFF 库存里选择具体那一件）"
            )
        asset = {
            "assetid": str(asset_id),
            "goods_id": str(item_id),
            "price": float(price),
        }
        if kwargs.get("remark"):
            asset["custom_description"] = kwargs["remark"]
        payload = {
            "game": self.game,
            "assets": [asset],
        }
        if kwargs.get("steamid"):
            payload["steamid"] = str(kwargs["steamid"])
        try:
            resp = self.session.post(
                f"{self.BASE_URL}/api/market/sell_order/create/manual",
                json=payload,
                headers=self._headers(with_csrf=True),
                timeout=self.TIMEOUT_WRITE,
            )
            data = self._check_response(resp, "place_sell_order")
            # 返回结构可能是 {assetid: "OK"} / {"id": ...}
            order_id = ""
            if isinstance(data, dict):
                order_id = str(data.get("id") or data.get(str(asset_id), ""))
            return {
                "order_id": order_id,
                "status": "created",
            }
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"Failed to place sell order: {e}") from e

    def cancel_order(self, order_id, order_type="buy") -> Dict:
        """Cancel an existing order.

        Returns {'status': 'cancelled'}.
        """
        self.rate_limiter.wait_if_needed()
        # 真实接口：撤求购 POST /api/market/buy_order/cancel {game, buy_orders:[id]}
        #           撤出售 POST /api/market/sell_order/cancel {game, sell_orders:[id]}
        if order_type == "sell":
            url = f"{self.BASE_URL}/api/market/sell_order/cancel"
            payload = {"game": self.game, "sell_orders": [str(order_id)]}
        else:
            url = f"{self.BASE_URL}/api/market/buy_order/cancel"
            payload = {"game": self.game, "buy_orders": [str(order_id)]}

        try:
            resp = self.session.post(
                url,
                json=payload,
                headers=self._headers(with_csrf=True),
                timeout=self.TIMEOUT_WRITE,
            )
            data = self._check_response(resp, f"cancel_{order_type}_order")
            # 逐单结果：{"<order_id>": "OK"} / {"<order_id>": "错误原因"}
            if isinstance(data, dict) and str(order_id) in data:
                detail = data[str(order_id)]
                if detail != "OK":
                    raise DataFetchError(f"撤销失败: {detail}")
            return {"status": "cancelled"}
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"Failed to cancel order: {e}") from e

    @staticmethod
    def _money(value) -> float:
        """把 BUFF 返回的金额字段（可能是字符串 / 分）统一成元"""
        try:
            amount = float(value)
        except (TypeError, ValueError):
            return 0.0
        return amount

    def get_balance_detail(self) -> Dict:
        """查询资产概览（真实接口：GET /api/asset/get_brief_asset/）

        返回 {'available': 可用余额(元), 'trade': 交易中金额, 'pending': 待结算,
              'details': [{name, amount}], 'raw': 原始字段}
        """
        self.rate_limiter.wait_if_needed()
        try:
            resp = self.session.get(
                f"{self.BASE_URL}/api/asset/get_brief_asset/",
                headers=self._headers(),
                timeout=self.TIMEOUT_READ,
            )
            data = self._check_response(resp, "get_balance")

            available = self._money(data.get("cash_amount"))
            if available <= 0:
                available = self._money(data.get("cash_amount_inner"))

            details = []
            for item in data.get("cash_amount_details") or []:
                if not isinstance(item, dict):
                    continue
                name = item.get("name") or item.get("title") or ""
                amount = self._money(item.get("amount") or item.get("value"))
                if name:
                    details.append({"name": str(name), "amount": amount})

            return {
                "available": round(available, 2),
                "trade": round(self._money(data.get("cash_amount_inner")), 2),
                "pending": round(self._money(data.get("cash_amount_outer")), 2),
                "details": details,
                "raw": {
                    k: v for k, v in data.items()
                    if isinstance(v, (int, float, str))
                },
            }
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"Failed to get balance: {e}") from e

    def get_balance(self) -> float:
        """Return available balance in CNY."""
        return self.get_balance_detail()["available"]

    def get_open_orders(self) -> List[Dict]:
        """Return list of my on-sale orders.

        真实接口只提供「我的出售中」列表（GET /api/market/sell_order/on_sale）；
        BUFF 没有公开的「我的求购」JSON 列表，求购部分返回空并在日志里说明。
        """
        orders: List[Dict] = []
        self.rate_limiter.wait_if_needed()
        try:
            resp = self.session.get(
                f"{self.BASE_URL}/api/market/sell_order/on_sale",
                params={"game": self.game, "page_num": 1, "page_size": 100},
                headers=self._headers(),
                timeout=self.TIMEOUT_READ,
            )
            data = self._check_response(resp, "get_open_orders")
            for item in data.get("items", []) or []:
                orders.append({
                    "order_id": str(item.get("id") or item.get("sell_order_id") or ""),
                    "order_type": "sell",
                    "item_id": str(item.get("goods_id", "")),
                    "price": float(item.get("price", 0) or 0),
                    "status": item.get("state_text") or item.get("state", ""),
                })
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"Failed to get on-sale orders: {e}") from e

        logger.info("BUFF 未提供「我的求购」列表接口，求购订单请在 BUFF 网页查看")
        return orders

    def get_inventory(self) -> List[Dict]:
        """Return list of inventory items."""
        self.rate_limiter.wait_if_needed()
        try:
            resp = self.session.get(
                f"{self.BASE_URL}/api/market/steam_inventory",
                params={
                    "game": self.game,
                    "page_num": 1,
                    "page_size": 20,
                },
                headers=self._headers(),
                timeout=self.TIMEOUT_READ,
            )
            data = self._check_response(resp, "get_inventory")
            items = data.get("items", [])
            result = []
            for item in items:
                asset_info = item.get("asset_info") or {}
                result.append({
                    "asset_id": str(item.get("assetid") or item.get("asset_id") or ""),
                    "item_id": str(item.get("goods_id", "")),
                    "name": item.get("goods_name") or asset_info.get("goods_name", ""),
                    "market_price": float(item.get("price") or item.get("market_price") or 0),
                })
            return result
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"Failed to get inventory: {e}") from e

    # ------------------------------------------------------------------
    # 发货相关 API（秒发货功能）
    # ------------------------------------------------------------------

    def get_pending_deliveries(self, page_num: int = 1,
                               page_size: int = 20) -> List[Dict]:
        """待发货列表（真实接口）。

        BUFF 网页「等待发货」页调用的是卖家订单接口带 mode=2：
            GET /api/market/sell_order/on_sale?game=csgo&mode=2&page_num=..&page_size=..
        mode=2 返回的就是「买家已付款、等待我发货」的单，mode=5 是正在寄售。
        返回项里的 id 就是后面发货要用的 bill_order_id。
        """
        self.rate_limiter.wait_if_needed()
        try:
            resp = self.session.get(
                f"{self.BASE_URL}/api/market/sell_order/on_sale",
                params={
                    "game": self.game,
                    "mode": "2",
                    "page_num": int(page_num),
                    "page_size": int(page_size),
                },
                headers={
                    **self._headers(),
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": f"{self.BASE_URL}/market/sell_order/to_deliver?game={self.game}",
                },
                timeout=self.TIMEOUT_READ,
            )
            data = self._check_response(resp, "get_pending_deliveries")
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"获取待发货列表失败: {e}") from e

        goods_infos = data.get("goods_infos") or {}
        user_infos = data.get("user_infos") or {}
        result: List[Dict] = []
        for item in data.get("items") or []:
            asset_info = item.get("asset_info") or {}
            goods_id = str(item.get("goods_id") or asset_info.get("goods_id") or "")
            info = goods_infos.get(goods_id) or {}
            name = info.get("name") or info.get("short_name") or asset_info.get("goods_name") or ""
            paintwear = asset_info.get("paintwear")
            if paintwear:
                name = f"{name} (磨损 {float(paintwear):.4f})" if name else name
            buyer_id = item.get("buyer_id") or item.get("user_id") or ""
            buyer = (user_infos.get(str(buyer_id)) or {}).get("nickname") or buyer_id
            result.append({
                # 这里 item.id 是 bill_order_id，发货接口按这个下单
                "order_id": str(item.get("id") or ""),
                "item_name": name,
                "asset_id": str(asset_info.get("assetid") or ""),
                "goods_id": goods_id,
                "buyer_name": str(buyer or ""),
                "price": float(item.get("price") or 0),
                "state": item.get("state"),
                "mode": item.get("mode"),
                "trade_id": "",
            })
        return result

    def _deliver_hint(self, code: str, error: str = "") -> str:
        """发货接口的错误码翻译：这几条都是卖家侧配置问题，讲清楚比抛英文强"""
        hints = {
            "Steam Trade URL Binding Required": "还没绑定 Steam 交易链接：BUFF 网页 → 个人中心 → Steam 设置里填交易链接（https://steamcommunity.com/tradeoffer/new/?partner=…）",
            "Steam Trade Hold Duration Invalid": "Steam 账号处于交易冷却（Trade Hold），这段时间 BUFF 不能代发，等冷却结束再试",
            "Steam Account Not Bound": "还没绑定 Steam 账号，先在 BUFF 个人中心完成绑定",
            "Steam Account Is Unbound": "还没绑定 Steam 账号，先在 BUFF 个人中心完成绑定",
            "Steam Trade URL Invalid": "Steam 交易链接失效了，去 Steam 重新生成并更新到 BUFF",
            "Inventory Not Enough": "库存里没有这件饰品了（可能已卖出或已下架）",
            "Order Status Error": "订单状态已变化（可能已被别人处理或已超时）",
            "Request Rate Will Be Limited": "操作太频繁，被 BUFF 限速，稍后重试",
            "Login Required": "登录已失效，请重新登录 BUFF",
        }
        base = f"BUFF 接口返回 {code}"
        hint = hints.get(code, "")
        if hint:
            base += f"：{hint}"
        if error:
            base += f"（{error}）"
        return base

    def deliver_orders(self, bill_order_ids: List[str]) -> Dict:
        """批量确认发货（真实接口）。

        POST /api/market/bill_order/deliver  body: {"game": "csgo", "bill_orders": ["<id>", ...]}
        BUFF 收到后会用它自己绑定的 Steam 交易链接把饰品发给买家，所以本地不需要开 Steam。
        """
        ids = [str(i) for i in (bill_order_ids or []) if str(i).strip()]
        if not ids:
            raise DataFetchError("没有需要发货的订单号")
        self.rate_limiter.wait_if_needed()
        try:
            resp = self.session.post(
                f"{self.BASE_URL}/api/market/bill_order/deliver",
                json={"game": self.game, "bill_orders": ids},
                headers={
                    **self._headers(with_csrf=True),
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": f"{self.BASE_URL}/market/sell_order/to_deliver",
                },
                timeout=self.TIMEOUT_WRITE,
            )
            body = resp.json()
        except Exception as e:
            raise DataFetchError(f"发货请求失败: {e}") from e

        code = body.get("code")
        if code != "OK":
            raise DataFetchError(self._deliver_hint(str(code), str(body.get("error") or "")))

        data = body.get("data") or {}
        return {
            "status": "delivered",
            "order_ids": ids,
            "trade_id": str(data.get("trade_id") or data.get("tradeoffer_id") or ""),
            "raw": data,
        }

    def accept_delivery(self, order_id: str, trade_id: str = "") -> Dict:
        """单条发货（保留旧签名，内部走批量接口）"""
        result = self.deliver_orders([order_id])
        result["bill_order_id"] = str(order_id)
        return result

    def get_trade_notifications(self) -> List[Dict]:
        """
        查询交易通知

        Returns: [{'notification_id', 'type', 'message', ...}, ...]
        """
        self.rate_limiter.wait_if_needed()
        try:
            resp = self.session.get(
                f"{self.BASE_URL}/api/market/notifications",
                params={"page_num": 1, "page_size": 10},
                headers=self._headers(),
                timeout=self.TIMEOUT_READ,
            )
            data = self._check_response(resp, "get_trade_notifications")
            return data.get("items", [])
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(
                f"Failed to get notifications: {e}"
            ) from e
