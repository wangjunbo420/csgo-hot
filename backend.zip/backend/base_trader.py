"""
交易执行器抽象基类

定义统一的买卖接口，所有平台（BUFF、Steam）必须实现这些方法。
所有交易操作均需要手动确认后执行，内置安全检查。
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class BaseTrader(ABC):
    """交易执行器抽象基类"""

    @abstractmethod
    def place_buy_order(self, item_id: str, price: float, quantity: int,
                        **kwargs) -> Dict:
        """
        创建求购单（买入）

        Args:
            item_id: 物品标识（BUFF: goods_id, Steam: market_hash_name）
            price: 单价（人民币元）
            quantity: 数量

        Returns:
            {'order_id': str, 'status': 'submitted', 'total_cost': float}
        """

    @abstractmethod
    def place_sell_order(self, item_id: str, asset_id: str, price: float,
                         **kwargs) -> Dict:
        """
        创建出售挂单（卖出）

        Args:
            item_id: 物品标识
            asset_id: 资产 ID（Steam: assetid, BUFF: asset_id）
            price: 售价（人民币元）

        Returns:
            {'order_id': str, 'status': 'submitted'}
        """

    @abstractmethod
    def cancel_order(self, order_id: str, order_type: str = 'buy') -> Dict:
        """
        取消订单

        Args:
            order_id: 订单 ID
            order_type: 'buy' 或 'sell'

        Returns:
            {'status': 'cancelled'}
        """

    @abstractmethod
    def get_balance(self) -> float:
        """查询可用余额（人民币元）"""

    @abstractmethod
    def get_open_orders(self) -> List[Dict]:
        """
        查询当前挂单（求购 + 出售）

        Returns:
            [{'order_id', 'type', 'item_name', 'price', 'quantity', 'status'}, ...]
        """

    @abstractmethod
    def get_inventory(self) -> List[Dict]:
        """
        查询库存

        Returns:
            [{'asset_id', 'item_name', 'market_hash_name', ...}, ...]
        """
