"""
秒发货 - 自动发货监控服务

轮询 BUFF 待发货列表，检测到买家已付款的订单后自动确认发货。
设计为 asyncio.Task，在 FastAPI lifespan 中启动/停止。

工作流程:
1. 每 POLL_INTERVAL 秒查询一次 BUFF 待发货列表
2. 去重（通过 buff_order_id 唯一约束）
3. 安全校验（金额上限）
4. 调用 accept_delivery 自动发货
5. 写入 delivery_orders 表留痕
"""

import asyncio
import logging
from typing import Optional, Dict, List
from datetime import datetime

from config import AutoDeliveryConfig, TradeConfig
from trade_engine import TradeDatabase
from exceptions import TradeExecutionError, DataFetchError

logger = logging.getLogger(__name__)


class TradeMonitor:
    """BUFF 自动发货监控器"""

    def __init__(self, buff_trader, config: AutoDeliveryConfig = None,
                 db: TradeDatabase = None):
        self.trader = buff_trader
        self.config = config or AutoDeliveryConfig()
        self.db = db or TradeDatabase(TradeConfig().DATABASE_PATH)
        self._task: Optional[asyncio.Task] = None
        self._running: bool = False
        self._poll_lock = asyncio.Lock()
        self._last_poll: Optional[datetime] = None
        self._stats = {
            "total_detected": 0,
            "total_delivered": 0,
            "total_failed": 0,
            "last_error": None,
        }

    @property
    def is_running(self) -> bool:
        return self._running and self._task is not None and not self._task.done()

    @property
    def stats(self) -> dict:
        try:
            pending_count = len(self.db.get_deliveries(status="pending", limit=200))
        except Exception:
            pending_count = 0
        return {
            **self._stats,
            "last_poll": self._last_poll.isoformat() if self._last_poll else None,
            "enabled": self.config.ENABLED,
            "running": self.is_running,
            "auto_accept": self.config.AUTO_ACCEPT,
            "poll_interval": self.config.POLL_INTERVAL,
            "max_delivery_amount": self.config.MAX_DELIVERY_AMOUNT,
            "pending_count": pending_count,
        }

    # ── 生命周期 ──────────────────────────────────────────────

    async def start(self):
        """启动轮询任务"""
        if self._running:
            logger.warning("TradeMonitor 已在运行")
            return
        self._running = True
        self._task = asyncio.create_task(self._poll_loop())
        logger.info(
            f"TradeMonitor 已启动 (间隔={self.config.POLL_INTERVAL}s, "
            f"自动发货={self.config.AUTO_ACCEPT})"
        )

    async def stop(self):
        """优雅停止"""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("TradeMonitor 已停止")

    def toggle(self, enabled: bool):
        """运行时开关：开启时同时把「自动发货」打开（界面上这个开关就是自动发货）"""
        self.config.ENABLED = enabled
        self.config.AUTO_ACCEPT = enabled
        logger.info(
            f"自动发货已{'开启（每 %ss 轮询，单笔上限 ¥%s）' % (self.config.POLL_INTERVAL, self.config.MAX_DELIVERY_AMOUNT) if enabled else '关闭'}"
        )

    # ── 轮询循环 ──────────────────────────────────────────────

    async def _poll_loop(self):
        """主轮询循环，使用 asyncio.sleep 避免阻塞事件循环"""
        while self._running:
            try:
                if self.config.ENABLED:
                    await self._poll_once()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"轮询异常: {e}")
                self._stats["last_error"] = str(e)

            await asyncio.sleep(self.config.POLL_INTERVAL)

    async def _poll_once(self):
        """单次轮询：查询待发货 → 逐条处理（通过 asyncio.Lock 防并发）"""
        async with self._poll_lock:
            await self._poll_once_inner()

    async def poll_once(self):
        """公开接口：触发一次轮询（供 API 端点调用）"""
        await self._poll_once()

    async def _poll_once_inner(self):
        """内部轮询实现（由 _poll_once 加锁调用）"""
        self._last_poll = datetime.now()
        loop = asyncio.get_running_loop()

        try:
            pending = await loop.run_in_executor(
                None, self.trader.get_pending_deliveries
            )
        except DataFetchError as e:
            logger.warning(f"获取待发货列表失败: {e}")
            self._stats["last_error"] = str(e)
            return

        if not pending:
            logger.debug("无待发货订单")
            return

        logger.info(f"发现 {len(pending)} 个待发货订单")
        self._stats["total_detected"] += len(pending)

        for delivery in pending:
            if not self._running or not self.config.ENABLED:
                break
            await self._process_delivery(delivery)

    # ── 单条发货处理 ──────────────────────────────────────────

    async def _process_delivery(self, delivery: dict):
        """处理单条待发货订单：去重 → 安全检查 → 发货"""
        order_id = delivery["order_id"]

        # 去重
        existing = self.db.get_delivery_by_buff_order_id(order_id)
        if existing and existing["status"] in ("accepted", "delivered", "delivering"):
            logger.debug(f"订单 {order_id} 已处理过 ({existing['status']})，跳过")
            return

        # 金额安全检查
        if delivery["price"] > self.config.MAX_DELIVERY_AMOUNT:
            logger.warning(
                f"订单 {order_id} 金额 ¥{delivery['price']:,.2f} "
                f"超过上限 ¥{self.config.MAX_DELIVERY_AMOUNT:,.2f}，跳过"
            )
            self.db.save_delivery({
                "buff_order_id": order_id,
                "item_name": delivery["item_name"],
                "asset_id": delivery.get("asset_id", ""),
                "buyer_name": delivery.get("buyer_name", ""),
                "price": delivery["price"],
                "status": "skipped_amount_limit",
                "delivery_method": "auto",
                "error_message": "金额超过上限",
                "detected_at": datetime.now().isoformat(),
            })
            return

        # 记录到数据库
        delivery_pk = self.db.save_delivery({
            "buff_order_id": order_id,
            "item_name": delivery["item_name"],
            "asset_id": delivery.get("asset_id", ""),
            "buyer_name": delivery.get("buyer_name", ""),
            "price": delivery["price"],
            "status": "pending",
            "delivery_method": "auto" if self.config.AUTO_ACCEPT else "manual",
            "detected_at": datetime.now().isoformat(),
        })

        if not self.config.AUTO_ACCEPT:
            logger.info(f"订单 {order_id} 已记录（手动模式，等待用户操作）")
            return

        # 自动发货
        try:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.trader.accept_delivery(
                    order_id, delivery.get("trade_id", "")
                ),
            )
            now = datetime.now().isoformat()
            self.db.update_delivery_status(
                delivery_pk, "delivered",
                delivered_at=now,
                steam_trade_offer_id=result.get("trade_id", ""),
            )
            self._stats["total_delivered"] += 1
            logger.info(
                f"✓ 自动发货成功: {delivery['item_name']} "
                f"(订单 {order_id}) → {delivery.get('buyer_name', '?')}"
            )
        except Exception as e:
            self.db.update_delivery_status(
                delivery_pk, "failed",
                error_message=str(e),
            )
            self._stats["total_failed"] += 1
            self._stats["last_error"] = str(e)
            logger.error(f"✗ 发货失败: {order_id} — {e}")

    # ── 手动发货（API 调用） ──────────────────────────────────

    async def manual_accept(self, delivery_pk: int) -> dict:
        """手动确认发货（前端按钮触发）"""
        all_deliveries = self.db.get_deliveries(status="pending", limit=1000)
        delivery = None
        for d in all_deliveries:
            if d["id"] == delivery_pk:
                delivery = d
                break

        if not delivery:
            raise TradeExecutionError(
                f"发货记录 {delivery_pk} 不存在或状态非 pending"
            )

        try:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.trader.accept_delivery(
                    delivery["buff_order_id"],
                    delivery.get("trade_id", ""),
                ),
            )
            now = datetime.now().isoformat()
            self.db.update_delivery_status(
                delivery_pk, "delivered",
                delivered_at=now,
                steam_trade_offer_id=result.get("trade_id", ""),
            )
            self._stats["total_delivered"] += 1
            return {"status": "delivered", "delivery_pk": delivery_pk}
        except Exception as e:
            self.db.update_delivery_status(
                delivery_pk, "failed", error_message=str(e)
            )
            raise TradeExecutionError(f"手动发货失败: {e}")

    async def manual_accept_all(self) -> dict:
        """一键把当前所有待发货的订单交给 BUFF 发货（真实接口，支持批量）"""
        rows = self.db.get_deliveries(status="pending", limit=500)
        if not rows:
            return {"status": "empty", "message": "没有待发货订单", "delivered": 0, "failed": 0}

        loop = asyncio.get_running_loop()
        delivered, failures = 0, []
        now = datetime.now().isoformat()

        # 先整批调用一次：BUFF 的 deliver 接口支持 bill_orders 数组
        ids = [r["buff_order_id"] for r in rows if r.get("buff_order_id")]
        try:
            result = await loop.run_in_executor(None, lambda: self.trader.deliver_orders(ids))
            for r in rows:
                self.db.update_delivery_status(
                    r["id"], "delivered", delivered_at=now,
                    steam_trade_offer_id=result.get("trade_id", ""),
                )
            delivered = len(rows)
            self._stats["total_delivered"] += delivered
            return {
                "status": "delivered", "message": f"已批量发货 {delivered} 单",
                "delivered": delivered, "failed": 0,
            }
        except Exception as batch_err:
            # 批量失败就逐单重试，把具体哪一单失败留痕，而不是整批失败
            logger.warning(f"批量发货失败，改为逐单重试: {batch_err}")
            for r in rows:
                try:
                    await loop.run_in_executor(
                        None, lambda rid=r["buff_order_id"]: self.trader.accept_delivery(rid)
                    )
                    self.db.update_delivery_status(r["id"], "delivered", delivered_at=now)
                    delivered += 1
                    self._stats["total_delivered"] += 1
                except Exception as e:
                    self.db.update_delivery_status(r["id"], "failed", error_message=str(e))
                    failures.append({"order_id": r.get("buff_order_id"), "error": str(e)})
                    self._stats["total_failed"] += 1

        return {
            "status": "partial" if delivered else "failed",
            "message": f"发货 {delivered} 单，失败 {len(failures)} 单",
            "delivered": delivered, "failed": len(failures), "failures": failures,
        }
