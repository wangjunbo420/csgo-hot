"""
网易BUFF数据采集模块
【合规性声明】仅使用网易BUFF开放平台公开API，严格遵守速率限制
API文档：https://buff.163.com/api/doc
"""

import time
import random
import logging
import threading
import requests
from typing import Dict, List, Optional, Tuple
from datetime import datetime

from base_fetcher import BaseFetcher
from config import APIConfig
from exceptions import DataFetchError, APIRateLimitError

logger = logging.getLogger(__name__)


class RateLimiter:
    """请求频率控制器 — 严格实施 ≤10次/分钟 的限制"""

    def __init__(self, max_requests: int = APIConfig.MAX_REQUESTS_PER_MINUTE,
                 time_window: int = 60):
        self.max_requests = max_requests
        self.time_window = time_window
        self.request_times: list[float] = []
        self._lock = threading.Lock()

    def wait_if_needed(self):
        """如果需要，等待以确保不超过频率限制"""
        with self._lock:
            now = time.time()
            self.request_times = [
                t for t in self.request_times
                if now - t < self.time_window
            ]

            if len(self.request_times) >= self.max_requests:
                oldest_request = min(self.request_times)
                wait_time = self.time_window - (now - oldest_request)
                if wait_time > 0:
                    logger.warning(f"触发频率限制，等待 {wait_time:.2f} 秒")
                    time.sleep(wait_time)

            self.request_times.append(time.time())


class BuffDataFetcher(BaseFetcher):
    """
    网易BUFF数据采集器

    支持上下文管理器:
        with BuffDataFetcher(cookie="...") as fetcher:
            data = fetcher.fetch_item_price("AK-47 | Fire Serpent (Field-Tested)")
    """

    # 已知稀有饰品的 goods_id 映射表（搜索失败时的备用）
    _KNOWN_GOODS_IDS: Dict[str, str] = {
        "AK-47 | Fire Serpent": "34083",
        "AK-47 | Fire Serpent (Field-Tested)": "34083",
        "AK-47 | Fire Serpent (Minimal Wear)": "34083",
        "AK-47 | Fire Serpent (Factory New)": "34083",
        "AK-47 | Fire Serpent (Well-Worn)": "34083",
        "AK-47 | Fire Serpent (Battle-Scarred)": "34083",
        "AWP | Dragon Lore": "34085",
        "AWP | Dragon Lore (Field-Tested)": "34085",
        "AWP | Dragon Lore (Minimal Wear)": "34085",
        "AWP | Dragon Lore (Factory New)": "34085",
        "AWP | Dragon Lore (Well-Worn)": "34085",
        "AWP | Dragon Lore (Battle-Scarred)": "34085",
    }

    def __init__(self, api_key: Optional[str] = None, cookie: Optional[str] = None):
        self.config = APIConfig()
        self.rate_limiter = RateLimiter()
        self.session = requests.Session()
        self.current_proxy_index = 0

        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
        })

        if cookie:
            for cookie_item in cookie.split(';'):
                cookie_item = cookie_item.strip()
                if '=' in cookie_item:
                    name, value = cookie_item.split('=', 1)
                    self.session.cookies.set(name, value)
            logger.info("已设置Cookie认证")
        elif api_key:
            self.session.headers['Authorization'] = f'Bearer {api_key}'
            logger.info("已设置API Key认证")

    # ---- 上下文管理器 ----

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    # ---- 内部方法 ----

    def _get_proxy(self) -> Optional[Dict[str, str]]:
        if self.config.PROXY_POOL:
            proxy_url = self.config.PROXY_POOL[self.current_proxy_index]
            return {"http": proxy_url, "https": proxy_url}
        return None

    def _switch_proxy(self):
        if self.config.PROXY_POOL:
            self.current_proxy_index = (self.current_proxy_index + 1) % len(self.config.PROXY_POOL)
            logger.info(f"切换代理IP至: {self.config.PROXY_POOL[self.current_proxy_index]}")

    def _add_random_delay(self):
        delay = random.uniform(self.config.RANDOM_DELAY_MIN, self.config.RANDOM_DELAY_MAX)
        logger.debug(f"添加随机延迟: {delay:.2f}秒")
        time.sleep(delay)

    def _make_request(self, url: str, params: Dict = None, retry_count: int = 0) -> Dict:
        """发送HTTP请求（带重试机制）"""
        try:
            self.rate_limiter.wait_if_needed()

            proxies = self._get_proxy()
            response = self.session.get(
                url, params=params,
                timeout=self.config.TIMEOUT,
                proxies=proxies,
            )

            if response.status_code == 429:
                raise APIRateLimitError(
                    "API频率限制",
                    retry_after=int(response.headers.get('Retry-After', 60))
                )

            response.raise_for_status()
            data = response.json()

            if data.get('code') != 'OK':
                raise DataFetchError(
                    f"API返回错误: {data.get('msg', '未知错误')}",
                    status_code=response.status_code,
                    retry_count=retry_count
                )

            return data

        except requests.exceptions.Timeout:
            logger.warning(f"请求超时 (重试 {retry_count + 1}/{self.config.MAX_RETRY_COUNT})")
            if retry_count >= self.config.MAX_RETRY_COUNT:
                self._switch_proxy()
                raise DataFetchError("请求超时，已切换代理IP", retry_count=retry_count)
            raise DataFetchError("请求超时", retry_count=retry_count)

        except requests.exceptions.ConnectionError as e:
            logger.error(f"连接错误: {e}")
            if retry_count >= self.config.MAX_RETRY_COUNT:
                self._switch_proxy()
                raise DataFetchError("连接失败，已切换代理IP", retry_count=retry_count)
            raise DataFetchError("连接错误", retry_count=retry_count)

        except APIRateLimitError:
            raise

        except Exception as e:
            logger.error(f"未知错误: {e}")
            raise DataFetchError(f"请求异常: {e}", retry_count=retry_count)

    def _search_suggest_api(self, text: str, game: str = 'csgo') -> list:
        """调用搜索建议 API，返回 suggestions 列表"""
        url = f"{self.config.BASE_URL}/market/search/suggest"
        params = {'game': game, 'text': text}

        self.rate_limiter.wait_if_needed()
        proxies = self._get_proxy()
        try:
            response = self.session.get(url, params=params, timeout=self.config.TIMEOUT, proxies=proxies)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise DataFetchError(f"搜索请求失败: {e}")

        data = response.json()
        if data.get('code') != 'OK':
            logger.error(f"搜索API返回: {data}")
            msg = data.get('error') or data.get('msg') or '未知错误'
            if data.get('code') == 'Login Required':
                msg = "BUFF 需要登录后才能搜索，请先在「登录设置」扫码或一键登录"
            raise DataFetchError(f"搜索失败：{msg}")

        return data.get('data', {}).get('suggestions', [])

    def search_items(self, keyword: str, game: str = 'csgo', limit: int = 8) -> List[Dict]:
        """
        按关键字返回候选饰品列表（输入联想用）。

        数据源：BUFF 官方搜索建议接口 `/api/market/search/suggest`（公开，无需登录）。
        只返回「名称 + goods_id」，价格留给用户选定后再查，避免把价格挂到错误的饰品上。
        """
        suggestions = self._search_suggest_api(keyword, game)
        if not suggestions and '|' in keyword:
            suggestions = self._search_suggest_api(keyword.split('|')[0].strip(), game)

        results: List[Dict] = []
        for s in suggestions or []:
            gid = s.get('goods_ids') or s.get('goods_id') or s.get('id')
            if isinstance(gid, (list, tuple)):
                gid = gid[0] if gid else ''
            label = s.get('option') or s.get('name') or ''
            if not gid or not label:
                continue
            results.append({
                'goods_id': str(gid),
                'name': label,
                'market_hash_name': s.get('market_hash_name') or '',
                'price': 0.0,
                'sell_num': 0,
                'icon_url': s.get('icon_url') or '',
            })
            if len(results) >= limit:
                break
        return results

    @staticmethod
    def _to_float(value) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _to_int(value) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    # ---- 公开方法 ----

    def fetch_item_price(self, market_hash_name: str, game: str = 'csgo',
                         min_paintwear: Optional[float] = None,
                         max_paintwear: Optional[float] = None,
                         goods_id: Optional[str] = None) -> Dict:
        """
        获取饰品价格数据

        Args:
            goods_id: 已确定的具体饰品 ID（来自联想选择）。传了就按它查，
                      不再猜名字，保证「价格一定属于这个饰品」。

        Returns:
            {item_name, price_low, price_avg_7d, buy_order, paintwear, timestamp,
             goods_id, matched_name, match_type}
        """
        if goods_id:
            matched_name = market_hash_name
            match_type = 'selected'
        else:
            resolved = self.resolve_item(market_hash_name, game)
            if resolved['match_type'] == 'ambiguous':
                raise DataFetchError(
                    f"'{market_hash_name}' 对应 {len(resolved['candidates'])} 个不同饰品，"
                    f"无法确定是哪一个，请从候选中选择具体饰品"
                )
            goods_id = resolved['goods_id']
            matched_name = resolved['name'] or market_hash_name
            match_type = resolved['match_type']

        url = f"{self.config.BASE_URL}/market/goods/sell_order"
        params = {
            'game': game,
            'goods_id': goods_id,
            'page_num': 1,
            'page_size': 100,
        }

        if min_paintwear is not None:
            params['min_paintwear'] = str(min_paintwear)
        if max_paintwear is not None:
            params['max_paintwear'] = str(max_paintwear)

        logger.info(f"获取饰品价格数据: {market_hash_name} (goods_id={goods_id})")

        for attempt in range(self.config.MAX_RETRY_COUNT + 1):
            try:
                response_data = self._make_request(url, params, retry_count=attempt)
                result = self._parse_price_data(response_data, matched_name,
                                                goods_id=goods_id, game=game)
                # 把「这一份价格到底属于哪个饰品」明确带回前端
                result['goods_id'] = str(goods_id)
                # matched_name 用接口里的中文展示名，避免前端拿英文 market_hash_name 当标题
                result['matched_name'] = result.get('item_name') or matched_name
                result['match_type'] = match_type
                result['query_name'] = market_hash_name
                self._add_random_delay()
                return result
            except (DataFetchError, APIRateLimitError) as e:
                logger.warning(f"尝试 {attempt + 1}/{self.config.MAX_RETRY_COUNT + 1} 失败: {e}")
                if attempt == self.config.MAX_RETRY_COUNT:
                    raise
                wait = getattr(e, 'retry_after', None) or (2 ** attempt)
                time.sleep(wait)

    def resolve_item(self, query: str, game: str = 'csgo') -> Dict:
        """
        把用户输入的名字解析成「确定的一个饰品」。

        Returns:
            {'goods_id', 'name', 'match_type': exact|selected|ambiguous, 'candidates': [...]}

        关键原则：**名字不唯一时绝不猜**。以前是取第一个搜索结果直接报价，
        用户只输 "AK-47" 或 "火蛇" 就会拿到某个随机变体的价格且不知道是哪一个。
        """
        import re
        q = (query or '').strip()
        if not q:
            raise DataFetchError("请输入饰品名称")

        def norm(s: str) -> str:
            return re.sub(r'[\s\-_|]+', '', (s or '').lower())

        # 1) 已知 ID 映射：仅在完全同名时采用
        for known_name, goods_id in self._KNOWN_GOODS_IDS.items():
            if norm(known_name) == norm(q):
                return {'goods_id': str(goods_id), 'name': known_name,
                        'match_type': 'exact', 'candidates': []}

        # 2) 官方搜索建议
        suggestions = self._search_suggest_api(q, game)
        if not suggestions and '|' in q:
            suggestions = self._search_suggest_api(q.split('|')[0].strip(), game)
        if not suggestions:
            raise DataFetchError(f"未找到饰品：'{q}'，请检查名称或换个关键字")

        candidates = []
        for s in suggestions:
            gid = s.get('goods_ids') or s.get('goods_id')
            if isinstance(gid, (list, tuple)):
                gid = gid[0] if gid else ''
            label = s.get('option') or s.get('name') or ''
            if gid:
                candidates.append({'goods_id': str(gid), 'name': label})

        exact = [c for c in candidates if norm(c['name']) == norm(q)]
        if len(exact) == 1:
            return {'goods_id': exact[0]['goods_id'], 'name': exact[0]['name'],
                    'match_type': 'exact', 'candidates': []}
        if len(candidates) == 1:
            # 唯一候选：可以安全采用，但把真实名称一起返回，界面要显示清楚
            return {'goods_id': candidates[0]['goods_id'], 'name': candidates[0]['name'],
                    'match_type': 'unique', 'candidates': []}

        # 3) 有多个候选 → 交给用户选，不猜价格
        return {'goods_id': '', 'name': '', 'match_type': 'ambiguous', 'candidates': candidates}

    def _search_goods_id(self, market_hash_name: str, game: str = 'csgo') -> str:
        """
        搜索饰品获取 goods_id

        匹配策略（按优先级）：
        1. 已知 ID 映射表 — 仅做精确匹配（双向相等）
        2. 官方搜索 API — 精确匹配 > 第一个结果
        3. 简化名称搜索 fallback
        """
        # 1. 已知 ID 映射表 — 仅当查询名称包含在已知名称中 或 已知名称包含在查询名称中时匹配
        #    加入长度比例约束，防止 "AK-47" 匹配所有 AK-47 变体
        name_lower = market_hash_name.lower()
        for known_name, goods_id in self._KNOWN_GOODS_IDS.items():
            known_lower = known_name.lower()
            if known_lower == name_lower:
                logger.info(f"已知ID精确匹配: {market_hash_name} -> {goods_id}")
                return goods_id
            if name_lower in known_lower or known_lower in name_lower:
                # 长度比例保护：查询词至少要覆盖已知名称的 60%
                ratio = len(name_lower) / max(len(known_lower), 1)
                if ratio >= 0.6:
                    logger.info(f"已知ID模糊匹配 (ratio={ratio:.2f}): {market_hash_name} -> {goods_id}")
                    return goods_id

        # 2. 官方搜索 API
        suggestions = self._search_suggest_api(market_hash_name, game)

        if not suggestions:
            # 3. 简化搜索词 fallback
            simplified = market_hash_name.split('|')[0].strip() if '|' in market_hash_name else market_hash_name
            if simplified != market_hash_name:
                logger.warning(f"搜索 '{market_hash_name}' 无结果，尝试简化: '{simplified}'")
                suggestions = self._search_suggest_api(simplified, game)

            if not suggestions:
                raise DataFetchError(f"未找到饰品: '{market_hash_name}'，请检查名称是否正确")

        # 精确匹配
        for suggestion in suggestions:
            option = suggestion.get('option', '')
            if name_lower in option.lower() or option.lower() in name_lower:
                goods_id = suggestion.get('goods_ids')
                logger.info(f"API精确匹配: {option} (goods_id={goods_id})")
                return goods_id

        # 返回第一个结果
        goods_id = suggestions[0].get('goods_ids')
        option_name = suggestions[0].get('option')
        logger.warning(
            f"找到 {len(suggestions)} 个匹配结果，使用第一个: {option_name} (goods_id={goods_id})"
        )
        return goods_id

    def _fetch_price_history_v2(self, goods_id: str, days: int = 7,
                                game: str = 'csgo') -> Dict:
        """调用 BUFF 真实价格历史接口（需要登录 Cookie，否则返回空）"""
        url = f"{self.config.BASE_URL}/market/goods/price_history/buff/v2"
        params = {'game': game, 'goods_id': str(goods_id), 'days': days, 'currency': 'CNY'}
        try:
            response = self.session.get(url, params=params, timeout=self.config.TIMEOUT)
            response.raise_for_status()
            body = response.json()
        except Exception as e:
            logger.warning(f"价格历史接口请求失败: {e}")
            return {}
        if body.get('code') != 'OK':
            logger.warning(f"价格历史不可用: {body.get('code')} {body.get('error')}")
            return {}
        return body.get('data') or {}

    @staticmethod
    def _series_prices(series) -> List[float]:
        """把 BUFF 价格序列（[ts, price] 或 {p:..}）统一成价格列表"""
        prices: List[float] = []
        for item in series or []:
            value = None
            if isinstance(item, (list, tuple)):
                if len(item) >= 2:
                    value = item[1]
            elif isinstance(item, dict):
                value = (item.get('price') or item.get('p')
                         or item.get('sell_min_price') or item.get('value'))
            elif isinstance(item, (int, float)):
                value = item
            try:
                price = float(value)
            except (TypeError, ValueError):
                continue
            if price > 0:
                prices.append(price)
        return prices

    def _history_prices(self, data: Dict,
                        prefer=('sell_min_price_history', 'sell_price_history')) -> List[float]:
        """
        v2 接口的真实结构是 data.lines = [{key, name, points: [[ts, 价格], ...]}]，
        不是平铺的 sell_min_price_history 字段——之前按平铺字段取，所以均价恒为 0。
        这里按 lines 取，同时兼容平铺结构。
        """
        lines = (data or {}).get('lines') or []
        by_key = {}
        for line in lines:
            if isinstance(line, dict) and line.get('key'):
                by_key[line['key']] = line.get('points')
        for key in prefer:
            prices = self._series_prices(by_key.get(key))
            if prices:
                return prices
        for key in prefer:
            prices = self._series_prices((data or {}).get(key))
            if prices:
                return prices
        return []

    def _estimate_avg_7d(self, goods_id: str, goods_info: Dict,
                         price_low: Optional[float], game: str = 'csgo') -> float:
        """7 日均价：优先真实价格历史，其次候选字段，最后按最低价合理性兜底

        只要结果与当前最低售价严重不符（偏离超过 2.5 倍或低于 0.4 倍），
        就视为无效数据返回 0，避免用假均价算出 -81% 这种离谱偏离。
        """
        def plausible(value: float) -> bool:
            if value <= 0 or not price_low or price_low <= 0:
                return False
            return 0.4 * price_low <= value <= 2.5 * price_low

        candidate = 0.0
        if goods_id:
            data = self._fetch_price_history_v2(goods_id, days=7, game=game)
            prices = self._history_prices(data)
            if prices:
                candidate = sum(prices) / len(prices)
                logger.info(f"7日均价来自真实价格历史（{len(prices)} 个采样点）: {candidate:.2f}")

        if not plausible(candidate):
            for field in ('recent_avg_price', 'avg_price', 'price_7d'):
                raw = goods_info.get(field)
                try:
                    value = float(raw)
                except (TypeError, ValueError):
                    continue
                if plausible(value):
                    candidate = value
                    logger.info(f"7日均价来自 goods.{field}: {candidate:.2f}")
                    break
                if value > 0:
                    logger.warning(
                        f"goods.{field}={value} 与当前最低价 {price_low} 明显不符，已忽略"
                    )

        if not plausible(candidate):
            logger.warning("7日均价不可用（接口未返回或数据异常），本次标记为 N/A")
            return 0.0

        return round(candidate, 2)

    def _fetch_buy_order_price(self, goods_id: str, game: str = 'csgo') -> float:
        """取真实最高求购价（/api/market/goods/buy_order），失败返回 0（表示 N/A）

        注意：BUFF 的求购单可以带 `specific`（限定磨损区间/图案等），这类「特定磨损求购」
        出价往往远高于普通求购（实测王蛇 45486 有一单 6310 限定 0.07-0.08 磨损），
        直接取第一条会把「求购价」报成不真实的数。这里只取不带 specific 的普通求购单。
        """
        url = f"{self.config.BASE_URL}/market/goods/buy_order"
        params = {'game': game, 'goods_id': str(goods_id), 'page_num': 1, 'page_size': 100}
        try:
            response = self.session.get(url, params=params, timeout=self.config.TIMEOUT)
            response.raise_for_status()
            body = response.json()
        except Exception as e:
            logger.warning(f"求购价获取失败: {e}")
            return 0.0
        if body.get('code') != 'OK':
            logger.warning(f"求购价接口返回 {body.get('code')}")
            return 0.0
        items = (body.get('data') or {}).get('items') or []
        for item in items:
            if item.get('specific'):
                continue
            try:
                price = float(item.get('price', 0))
            except (TypeError, ValueError):
                continue
            if price > 0:
                return round(price, 2)
        return 0.0

    def _parse_price_data(self, api_response: Dict, item_name: str,
                          goods_id: Optional[str] = None,
                          game: str = 'csgo') -> Dict:
        """解析 API 响应，提取价格信息"""
        try:
            data = api_response.get('data', {})
            goods_info = data.get('goods', {})
            sell_orders = data.get('items', [])

            # 最低售价
            price_low = None
            first_item_paintwear = None
            if sell_orders:
                price_low = float(sell_orders[0].get('price', 0))
                asset_info = sell_orders[0].get('asset_info', {})
                # 印花/涂鸦这类没有磨损字段，BUFF 会返回空字符串，直接 float 会抛 ValueError
                try:
                    if asset_info.get('paintwear') not in (None, ''):
                        first_item_paintwear = float(asset_info['paintwear'])
                except (TypeError, ValueError):
                    first_item_paintwear = None

            # 7日均价：真实价格历史优先，并做合理性校验（不合理直接按 N/A 处理）
            price_avg_7d = self._estimate_avg_7d(goods_id, goods_info, price_low, game)
            # 拿不到可靠均价时不再用「在售订单均价」硬凑（那相当于拿当前价跟自己比，
            # 偏离度恒为 0，掩盖了真实数据缺口），直接保留 0 表示 N/A

            # 求购价：优先接口真实最高求购，拿不到就明确为 0（N/A）
            # 以前拿「最低价 × 95%」估算，等于自己造了一个不存在的价格，已删除。
            # goods_info.buyout_price 实测不是求购价（曾出现 6310 > 最低售价 2379 的离谱值），
            # 只认 buy_max_price / highest_buy_order；且必须低于最低售价（求购不可能高于在售最低），
            # 否则一律丢弃，改走 /market/goods/buy_order 拿真实最高求购。
            buy_order = float(
                goods_info.get('buy_max_price')
                or goods_info.get('highest_buy_order')
                or 0
            )
            plausible_buy = buy_order > 0 and price_low > 0 and buy_order <= price_low * 1.02
            if (not plausible_buy) and goods_id:
                buy_order = self._fetch_buy_order_price(goods_id, game)
                plausible_buy = buy_order > 0 and price_low > 0 and buy_order <= price_low * 1.05
            if not plausible_buy:
                buy_order = 0.0

            # 图片/分类信息：sell_order 接口把图标放在 data.goods_infos[goods_id] 里，
            # 不在 goods/items 上，单独取一次给「实时分析」页做物品主视觉。
            gid = str(goods_id or (sell_orders[0].get('goods_id') if sell_orders else '') or '')
            goods_meta = (data.get('goods_infos') or {}).get(gid) or {}
            meta_tags = goods_meta.get('tags') or {}

            result = {
                'item_name': goods_meta.get('name') or item_name,
                'goods_id': gid,
                'icon_url': goods_meta.get('icon_url') or '',
                'exterior': ((meta_tags.get('exterior') or {}).get('localized_name') or ''),
                'rarity': ((meta_tags.get('rarity') or {}).get('localized_name') or ''),
                'price_low': price_low,
                'price_avg_7d': price_avg_7d,
                'buy_order': buy_order,
                'paintwear': first_item_paintwear,
                'timestamp': datetime.now().isoformat(),
            }

            # 显式数据校验（替代 assert，生产环境安全）
            if result['price_low'] is None or result['price_low'] <= 0:
                raise DataFetchError("最低售价无效")

            logger.info(f"成功获取价格数据: {result}")
            return result

        except (KeyError, TypeError) as e:
            raise DataFetchError(f"数据解析失败: {e}")

    def fetch_price_history(self, market_hash_name: str, days: int = 7) -> list:
        """获取历史价格数据 → [(date, price, sell_num), ...]（兼容旧调用）"""
        series = self.fetch_price_history_series(market_hash_name, days)
        return [(p['date'], p['price'], p['sell_num']) for p in series]

    def fetch_price_history_series(self, market_hash_name: str, days: int = 7,
                                   goods_id: Optional[str] = None) -> list:
        """获取带时间戳的历史序列 → [{ts, date, price, sell_num, buy_max}, ...]

        修掉的两个问题：
        1. 原来只返回 "MM-DD HH:MM" 字符串，前端按「序号等距」画点，BUFF 的采样点
           间隔并不均匀（3~4 小时一次，还会跳点），等距画出来时间轴是错的；
        2. 原成交量按数组下标硬套 sell_num_history，价格点被跳过时下标会错位。
        这里按时间戳合并三条线，前端才能按真实时间画。
        """
        # 前端已经确认了具体 goods_id 时必须按 ID 取，避免名字重名/近似被解析成另一件
        gid = str(goods_id) if goods_id else self._search_goods_id(market_hash_name)
        data = self._fetch_price_history_v2(gid, days=days)
        series = self._series_from_v2(data, days)
        if not series:
            raise DataFetchError(
                "价格历史不可用：BUFF 未返回该饰品的价格曲线（可能未登录或该饰品近期无成交）"
            )
        self._add_random_delay()
        logger.info(f"价格历史来自 v2 接口: {len(series)} 个数据点")
        return series

    def fetch_goods_series(self, goods_id: str, days: int = 30, game: str = 'csgo') -> list:
        """按 goods_id 直接取历史序列（推荐引擎用，不再过一遍名字搜索）"""
        data = self._fetch_price_history_v2(str(goods_id), days=days, game=game)
        return self._series_from_v2(data, days)

    def _series_from_v2(self, data: Dict, days: int = 7) -> list:
        """把 v2 的 lines 按时间戳对齐成一条序列"""
        if not data:
            return []
        lines = data.get('lines') or []
        key_points = {}
        for line in lines:
            if isinstance(line, dict) and line.get('key'):
                key_points[line['key']] = line.get('points') or []

        def collect(key):
            out = {}
            for item in key_points.get(key) or []:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    try:
                        out[int(float(item[0]))] = float(item[1])
                    except (TypeError, ValueError):
                        continue
            return out

        prices = collect('sell_min_price_history')
        if not prices:
            # 只有成交价时的兜底
            prices = collect('sell_price_history')
        sells = collect('sell_num_history')
        buys = collect('buy_max_price_history')
        if not prices:
            return []

        cutoff = None
        try:
            cutoff = int((datetime.now().timestamp() - days * 86400) * 1000)
        except Exception:
            cutoff = None

        series = []
        for ts in sorted(prices.keys()):
            price = prices[ts]
            if price is None or price <= 0:
                continue
            if cutoff and ts < cutoff:
                continue
            try:
                stamp = datetime.fromtimestamp(ts / 1000).strftime('%m-%d %H:%M')
            except (OSError, OverflowError, ValueError):
                stamp = ''
            series.append({
                'ts': int(ts),
                'date': stamp,
                'price': round(float(price), 2),
                'sell_num': int(sells.get(ts, 0) or 0),
                'buy_max': round(float(buys.get(ts, 0) or 0), 2),
            })
        return series

    # ---- 市场整体趋势 / 热销 / 分类 / 涨幅榜（推荐页的数据源） ----

    def _get_json(self, path: str, params: Dict, with_csrf: bool = False) -> Dict:
        url = f"{self.config.BASE_URL}{path}"
        self.rate_limiter.wait_if_needed()
        response = self.session.get(url, params=params, timeout=self.config.TIMEOUT)
        response.raise_for_status()
        body = response.json()
        if body.get('code') != 'OK':
            raise DataFetchError(
                f"{path} 返回 {body.get('code')}: {body.get('error') or body.get('msg') or ''}"
            )
        return body.get('data') or {}

    def fetch_inventory(self, game: str = 'csgo', page_num: int = 1,
                        page_size: int = 50) -> Dict:
        """读取 BUFF「我的库存」(Steam 库存) 真实数据

        GET /api/market/steam_inventory?game=csgo&page_num=&page_size=
        返回体里 items 是饰品的每一件（含 assetid / 磨损 / 购入价），
        goods_infos 是按 goods_id 聚合的名称与图标。
        """
        import re
        data = self._get_json('/market/steam_inventory', {
            'game': game, 'page_num': page_num, 'page_size': page_size,
        })
        goods_infos = data.get('goods_infos') or {}
        items = []
        for row in (data.get('items') or []):
            gid = str(row.get('goods_id') or '')
            if not gid:
                continue
            info = goods_infos.get(gid) or {}
            extra = row.get('asset_extra') or {}

            def num(key, source=None):
                try:
                    return round(float((source or {}).get(key) or row.get(key) or 0), 2)
                except (TypeError, ValueError):
                    return 0.0

            items.append({
                'assetid': str(row.get('assetid') or ''),
                'goods_id': gid,
                'name': info.get('name') or row.get('name') or '',
                'market_hash_name': info.get('market_hash_name') or row.get('market_hash_name') or '',
                'icon_url': info.get('icon_url') or row.get('icon_url') or '',
                'amount': int(row.get('amount') or 1),
                'sell_min_price': num('sell_min_price'),
                'buy_max_price': num('buy_max_price'),
                'buy_price': round(float(extra.get('buy_price') or 0), 2),
                'sell_order_price': num('sell_order_price'),
                'sell_order_id': str(row.get('sell_order_id') or ''),
                'state_text': row.get('state_text') or '',
                'tradable_text': row.get('tradable_text') or '',
                'tags': row.get('tags') or [],
                'paintwear': (row.get('asset_info') or {}).get('paintwear') or '',
            })

        brief = data.get('brief_info') or ''
        count = None
        value = None
        m = re.search(r'件数[:：]\s*(\d+)', brief)
        if m:
            count = int(m.group(1))
        m = re.search(r'估值[:：]\s*[¥￥]?\s*([\d,]+(?:\.\d+)?)', brief)
        if m:
            value = float(m.group(1).replace(',', ''))

        return {
            'items': items,
            'total_count': data.get('total_count') or len(items),
            'page_num': page_num,
            'page_size': page_size,
            'brief_info': brief,
            'count': count,
            'estimated_value': value,
        }

    def fetch_market_insights(self, game: str = 'csgo') -> Dict:
        """一次性拉 BUFF 的：整体趋势、热门分类、热销在售、涨幅榜"""
        insights = {'overview': {}, 'categories': [], 'hot_items': [], 'incr_items': [], 'errors': []}

        try:
            overview = self._get_json('/market/leaderboard/price_trend/overview', {'game': game})
            insights['overview'] = {
                'online': overview.get('game_current_online_count'),
                'peak_1d': overview.get('game_peak_count_1_day'),
                'hottest_1d': overview.get('hottest_compare_1_day'),
                'hottest_7d': overview.get('hottest_compare_7_day'),
                'overview_1d': overview.get('overview_compare_1_day'),
                'overview_7d': overview.get('overview_compare_7_day'),
            }
        except Exception as e:
            insights['errors'].append(f'整体趋势: {e}')

        try:
            lst = self._get_json('/market/leaderboard/price_trend/list', {
                'game': game, 'page_num': 1, 'page_size': 30,
                'days': 7, 'sort_by': 'incr_rate.desc', 'price_type': 'sell_min_price',
            })
            cats = []
            for row in (lst.get('items') or []):
                try:
                    cats.append({
                        'key': row.get('item_key') or '',
                        'name': row.get('name') or '',
                        'incr_rate': float(row.get('incr_rate') or 0),
                        'trends': row.get('trends') or [],
                    })
                except (TypeError, ValueError):
                    continue
            insights['categories'] = cats
        except Exception as e:
            insights['errors'].append(f'热门分类: {e}')

        try:
            hot = self._get_json('/index/popular_sell_order', {'game': game})
            goods_infos = hot.get('goods_infos') or {}
            hot_items = []
            for idx, item in enumerate(hot.get('items') or []):
                gid = str(item.get('goods_id') or '')
                info = goods_infos.get(gid) or goods_infos.get(int(gid)) if gid.isdigit() else {}
                if not gid or not info:
                    continue
                hot_items.append({
                    'goods_id': gid,
                    'name': info.get('name') or '',
                    'market_hash_name': info.get('market_hash_name') or '',
                    'icon_url': info.get('icon_url') or '',
                    'price': float(item.get('price') or 0),
                    'hot_rank': idx + 1,
                })
            insights['hot_items'] = hot_items
        except Exception as e:
            insights['errors'].append(f'热销在售: {e}')

        try:
            inc = self._get_json('/market/leaderboard/goods_price_incr/v3', {
                'game': game, 'page_num': 1, 'page_size': 30,
            })
            goods_infos = inc.get('goods_infos') or {}
            incr = []
            for row in (inc.get('items') or []):
                gid = str(row.get('goods_id') or '')
                if not gid:
                    continue
                info = goods_infos.get(gid) or goods_infos.get(int(gid)) if gid.isdigit() else {}
                incr.append({
                    'goods_id': gid,
                    'name': (info or {}).get('name') or '',
                    'market_hash_name': (info or {}).get('market_hash_name') or '',
                    'icon_url': (info or {}).get('icon_url') or '',
                    'rank': row.get('rank'),
                })
            insights['incr_items'] = incr
        except Exception as e:
            insights['errors'].append(f'涨幅榜: {e}')

        return insights

    def _history_points(self, data: Dict, prefer=('sell_min_price_history',)) -> List[tuple]:
        """从 v2 的 lines 结构里取出 (时间戳, 数值) 序列"""
        lines = (data or {}).get('lines') or []
        by_key = {}
        for line in lines:
            if isinstance(line, dict) and line.get('key'):
                by_key[line['key']] = line.get('points')
        for key in prefer:
            output = []
            for item in by_key.get(key) or []:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    try:
                        output.append((item[0], float(item[1])))
                    except (TypeError, ValueError):
                        continue
            if output:
                return output
        return []

    def validate_auth(self) -> bool:
        """验证 Cookie 是否有效（发一个轻量搜索请求）"""
        try:
            self._search_suggest_api("AK")
            return True
        except Exception:
            return False

    def close(self):
        """关闭 HTTP 会话"""
        self.session.close()
        logger.info("数据采集器已关闭")
