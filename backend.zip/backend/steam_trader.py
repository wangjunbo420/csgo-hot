"""
Steam社区市场交易客户端

实现 BaseTrader 接口，通过 Steam 社区市场 API 执行买卖操作。
所有价格以人民币（CNY）元为单位，内部转换为分（cents）传输。
currency=23 对应 CNY。
"""

import re
import logging
import time
from typing import Dict, List, Optional
from urllib.parse import quote

import requests

from base_trader import BaseTrader
from data_fetcher import RateLimiter
from exceptions import DataFetchError

logger = logging.getLogger(__name__)

# Steam 市场相关常量
STEAM_MARKET_BASE = "https://steamcommunity.com/market"
STEAM_INVENTORY_BASE = "https://steamcommunity.com/inventory"
CSGO_APPID = 730
CSGO_CONTEXT_ID = "2"
CNY_CURRENCY = 23
DEFAULT_RATE_LIMIT = 8  # 请求/分钟


class SteamTrader(BaseTrader):
    """
    Steam 社区市场交易客户端

    用法:
        trader = SteamTrader(session_cookies={
            'sessionid': '...',
            'steamid': '76561198000000000',
            'steamLoginSecure': '...',
            'steamMachineAuth76561198000000000': '...',
        })
        balance = trader.get_balance()
        trader.place_buy_order("AK-47 | Redline (Field-Tested)", 50.0, 1)
    """

    def __init__(self, session_cookies: dict):
        """
        初始化 Steam 交易客户端

        Args:
            session_cookies: 包含 Steam 认证信息的字典，必须包含:
                - sessionid: Steam 会话 ID（所有写操作必需）
                - steamid: 用户 SteamID64（库存查询必需）
                - steamLoginSecure: 登录令牌
                - steamMachineAuth<steamid>: 机器认证令牌（可选）
        """
        self._validate_cookies(session_cookies)

        self.sessionid = session_cookies["sessionid"]
        self.steamid = session_cookies["steamid"]

        # 创建独立的 requests.Session 并注入 cookies
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        })

        for name, value in session_cookies.items():
            self.session.cookies.set(name, value)

        # 速率限制器：8 次请求/分钟
        self.rate_limiter = RateLimiter(
            max_requests=DEFAULT_RATE_LIMIT,
            time_window=60,
        )

        logger.info("SteamTrader 初始化完成 (steamid=%s)", self.steamid)

    # ------------------------------------------------------------------
    # 上下文管理器
    # ------------------------------------------------------------------

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        """关闭 HTTP 会话"""
        self.session.close()
        logger.info("SteamTrader 已关闭")

    # ------------------------------------------------------------------
    # BaseTrader 接口实现
    # ------------------------------------------------------------------

    def place_buy_order(self, item_id: str, price: float, quantity: int,
                        **kwargs) -> Dict:
        """
        创建求购单（买入）

        Args:
            item_id: market_hash_name，如 "AK-47 | Redline (Field-Tested)"
            price: 单价（人民币元），如 50.0 表示 ¥50.00
            quantity: 数量

        Returns:
            {'order_id': str, 'status': 'submitted', 'total_cost': float}
        """
        if price <= 0:
            raise DataFetchError("求购价格必须大于 0")
        if quantity <= 0:
            raise DataFetchError("求购数量必须大于 0")

        price_total_cents = round(price * 100) * quantity
        appid = kwargs.get("appid", CSGO_APPID)

        url = f"{STEAM_MARKET_BASE}/createbuyorder/"
        data = {
            "sessionid": self.sessionid,
            "currency": CNY_CURRENCY,
            "appid": appid,
            "market_hash_name": item_id,
            "price_total": price_total_cents,
            "quantity": quantity,
        }
        headers = {
            "Referer": f"{STEAM_MARKET_BASE}/",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        }

        logger.info(
            "创建求购单: %s x%d @ ¥%.2f (总计 %d 分)",
            item_id, quantity, price, price_total_cents,
        )

        resp_json = self._post(url, data=data, headers=headers)
        self._check_success(resp_json, "创建求购单")

        order_id = str(resp_json.get("buy_orderid", ""))
        total_cost = price_total_cents / 100.0

        logger.info("求购单已提交: order_id=%s, total_cost=¥%.2f", order_id, total_cost)

        return {
            "order_id": order_id,
            "status": "submitted",
            "total_cost": total_cost,
        }

    def place_sell_order(self, item_id: str, asset_id: str, price: float,
                         **kwargs) -> Dict:
        """
        创建出售挂单（卖出）

        Args:
            item_id: market_hash_name（用于日志，实际请求使用 asset_id）
            asset_id: Steam 资产 ID（assetid）
            price: 卖家实际收到的金额（人民币元），买家需支付约 15% 更多

        Returns:
            {'order_id': str, 'status': 'submitted'}
        """
        if price <= 0:
            raise DataFetchError("出售价格必须大于 0")

        price_cents = round(price * 100)
        appid = kwargs.get("appid", CSGO_APPID)
        contextid = kwargs.get("contextid", CSGO_CONTEXT_ID)

        url = f"{STEAM_MARKET_BASE}/sellitem/"
        data = {
            "sessionid": self.sessionid,
            "appid": appid,
            "contextid": contextid,
            "assetid": asset_id,
            "amount": 1,
            "price": price_cents,
        }
        headers = {
            "Referer": f"https://steamcommunity.com/profiles/{self.steamid}/inventory",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        }

        logger.info(
            "创建出售挂单: %s (asset=%s) @ ¥%.2f (%d 分)",
            item_id, asset_id, price, price_cents,
        )

        resp_json = self._post(url, data=data, headers=headers)
        self._check_success(resp_json, "创建出售挂单")

        # Steam 的 sellitem 不一定返回 order_id；listing_id 有时可从响应提取
        order_id = str(
            resp_json.get("listingid", "")
            or resp_json.get("order_id", "")
            or asset_id
        )

        if resp_json.get("needs_email_confirmation"):
            logger.warning("出售挂单需要邮箱确认: asset=%s", asset_id)

        logger.info("出售挂单已提交: order_id=%s", order_id)

        return {
            "order_id": order_id,
            "status": "submitted",
        }

    def cancel_order(self, order_id: str, order_type: str = "buy") -> Dict:
        """
        取消订单

        Args:
            order_id: 订单 ID
            order_type: 'buy'（求购单）或 'sell'（出售挂单/listing）

        Returns:
            {'status': 'cancelled'}
        """
        if order_type == "buy":
            url = f"{STEAM_MARKET_BASE}/cancelbuyorder/"
            data = {
                "sessionid": self.sessionid,
                "buy_orderid": order_id,
            }
            headers = {
                "Referer": f"{STEAM_MARKET_BASE}/",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            }
        elif order_type == "sell":
            # 出售挂单使用 removelisting/<listingid>
            url = f"{STEAM_MARKET_BASE}/removelisting/{order_id}"
            data = {
                "sessionid": self.sessionid,
            }
            headers = {
                "Referer": f"{STEAM_MARKET_BASE}/",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            }
        else:
            raise DataFetchError(f"不支持的订单类型: {order_type}，仅支持 'buy' 或 'sell'")

        logger.info("取消订单: order_id=%s, type=%s", order_id, order_type)

        resp_json = self._post(url, data=data, headers=headers)
        self._check_success(resp_json, f"取消{order_type}订单")

        logger.info("订单已取消: order_id=%s", order_id)

        return {"status": "cancelled"}

    def get_balance(self) -> float:
        """
        查询 Steam 钱包可用余额（人民币元）

        通过解析市场主页 HTML 中的钱包余额信息实现。

        Returns:
            可用余额，单位：人民币元
        """
        url = f"{STEAM_MARKET_BASE}/"
        headers = {
            "Referer": "https://steamcommunity.com/",
        }

        logger.debug("查询钱包余额")

        self.rate_limiter.wait_if_needed()
        try:
            response = self.session.get(url, headers=headers, timeout=30)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise DataFetchError(f"查询余额请求失败: {e}")

        html = response.text

        # 尝试从 HTML 中提取钱包余额
        # 格式: var g_rgWalletInfo = {"wallet_balance": 12345, ...};
        wallet_match = re.search(
            r'var\s+g_rgWalletInfo\s*=\s*(\{[^}]+\})', html
        )
        if wallet_match:
            try:
                import json
                wallet_info = json.loads(wallet_match.group(1))
                balance_cents = int(wallet_info.get("wallet_balance", 0))
                balance_yuan = balance_cents / 100.0
                logger.info("钱包余额: ¥%.2f", balance_yuan)
                return balance_yuan
            except (ValueError, KeyError) as e:
                logger.warning("解析 g_rgWalletInfo 失败: %s", e)

        # 备用方案：匹配 wallet_balance 字段
        balance_match = re.search(r'"wallet_balance"\s*:\s*(\d+)', html)
        if balance_match:
            balance_cents = int(balance_match.group(1))
            balance_yuan = balance_cents / 100.0
            logger.info("钱包余额(备用解析): ¥%.2f", balance_yuan)
            return balance_yuan

        raise DataFetchError("无法从市场页面解析钱包余额，可能未登录或页面结构变化")

    def get_open_orders(self) -> List[Dict]:
        """
        查询当前所有挂单（求购 + 出售）

        Returns:
            [{'order_id', 'type', 'item_name', 'price', 'quantity', 'status'}, ...]
        """
        url = f"{STEAM_MARKET_BASE}/mylistings/"
        params = {
            "query": "",
            "start": 0,
            "count": 100,
        }
        headers = {
            "Referer": f"{STEAM_MARKET_BASE}/",
        }

        logger.debug("查询当前挂单")

        self.rate_limiter.wait_if_needed()
        try:
            response = self.session.get(url, params=params, headers=headers, timeout=30)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise DataFetchError(f"查询挂单请求失败: {e}")

        content_type = response.headers.get("Content-Type", "")

        # 如果返回 JSON（部分 Steam 端点支持）
        if "application/json" in content_type:
            return self._parse_listings_json(response.json())

        # 否则解析 HTML 中嵌入的数据
        return self._parse_listings_html(response.text)

    def get_inventory(self) -> List[Dict]:
        """
        查询 CS2 库存物品

        Returns:
            [{'asset_id', 'item_name', 'market_hash_name', 'classid',
              'instanceid', 'tradable', 'marketable', 'amount'}, ...]
        """
        url = f"{STEAM_INVENTORY_BASE}/{self.steamid}/{CSGO_APPID}/{CSGO_CONTEXT_ID}/"
        params = {
            "l": "schinese",
            "count": 100,
        }
        headers = {
            "Referer": f"https://steamcommunity.com/profiles/{self.steamid}/inventory",
        }

        logger.debug("查询库存 (steamid=%s)", self.steamid)

        all_items: List[Dict] = []
        start_assetid: Optional[str] = None

        while True:
            if start_assetid:
                params["start_assetid"] = start_assetid

            self.rate_limiter.wait_if_needed()
            try:
                response = self.session.get(url, params=params, headers=headers, timeout=30)
                response.raise_for_status()
            except requests.exceptions.RequestException as e:
                raise DataFetchError(f"查询库存请求失败: {e}")

            data = response.json()

            if not data.get("success"):
                error_msg = data.get("error", "未知错误")
                raise DataFetchError(f"库存查询失败: {error_msg}")

            assets = data.get("assets", [])
            descriptions = data.get("descriptions", [])

            # 构建 classid+instanceid -> description 的查找表
            desc_map: Dict[str, dict] = {}
            for desc in descriptions:
                key = f"{desc.get('classid')}_{desc.get('instanceid', '0')}"
                desc_map[key] = desc

            # 合并资产与描述信息
            for asset in assets:
                key = f"{asset.get('classid')}_{asset.get('instanceid', '0')}"
                desc = desc_map.get(key, {})

                item = {
                    "asset_id": asset.get("assetid", ""),
                    "classid": asset.get("classid", ""),
                    "instanceid": asset.get("instanceid", "0"),
                    "amount": int(asset.get("amount", 1)),
                    "item_name": desc.get("market_name", ""),
                    "market_hash_name": desc.get("market_hash_name", ""),
                    "tradable": bool(int(desc.get("tradable", 0))),
                    "marketable": bool(int(desc.get("marketable", 0))),
                }
                all_items.append(item)

            # 分页处理
            more_items = data.get("more_items", 0)
            last_assetid = data.get("last_assetid")
            if more_items and last_assetid:
                start_assetid = str(last_assetid)
                logger.debug("库存分页: 继续加载 (start_assetid=%s)", start_assetid)
                time.sleep(1)  # 分页间短暂延迟，避免触发限制
            else:
                break

        logger.info("库存查询完成: 共 %d 件物品", len(all_items))
        return all_items

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_cookies(cookies: dict):
        """验证必要的 cookie 字段"""
        required = ("sessionid", "steamid")
        for key in required:
            if key not in cookies or not cookies[key]:
                raise DataFetchError(f"session_cookies 缺少必要字段: {key}")

    def _post(self, url: str, data: dict, headers: Optional[dict] = None) -> dict:
        """
        发送 POST 请求（带速率限制和错误处理）

        Returns:
            解析后的 JSON 响应
        """
        self.rate_limiter.wait_if_needed()

        try:
            response = self.session.post(url, data=data, headers=headers, timeout=30)
            response.raise_for_status()
        except requests.exceptions.Timeout:
            raise DataFetchError(f"POST {url} 请求超时")
        except requests.exceptions.ConnectionError as e:
            raise DataFetchError(f"POST {url} 连接失败: {e}")
        except requests.exceptions.HTTPError as e:
            raise DataFetchError(
                f"POST {url} HTTP错误: {e}",
                status_code=response.status_code,
            )
        except requests.exceptions.RequestException as e:
            raise DataFetchError(f"POST {url} 请求异常: {e}")

        try:
            return response.json()
        except ValueError:
            raise DataFetchError(f"POST {url} 响应非 JSON: {response.text[:200]}")

    @staticmethod
    def _check_success(resp_json: dict, operation: str):
        """检查 Steam API 返回的 success 字段"""
        if not resp_json.get("success"):
            message = resp_json.get("message", "未知错误")
            raise DataFetchError(f"{operation}失败: {message}")

    def _parse_listings_json(self, data: dict) -> List[Dict]:
        """解析 JSON 格式的挂单数据"""
        orders: List[Dict] = []

        # 求购单
        for item in data.get("buy_orders", []):
            orders.append({
                "order_id": str(item.get("buy_orderid", "")),
                "type": "buy",
                "item_name": item.get("market_hash_name", ""),
                "price": int(item.get("price", 0)) / 100.0,
                "quantity": int(item.get("quantity_remaining", 0)),
                "status": "active",
            })

        # 出售挂单
        for item in data.get("sell_listings", []):
            orders.append({
                "order_id": str(item.get("listingid", "")),
                "type": "sell",
                "item_name": item.get("market_hash_name", ""),
                "price": int(item.get("price", 0)) / 100.0,
                "quantity": 1,
                "status": "active",
            })

        logger.info("查询到 %d 个挂单", len(orders))
        return orders

    def _parse_listings_html(self, html: str) -> List[Dict]:
        """
        从 HTML 中解析挂单数据

        Steam mylistings 页面返回 HTML，其中包含嵌入的 JavaScript 数据。
        尝试提取 g_rgBuyOrders / g_rgSellListings 或行内 JSON。
        """
        import json
        orders: List[Dict] = []

        # 尝试提取嵌入的 JSON 数据块
        # 求购单: var g_rgBuyOrders = [...];
        buy_match = re.search(
            r'var\s+g_rgBuyOrders\s*=\s*(\[.*?\])\s*;', html, re.DOTALL
        )
        if buy_match:
            try:
                buy_orders = json.loads(buy_match.group(1))
                for item in buy_orders:
                    orders.append({
                        "order_id": str(item.get("buy_orderid", "")),
                        "type": "buy",
                        "item_name": item.get("market_hash_name", ""),
                        "price": int(item.get("price", 0)) / 100.0,
                        "quantity": int(item.get("quantity_remaining", 0)),
                        "status": "active",
                    })
            except (json.JSONDecodeError, ValueError) as e:
                logger.warning("解析 g_rgBuyOrders 失败: %s", e)

        # 出售挂单: var g_rgSellListings = [...];
        sell_match = re.search(
            r'var\s+g_rgSellListings\s*=\s*(\[.*?\])\s*;', html, re.DOTALL
        )
        if sell_match:
            try:
                sell_listings = json.loads(sell_match.group(1))
                for item in sell_listings:
                    orders.append({
                        "order_id": str(item.get("listingid", "")),
                        "type": "sell",
                        "item_name": item.get("market_hash_name", ""),
                        "price": int(item.get("price", 0)) / 100.0,
                        "quantity": 1,
                        "status": "active",
                    })
            except (json.JSONDecodeError, ValueError) as e:
                logger.warning("解析 g_rgSellListings 失败: %s", e)

        # 如果两者都没匹配到，尝试从 HTML 元素中提取基本信息
        if not orders:
            logger.warning(
                "未能从 HTML 中解析挂单数据，可能页面结构变化 (HTML长度: %d)", len(html)
            )

        logger.info("从HTML解析到 %d 个挂单", len(orders))
        return orders

    # ------------------------------------------------------------------
    # 便捷方法
    # ------------------------------------------------------------------

    @staticmethod
    def yuan_to_cents(yuan: float) -> int:
        """人民币元转分"""
        return int(yuan * 100)

    @staticmethod
    def cents_to_yuan(cents: int) -> float:
        """分转人民币元"""
        return cents / 100.0

    def validate_auth(self) -> bool:
        """验证 Steam 认证是否有效"""
        try:
            self.get_balance()
            return True
        except DataFetchError:
            return False
        except Exception:
            return False
