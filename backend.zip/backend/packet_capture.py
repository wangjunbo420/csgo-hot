"""
自动抓包模块 — Cookie 自动获取

提供两种模式自动获取 BUFF 登录 Cookie：
1. 浏览器自动化模式（Playwright）：启动 Chromium，用户登录后自动提取 Cookie
2. 本地代理模式（mitmproxy）：启动 HTTPS 代理，拦截浏览器发往 BUFF 的请求头

两种模式均为可选依赖，未安装时返回清晰的错误提示。
"""

import asyncio
import logging
import os
import threading
from typing import Optional

logger = logging.getLogger(__name__)


# ==================== 浏览器自动化模式 ====================

class BrowserCapture:
    """
    启动 Chromium 浏览器窗口 → 用户登录 BUFF → 自动提取 Cookie

    依赖：pip install playwright && playwright install chromium
    """

    def __init__(self):
        self._playwright = None
        self._browser = None
        self._context = None
        self._page = None
        self._status: str = "idle"  # idle | running | captured | error
        self._cookie: str = ""
        self._error: str = ""

    @property
    def status(self) -> str:
        return self._status

    @property
    def cookie(self) -> str:
        return self._cookie

    async def start(self) -> dict:
        """启动 Chromium 并导航到 BUFF 登录页"""
        if self._status == "running":
            return {"status": "running", "message": "浏览器已在运行中"}

        try:
            from playwright.async_api import async_playwright
        except ImportError:
            return {
                "status": "error",
                "error": (
                    "浏览器抓包组件（Playwright）未安装。"
                    "安装版未内置自动抓包，请改用「扫码登录」或直接粘贴 Cookie；"
                    "源码运行可执行: pip install playwright && playwright install chromium"
                ),
            }

        try:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=False,
                args=["--disable-blink-features=AutomationControlled"],
            )
            self._context = await self._browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
                viewport={"width": 1280, "height": 800},
            )
            self._page = await self._context.new_page()
            await self._page.goto(
                "https://buff.163.com/account/login",
                wait_until="domcontentloaded",
                timeout=30000,
            )
            self._status = "running"
            self._cookie = ""
            self._error = ""
            logger.info("浏览器已启动，等待用户登录 BUFF")
            return {"status": "running", "message": "浏览器已打开，请在窗口中登录 BUFF 账号"}

        except Exception as e:
            await self._cleanup()
            self._status = "error"
            self._error = str(e)
            logger.error(f"浏览器启动失败: {e}")
            return {"status": "error", "error": f"浏览器启动失败: {e}"}

    async def poll(self) -> dict:
        """
        轮询检查浏览器中是否已完成登录。

        登录成功的判定条件：buff.163.com 域名下存在名为 session 的 cookie。
        """
        if self._status == "captured":
            return {"status": "captured", "cookie": self._cookie}
        if self._status == "error":
            return {"status": "error", "error": self._error}
        if self._status != "running":
            return {"status": self._status, "message": "浏览器未启动"}

        try:
            # 检查浏览器是否还活着
            if self._page.is_closed():
                self._status = "idle"
                return {"status": "idle", "message": "浏览器已关闭"}

            cookies = await self._context.cookies()
            buff_cookies = [
                c for c in cookies
                if "buff.163.com" in c.get("domain", "")
            ]

            # 检查是否有 session cookie（登录标志）
            session_cookie = next(
                (c for c in buff_cookies if c["name"] == "session"), None
            )

            if session_cookie:
                # 拼接所有 BUFF 域名的 cookie
                self._cookie = "; ".join(
                    f'{c["name"]}={c["value"]}' for c in buff_cookies
                )
                self._status = "captured"
                logger.info(f"Cookie 已捕获，共 {len(buff_cookies)} 个 cookie")
                return {"status": "captured", "cookie": self._cookie}

            return {"status": "running", "message": "等待登录...请在浏览器中完成登录"}

        except Exception as e:
            self._status = "error"
            self._error = str(e)
            logger.error(f"Cookie 轮询异常: {e}")
            return {"status": "error", "error": str(e)}

    async def stop(self) -> dict:
        """关闭浏览器，清理资源"""
        await self._cleanup()
        self._status = "idle"
        logger.info("浏览器已关闭")
        return {"status": "idle", "message": "浏览器已关闭"}

    async def _cleanup(self):
        """安全清理所有浏览器资源"""
        try:
            if self._browser:
                await self._browser.close()
        except Exception:
            pass
        try:
            if self._playwright:
                await self._playwright.stop()
        except Exception:
            pass
        self._browser = None
        self._context = None
        self._page = None
        self._playwright = None


# ==================== 本地代理模式 ====================

class _CookieAddon:
    """mitmproxy addon：拦截发往 buff.163.com 的请求并提取 Cookie"""

    def __init__(self):
        self.captured_cookie: str = ""
        self.captured: bool = False
        self.request_count: int = 0

    def request(self, flow):
        """每个经过代理的 HTTP 请求都会经过这里"""
        host = flow.request.host
        if "buff.163.com" not in host:
            return

        self.request_count += 1
        cookie = flow.request.headers.get("cookie", "")

        if cookie and "session" in cookie:
            self.captured_cookie = cookie
            self.captured = True
            logger.info(f"BUFF Cookie 已拦截 (第 {self.request_count} 个请求)")


class ProxyCapture:
    """
    启动本地 HTTPS 代理，拦截浏览器发往 BUFF 的请求以获取 Cookie。

    依赖：pip install mitmproxy
    注意：首次运行会在 ~/.mitmproxy/ 生成 CA 证书，
          用户需安装该证书到系统受信任根证书颁发机构才能拦截 HTTPS。
    """

    def __init__(self, port: int = 8888):
        self.port = port
        self._master = None
        self._thread: Optional[threading.Thread] = None
        self._addon = _CookieAddon()
        self._status: str = "idle"  # idle | running | captured | error
        self._error: str = ""
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def status(self) -> str:
        return self._status

    @property
    def cookie(self) -> str:
        return self._addon.captured_cookie

    def get_cert_dir(self) -> str:
        """返回 mitmproxy CA 证书目录"""
        return os.path.expanduser("~/.mitmproxy")

    async def start(self) -> dict:
        """在后台线程中启动 mitmproxy 代理服务器"""
        if self._status == "running":
            return {"status": "running", "message": f"代理已在端口 {self.port} 运行"}

        try:
            from mitmproxy.options import Options
            from mitmproxy.tools.dump import DumpMaster
        except ImportError:
            return {
                "status": "error",
                "error": (
                    "代理抓包组件（mitmproxy）未安装。"
                    "安装版未内置自动抓包，请改用「扫码登录」或直接粘贴 Cookie；"
                    "源码运行可执行: pip install mitmproxy"
                ),
            }

        try:
            opts = Options(listen_host="127.0.0.1", listen_port=self.port)
            self._master = DumpMaster(opts)
            self._master.addons.add(self._addon)

            # mitmproxy 需要在独立线程中运行自己的事件循环
            self._thread = threading.Thread(
                target=self._run_proxy_thread,
                daemon=True,
                name="mitmproxy-thread",
            )
            self._thread.start()
            self._status = "running"
            self._error = ""
            logger.info(f"代理服务器已启动在 127.0.0.1:{self.port}")

            cert_dir = self.get_cert_dir()
            return {
                "status": "running",
                "port": self.port,
                "cert_dir": cert_dir,
                "message": (
                    f"代理已启动在 127.0.0.1:{self.port}\n"
                    f"CA 证书目录: {cert_dir}\n"
                    "请将浏览器代理设置为此地址，然后访问 buff.163.com"
                ),
            }

        except Exception as e:
            self._status = "error"
            self._error = str(e)
            logger.error(f"代理启动失败: {e}")
            return {"status": "error", "error": f"代理启动失败: {e}"}

    def _run_proxy_thread(self):
        """在独立线程中运行 mitmproxy（它有自己的 asyncio 事件循环）"""
        try:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._master.run())
        except Exception as e:
            logger.error(f"代理线程异常: {e}")
            self._error = str(e)
            self._status = "error"
        finally:
            if self._loop:
                self._loop.close()

    def poll(self) -> dict:
        """检查是否已拦截到 BUFF Cookie"""
        if self._addon.captured:
            self._status = "captured"
            return {"status": "captured", "cookie": self._addon.captured_cookie}
        if self._status == "error":
            return {"status": "error", "error": self._error}
        if self._status != "running":
            return {"status": self._status, "message": "代理未启动"}

        return {
            "status": "running",
            "message": f"代理运行中，已拦截 {self._addon.request_count} 个 BUFF 请求",
        }

    async def stop(self) -> dict:
        """停止代理服务器"""
        try:
            if self._master and self._loop and self._loop.is_running():
                # 在代理线程自己的事件循环中触发 shutdown，确保线程安全
                self._loop.call_soon_threadsafe(self._master.shutdown)
            elif self._master:
                self._master.shutdown()
            if self._thread and self._thread.is_alive():
                self._thread.join(timeout=5)
        except Exception as e:
            logger.warning(f"代理关闭异常: {e}")
        finally:
            self._master = None
            self._thread = None
            self._status = "idle"
            logger.info("代理服务器已停止")
        return {"status": "idle", "message": "代理已停止"}


# ==================== 统一管理器 ====================

class CaptureManager:
    """
    统一管理浏览器模式和代理模式的抓包生命周期。

    确保同一时间每种模式只有一个实例在运行，
    并在应用关闭时自动清理所有资源。
    """

    def __init__(self, proxy_port: int = 8888):
        self.proxy_port = proxy_port
        self.browser: Optional[BrowserCapture] = None
        self.proxy: Optional[ProxyCapture] = None

    def get_browser(self) -> BrowserCapture:
        """获取或创建浏览器抓包实例"""
        if self.browser is None:
            self.browser = BrowserCapture()
        return self.browser

    def get_proxy(self, port: Optional[int] = None) -> ProxyCapture:
        """获取或创建代理抓包实例"""
        if self.proxy is None:
            self.proxy = ProxyCapture(port=port or self.proxy_port)
        return self.proxy

    async def shutdown(self):
        """关闭所有抓包资源（在 FastAPI lifespan 中调用）"""
        if self.browser:
            await self.browser.stop()
            self.browser = None
        if self.proxy:
            await self.proxy.stop()
            self.proxy = None
        logger.info("抓包管理器已关闭所有资源")
