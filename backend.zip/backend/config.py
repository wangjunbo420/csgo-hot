"""
系统配置文件

配置优先级：环境变量 > .env 文件 > 默认值
敏感信息（如 Cookie）必须通过环境变量或 .env 文件提供
"""

import os
from dataclasses import dataclass, field
from typing import List

import paths


def _load_dotenv(filepath: str = ".env"):
    """简易 .env 文件加载器（避免第三方依赖）

    优先读数据目录下的 .env（安装版用户可写位置），其次读代码目录下的 .env。
    """
    candidates = [
        os.path.join(paths.data_dir(), filepath),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), filepath),
    ]
    for env_path in candidates:
        if not os.path.exists(env_path):
            continue
        with open(env_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip().strip("\"'")
                    if key and key not in os.environ:
                        os.environ[key] = value
        break


# 加载 .env 文件（如果存在）
_load_dotenv()


@dataclass
class APIConfig:
    """网易BUFF API配置"""
    # API 基础 URL
    BASE_URL: str = os.getenv("BUFF_API_BASE_URL", "https://buff.163.com/api")

    # 速率限制（严格遵守官方限制）
    MAX_REQUESTS_PER_MINUTE: int = 10
    REQUEST_INTERVAL: float = 6.0
    RANDOM_DELAY_MIN: float = 0.5
    RANDOM_DELAY_MAX: float = 2.0
    MAX_RETRY_COUNT: int = 3
    TIMEOUT: int = 10

    # Cookie 认证 — 从环境变量读取，源码中不包含任何凭据
    # 获取方式：登录 buff.163.com → F12 → Network → 复制 Cookie
    COOKIE: str = os.getenv("BUFF_COOKIE", "")

    # 代理池（为空时不使用代理）
    PROXY_POOL: List[str] = field(default_factory=list)


@dataclass
class SteamConfig:
    """Steam 社区市场 API 配置"""
    BASE_URL: str = "https://steamcommunity.com/market"
    APPID: int = 730          # CS2
    CURRENCY: int = 23        # CNY（人民币）

    # 速率限制（Steam 公开接口限速严格，保守设置）
    MAX_REQUESTS_PER_MINUTE: int = 8
    REQUEST_INTERVAL: float = 7.5
    RANDOM_DELAY_MIN: float = 1.0
    RANDOM_DELAY_MAX: float = 3.0
    TIMEOUT: int = 15


@dataclass
class RiskConfig:
    """风险评级配置"""
    OVERSOLD_THRESHOLD: float = -0.15       # 超跌阈值：-15%
    MANIPULATION_THRESHOLD: float = -0.10   # 做盘风险阈值：-10%
    HIGH_LIQUIDITY_THRESHOLD: float = 1.2   # 高流动性阈值
    LOW_BUY_DEPTH_THRESHOLD: float = 0.3    # 低求购深度阈值


@dataclass
class TradeConfig:
    """交易决策配置"""
    MAX_LOSS_RATE: float = 0.02             # 最大单笔亏损率：2%
    STOP_LOSS_SPACE: float = 0.10           # 止损空间：10%
    MIN_DEVIATION_FOR_TRADE: float = -0.20  # 触发采购的最小偏离度：-20%
    T_PLUS_7_DAYS: int = 7                  # Steam T+7 交易延迟
    # 数据库放在数据目录（安装版：%LOCALAPPDATA%\CSGO饰品交易分析\data），可用环境变量覆盖
    DATABASE_PATH: str = os.getenv("TRADE_DB_PATH") or paths.data_path("trade_decisions.db")
    MAX_SINGLE_TRADE_AMOUNT: float = float(
        os.getenv("MAX_SINGLE_TRADE_AMOUNT", "5000")
    )  # 单笔交易金额上限（元）


@dataclass
class AutoDeliveryConfig:
    """秒发货 — BUFF 自动发货配置"""
    ENABLED: bool = os.getenv("AUTO_DELIVERY_ENABLED", "false").lower() == "true"
    POLL_INTERVAL: int = int(os.getenv("AUTO_DELIVERY_POLL_INTERVAL", "30"))  # 轮询间隔（秒）
    MAX_DELIVERY_AMOUNT: float = float(
        os.getenv("AUTO_DELIVERY_MAX_AMOUNT", "5000")
    )  # 单笔发货金额上限（元）— 与 MAX_SINGLE_TRADE_AMOUNT 保持一致
    AUTO_ACCEPT: bool = os.getenv("AUTO_DELIVERY_AUTO_ACCEPT", "false").lower() == "true"


# 默认数据平台
DEFAULT_PLATFORM: str = os.getenv("DEFAULT_PLATFORM", "buff")

# 总资金（从环境变量读取）
TOTAL_CAPITAL: float = float(os.getenv("TRADING_TOTAL_CAPITAL", "100000"))

# CORS 允许的域名
CORS_ORIGINS: List[str] = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
    if origin.strip()
]

# API 服务端口
API_PORT: int = int(os.getenv("API_PORT", "8000"))

# 抓包代理端口
PROXY_PORT: int = int(os.getenv("CAPTURE_PROXY_PORT", "8888"))

# 监控的饰品列表
MONITORED_ITEMS = [
    {
        "name": "AK-47 | 火蛇",
        "market_hash_name": "AK-47 | Fire Serpent (Field-Tested)",
        "game": "csgo",
    }
]
